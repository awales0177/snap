Moonstorm dataframe row editor — source snapshot

Core:
  moonstorm/moonstorm-jup-theme/moonstorm_jup_theme/dataframe_viewer.py
  moonstorm/moonstorm-jup-theme/moonstorm_jup_theme/ipython.py (kernel extension hook)

Styles (keep dataframeViewerCss.ts in sync with dataframe-viewer.css):
  moonstorm/moonstorm-jup-theme/style/dataframe-viewer.css
  moonstorm/moonstorm-jup-theme/src/lib/dataframeViewerCss.ts
  moonstorm/moonstorm-jup-theme/src/lib/dataframeViewerStyles.ts

Bundled theme (underline fix + PostCSS-expanded viewer CSS):
  moonstorm/moonstorm-jup-theme/moonstorm_jup_theme/labextension/themes/moonstorm-jup-theme/index.css
  moonstorm/moonstorm-jup-theme/moonstorm_jup_theme/labextension/themes/moonstorm-jup-theme/theme-dark.css
  moonstorm/moonstorm-jup-theme/moonstorm_jup_theme/labextension/themes/moonstorm-jup-theme/theme-light.css

Tests:
  moonstorm/moonstorm-jup-theme/tests/test_row_edit.py
  moonstorm/moonstorm-jup-theme/tests/test_theme.py
  moonstorm/moonstorm-jup-theme/tests/test_viewer_matrix.py
  moonstorm/moonstorm-jup-theme/tests/test_dataframe_ipython.py
  moonstorm/moonstorm-jup-theme/tests/node/dataframeRowEdit.test.mjs
  moonstorm/moonstorm-jup-theme/tests/node/helpers/rowEditRuntime.mjs

Install from repo root:
  ./scripts/install-local-wheels.sh moonstorm

Run row-edit tests (from moonstorm-jup-theme):
  PYTHONPATH=. python -m pytest tests/test_row_edit.py -q
  node --import ./tests/node/setup.mjs --test tests/node/dataframeRowEdit.test.mjs

Imports:
  from moonstorm_jup_theme import display
  from moonstorm_jup_theme.dataframe_viewer import build_dataframe_html
