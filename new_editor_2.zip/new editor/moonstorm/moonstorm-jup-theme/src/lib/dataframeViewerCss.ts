/** Auto-synced shared dataframe viewer CSS (from style/dataframe-viewer.css). */
export const DATAFRAME_VIEWER_CSS = `/* Shared Moonstorm dataframe viewer styles (class-scoped).
 * Injected once by the Lab extension (and into output iframes).
 * Keep in sync with height defaults in dataframe_viewer.py.
 */
    .dataframe-viewer {
        position:relative; border-radius:12px; border:1px solid #404040; overflow:hidden;
        box-shadow:0 2px 8px rgba(0,0,0,.3); background:#1e1e1e;
        font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        margin:10px 0; width:100%; box-sizing:border-box;
        display:flex; flex-direction:column;
        --dfv-scrollbar-width:8px;
    }
    .dataframe-viewer .dataframe-header {
        background:var(--moonstorm-dfv-header-bg, linear-gradient(135deg,#667eea 0%,#764ba2 100%));
        color:white; padding:6px calc(12px + var(--dfv-scrollbar-width)) 6px 12px;
        font-weight:600; font-size:14px;
        display:flex; align-items:center; box-sizing:border-box;
    }
    .dataframe-viewer .dataframe-header-bar {
        display:flex; align-items:center; justify-content:flex-end;
        gap:8px; width:100%; position:relative;
    }
    .dataframe-viewer .dataframe-header-bar:has(.dataframe-result-tabs) {
        justify-content:flex-start;
    }
    .dataframe-viewer .column-filter-btn {
        display:inline-flex; align-items:center; justify-content:center;
        cursor:pointer; padding:1px; border-radius:4px; border:1px solid transparent;
        transition:background .2s,border-color .2s;
    }
    .dataframe-viewer .column-filter-btn:hover { background:rgba(255,255,255,.2); border-color:rgba(255,255,255,.3); }
    .dataframe-viewer .column-filter-btn.active { background:rgba(255,255,255,.25); border-color:rgba(255,255,255,.4); }
    .dataframe-viewer .column-filter-btn svg { width:14px; height:14px; filter:invert(1); }
    .dataframe-viewer .dataframe-table th.column-selector-hidden,
    .dataframe-viewer .dataframe-table td.column-selector-hidden { display:none !important; }
    .dataframe-viewer .dataframe-table tr.column-selector-empty-row td {
        text-align:center; color:#888; font-style:italic; padding:16px;
    }
    .dataframe-viewer .column-selector-wrap { display:inline-flex; align-items:center; margin-left:0; position:relative; }
    .dataframe-viewer .column-selector-wrap .column-selector-btn,
    .dataframe-viewer .column-selector-wrap .dataframe-open-tab-btn,
    .dataframe-viewer .column-selector-wrap .dataframe-row-edit-btn,
    .dataframe-viewer .column-selector-wrap .dataframe-split-btn,
    .dataframe-viewer .column-selector-wrap .dataframe-merge-btn,
    .dataframe-viewer .column-selector-wrap .dataframe-minimize-btn {
        width:auto; border-radius:6px;
        background:transparent; border-color:transparent;
        appearance:none; -webkit-appearance:none;
        color:inherit; box-shadow:none;
    }
    .dataframe-viewer .column-selector-wrap .column-selector-btn:hover,
    .dataframe-viewer .column-selector-wrap .dataframe-open-tab-btn:hover,
    .dataframe-viewer .column-selector-wrap .dataframe-row-edit-btn:hover,
    .dataframe-viewer .column-selector-wrap .dataframe-split-btn:hover,
    .dataframe-viewer .column-selector-wrap .dataframe-merge-btn:hover,
    .dataframe-viewer .column-selector-wrap .dataframe-minimize-btn:hover {
        background:rgba(255,255,255,.2); border-color:rgba(255,255,255,.3);
    }
    .dataframe-viewer .column-selector-wrap .column-selector-btn.active,
    .dataframe-viewer .column-selector-wrap .dataframe-open-tab-btn.active,
    .dataframe-viewer .column-selector-wrap .dataframe-row-edit-btn.active,
    .dataframe-viewer .column-selector-wrap .dataframe-split-btn.active,
    .dataframe-viewer .column-selector-wrap .dataframe-merge-btn.active,
    .dataframe-viewer .column-selector-wrap .dataframe-minimize-btn.active {
        background:rgba(255,255,255,.25); border-color:rgba(255,255,255,.4);
    }
    .dataframe-viewer .column-selector-wrap .column-selector-btn svg,
    .dataframe-viewer .column-selector-wrap .dataframe-open-tab-btn svg,
    .dataframe-viewer .column-selector-wrap .dataframe-row-edit-btn svg,
    .dataframe-viewer .column-selector-wrap .dataframe-minimize-btn svg {
        width:14px; height:14px; filter:invert(1);
    }
    .dataframe-viewer .column-selector-wrap .dataframe-merge-btn svg,
    .dataframe-viewer .dataframe-merge-icon {
        width:16px; height:16px; filter:invert(1);
    }
    .dataframe-viewer .column-selector-wrap .dataframe-split-btn svg,
    .dataframe-viewer .dataframe-split-icon {
        width:11px; height:11px; filter:invert(1);
    }
    /* Minimized chrome: warning bar + tray (same layout as collapsed cell output). */
    .dataframe-viewer .dataframe-minimized-chrome {
        display:none;
        --dfv-tray-button-size:26px;
        --dfv-tray-button-radius:6px;
        --dfv-tray-radius:8px;
        width:100%;
        box-sizing:border-box;
        align-items:stretch;
        gap:6px;
        padding:4px 6px 4px 0;
    }
    .dataframe-viewer .dataframe-minimized-banner {
        flex:1 1 auto;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap:8px;
        min-width:0;
        min-height:var(--dfv-tray-button-size);
        margin:0;
        padding:6px 12px;
        appearance:none;
        box-sizing:border-box;
        border:1px solid transparent;
        border-radius:var(--dfv-tray-radius);
        /* Match the dataframe viewer header. */
        background:var(--moonstorm-dfv-header-bg, linear-gradient(135deg,#667eea 0%,#764ba2 100%));
        color:white;
        font:inherit;
        font-size:12px;
        font-weight:600;
        line-height:1.2;
        cursor:pointer;
        text-align:center;
        box-shadow:0 1px 3px rgba(0,0,0,.1);
    }
    .dataframe-viewer .dataframe-minimized-banner:hover {
        filter:brightness(1.06);
    }
    .dataframe-viewer .dataframe-minimized-icon {
        display:inline-flex; flex:0 0 auto; align-items:center; justify-content:center;
        color:#f0d090;
    }
    .dataframe-viewer .dataframe-minimized-icon svg { display:block; width:14px; height:14px; }
    .dataframe-viewer .dataframe-minimized-label { white-space:nowrap; }
    .dataframe-viewer .dataframe-minimized-tray {
        flex:0 0 auto;
        align-self:stretch;
        display:inline-flex;
        align-items:center;
        gap:2px;
        box-sizing:border-box;
        padding:3px;
        border:1px solid var(--moonstorm-border, var(--jp-border-color2, #404040));
        border-radius:var(--dfv-tray-radius);
        background:var(--moonstorm-toolbar-dropdown-bg, var(--moonstorm-tab-inactive-bg, var(--jp-layout-color1, #252525)));
        box-shadow:0 1px 3px rgba(0,0,0,.1);
    }
    .dataframe-viewer .dataframe-minimized-tray-btn {
        position:relative;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        width:var(--dfv-tray-button-size);
        height:var(--dfv-tray-button-size);
        margin:0;
        padding:0;
        appearance:none;
        border:0;
        border-radius:var(--dfv-tray-button-radius);
        background:transparent;
        color:var(--moonstorm-text-secondary, var(--jp-ui-font-color2, #aaa));
        cursor:pointer;
        flex:0 0 auto;
    }
    .dataframe-viewer .dataframe-minimized-tray-btn::before {
        content:'';
        position:absolute;
        inset:0;
        border-radius:var(--dfv-tray-button-radius);
        background-color:transparent;
        transition:background-color .12s ease;
    }
    .dataframe-viewer .dataframe-minimized-tray-btn:hover::before {
        background-color:var(--moonstorm-toolbar-dropdown-hover-bg, var(--moonstorm-tab-tray-hover-bg, var(--jp-layout-color2, #3a3a3a)));
    }
    .dataframe-viewer .dataframe-minimized-tray-btn:hover {
        color:var(--moonstorm-text, var(--jp-ui-font-color1, #e0e0e0));
    }
    .dataframe-viewer .dataframe-minimized-tray-btn svg {
        position:relative;
        z-index:1;
        display:block;
        width:14px;
        height:14px;
    }
    .dataframe-viewer[data-minimized="true"] {
        background:transparent !important;
        border-color:transparent !important;
        box-shadow:none !important;
        overflow:visible !important;
        margin:4px 0;
    }
    .dataframe-viewer[data-minimized="true"] > .dataframe-minimized-chrome {
        display:flex;
    }
    .dataframe-viewer[data-minimized="true"] > .dataframe-header,
    .dataframe-viewer[data-minimized="true"] > .dataframe-table-shell,
    .dataframe-viewer[data-minimized="true"] > .dataframe-footer,
    .dataframe-viewer[data-minimized="true"] > .dataframe-result-pane,
    .dataframe-viewer[data-minimized="true"] > .columns-hidden-notice,
    .dataframe-viewer[data-minimized="true"] > .column-selector-backdrop {
        display:none !important;
    }
    .dataframe-viewer .dataframe-result-tabs {
        display:flex; align-items:center; gap:4px; flex:1 1 auto; min-width:0;
        overflow-x:auto; scrollbar-width:thin;
    }
    .dataframe-viewer .dataframe-result-tab {
        appearance:none; -webkit-appearance:none; border:1px solid transparent;
        background:rgba(255,255,255,.12); color:inherit; cursor:pointer;
        font:inherit; font-size:12px; font-weight:600; line-height:1.2;
        padding:4px 10px; border-radius:6px; white-space:nowrap; flex:0 0 auto;
    }
    .dataframe-viewer .dataframe-result-tab:hover { background:rgba(255,255,255,.2); }
    .dataframe-viewer .dataframe-result-tab[aria-selected="true"] {
        background:rgba(255,255,255,.28); border-color:rgba(255,255,255,.45);
    }
    .dataframe-viewer .dataframe-header-actions {
        display:flex; align-items:center; justify-content:flex-end;
        gap:8px; flex:0 0 auto; margin-left:auto;
    }
    .dataframe-viewer .dataframe-result-controls { display:inline-flex; align-items:center; gap:8px; }
    .dataframe-viewer .dataframe-result-controls[hidden] { display:none !important; }
    .dataframe-viewer .dataframe-result-pane[hidden] { display:none !important; }
    .dataframe-viewer .dataframe-result-pane {
        display:flex; flex-direction:column; min-width:0;
    }
    .dataframe-viewer.light-mode .dataframe-result-tab {
        background:rgba(0,0,0,.06); color:#333;
    }
    .dataframe-viewer.light-mode .dataframe-result-tab:hover { background:rgba(0,0,0,.1); }
    .dataframe-viewer.light-mode .dataframe-result-tab[aria-selected="true"] {
        background:rgba(0,0,0,.14); border-color:rgba(0,0,0,.18);
    }
    .dataframe-viewer .column-selector-backdrop {
        display:none; position:absolute; inset:0;
        align-items:center; justify-content:center;
        background:rgba(0,0,0,.45); z-index:100;
    }
    .dataframe-viewer .column-selector-backdrop.open { display:flex; }
    /* Tab host: give the table room to breathe. */
    .dataframe-viewer.dataframe-viewer--tab .dataframe-table-shell {
        flex:1 1 auto; height:auto !important; min-height:280px;
        max-height:none !important;
    }
    .dataframe-viewer.dataframe-viewer--tab .dataframe-open-tab-btn,
    .dataframe-viewer.dataframe-viewer--tab .dataframe-minimize-btn { display:none; }
    .dataframe-viewer .column-selector-modal {
        background:#252525; border:1px solid #404040; border-radius:10px;
        box-shadow:0 8px 32px rgba(0,0,0,.5); padding:0;
        width:420px; min-width:280px; max-width:90%; max-height:calc(100% - 16px);
        overflow:hidden; display:flex; flex-direction:column; position:relative;
    }
    .dataframe-viewer .column-selector-modal-header {
        display:flex; align-items:center; justify-content:space-between; gap:8px;
        padding:10px 12px; border-bottom:1px solid #404040;
    }
    .dataframe-viewer .column-selector-title-row { display:flex; align-items:center; gap:8px; flex-shrink:0; }
    .dataframe-viewer .column-selector-modal-title { font-weight:600; font-size:13px; color:#e0e0e0; margin:0; }
    .dataframe-viewer .column-selector-toggle-all-btn {
        display:inline-flex; align-items:center; justify-content:center;
        width:28px; height:28px; padding:0;
        background:transparent; border:1px solid rgba(255,255,255,.35); border-radius:50%;
        color:#d0d0d0; cursor:pointer;
        transition:background .2s, border-color .2s, color .2s;
    }
    .dataframe-viewer .column-selector-toggle-all-btn:hover {
        background:rgba(255,255,255,.12); border-color:rgba(255,255,255,.45); color:#fff;
    }
    .dataframe-viewer .column-selector-toggle-state { display:inline-flex; align-items:center; justify-content:center; }
    .dataframe-viewer .column-selector-toggle-all-btn .column-selector-layers-icon { width:14px; height:14px; }
    .dataframe-viewer .column-selector-close {
        background:transparent; border:none; color:#999; cursor:pointer;
        font-size:20px; line-height:1; padding:0 4px; border-radius:4px;
        transition:color .2s, background .2s;
    }
    .dataframe-viewer .column-selector-close:hover { color:#fff; background:rgba(255,255,255,.15); }
    .dataframe-viewer .column-selector-modal-body { padding:8px; overflow-y:auto; min-height:260px; max-height:260px; }
    .dataframe-viewer .column-selector-row { display:flex; align-items:center; gap:8px; padding:6px 8px; cursor:pointer; font-size:12px; color:#d0d0d0; border-radius:4px; }
    .dataframe-viewer .column-selector-row:hover { background:#333; }
    .dataframe-viewer .column-selector-check { cursor:pointer; flex-shrink:0; }
    /* ── Light mode ─────────────────────────────────────────────────────── */
    .dataframe-viewer.light-mode { background:#fff; border:1px solid #e0e0e0; }
    .dataframe-viewer.light-mode .column-header-dtype { color:#888; }
    .dataframe-viewer.light-mode .dataframe-table th {
        background:#f5f5f5; color:#333; border-bottom:2px solid #ddd; border-right:1px solid #ddd;
    }
    .dataframe-viewer.light-mode .dataframe-table td { background:#fff; color:#333; border:1px solid #e0e0e0; }
    .dataframe-viewer.light-mode .dataframe-table-container { background:#fff; }
    .dataframe-viewer.light-mode .complex-content {
        background: var(--moonstorm-cell-bg, var(--jp-layout-color2, #f5f5f5));
        border-left-color: var(--moonstorm-border, var(--jp-border-color1, #dadce0));
    }
    .dataframe-viewer.light-mode .complex-json {
        background: transparent !important;
        color: var(--moonstorm-text, var(--jp-ui-font-color1, #202124));
    }
    .dataframe-viewer.light-mode .dataframe-table pre { background:#f5f5f5 !important; color:#333 !important; }
    .dataframe-viewer.light-mode .dataframe-null { color:#999; }
    .dataframe-viewer.light-mode .dataframe-table-container::-webkit-scrollbar-track { background:#f5f5f5; }
    .dataframe-viewer.light-mode .dataframe-table-container::-webkit-scrollbar-thumb { background:#ccc; }
    .dataframe-viewer.light-mode .dataframe-table-container::-webkit-scrollbar-thumb:hover { background:#aaa; }
    .dataframe-viewer.light-mode .dataframe-footer { background:#f5f5f5; border-top:1px solid #ddd; color:#666; }
    .dataframe-viewer.light-mode .dataframe-resize-corner { color:#aaa; }
    .dataframe-viewer.light-mode .dataframe-resize-corner:hover,
    .dataframe-viewer.light-mode .dataframe-footer:hover .dataframe-resize-corner {
        color:var(--moonstorm-dfv-accent, #6366f1);
    }
    .dataframe-viewer.light-mode .dataframe-footer .columns-hidden-notice { color:#b45309; }
    .dataframe-viewer.light-mode .dataframe-table tbody tr { background:#fff; }
    .dataframe-viewer.light-mode .dataframe-table tbody tr:hover,
    .dataframe-viewer.light-mode .dataframe-table tbody tr:hover td { background:#f0f0f0; }
    .dataframe-viewer.light-mode .dataframe-table th:hover { background:#e8e8e8; }
    .dataframe-viewer.light-mode .sort-indicator { color:var(--moonstorm-dfv-accent, #6366f1); }
    .dataframe-viewer.light-mode .column-selector-backdrop { background:rgba(0,0,0,.25); }
    .dataframe-viewer.light-mode .column-selector-modal { background:#fff; border-color:#e0e0e0; box-shadow:0 8px 32px rgba(0,0,0,.2); }
    .dataframe-viewer.light-mode .column-selector-modal-header { border-bottom-color:#e0e0e0; }
    .dataframe-viewer.light-mode .column-selector-modal-title { color:#333; }
    .dataframe-viewer.light-mode .column-selector-toggle-all-btn { border-color:#ccc; color:#555; }
    .dataframe-viewer.light-mode .column-selector-toggle-all-btn:hover { background:rgba(0,0,0,.06); border-color:#999; color:#333; }
    .dataframe-viewer.light-mode .column-selector-close { color:#666; }
    .dataframe-viewer.light-mode .column-selector-close:hover { color:#333; background:rgba(0,0,0,.08); }
    .dataframe-viewer.light-mode .column-selector-row { color:#333; }
    .dataframe-viewer.light-mode .column-selector-row:hover { background:#f0f0f0; }
    /* ── Table shell (height dragged from footer corner) ────────────────── */
    .dataframe-viewer .dataframe-table-shell {
        flex:0 0 auto;
        position:relative;
        height:260px;
        min-height:120px;
        max-height:min(85vh, 960px);
        overflow:hidden;
        box-sizing:border-box;
    }
    .dataframe-viewer .dataframe-table-container {
        height:100%;
        overflow:auto;
        overscroll-behavior:contain;
        box-sizing:border-box;
    }
    .dataframe-viewer .dataframe-table {
        width:100%; border-collapse:collapse; font-size:13px; table-layout:fixed; min-width:100%;
    }
    .dataframe-viewer tr.dfv-virtual-spacer td {
        padding:0 !important;
        border:none !important;
        line-height:0;
        overflow:hidden;
    }
    .dataframe-viewer .dataframe-table thead { position:sticky; top:0; z-index:10; }
    .dataframe-viewer .dataframe-table th {
        background:#2d2d2d; padding:6px 10px; text-align:left !important;
        font-weight:600; color:#e0e0e0; border-bottom:2px solid #404040;
        border-right:1px solid #555; position:relative;
        cursor:pointer; user-select:text; vertical-align:bottom;
    }
    .dataframe-viewer .column-header {
        display:flex; flex-direction:column; gap:2px;
        padding-right:12px; min-width:0;
    }
    .dataframe-viewer .column-header-name {
        font-weight:600; font-size:13px; line-height:1.2;
        white-space:nowrap; overflow:visible; text-overflow:unset;
    }
    .dataframe-viewer .column-header-dtype {
        font-weight:400; font-size:10px; line-height:1.2;
        color:#999; text-transform:lowercase;
        white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
    }
    .dataframe-viewer .dataframe-table th:hover { background:#353535; }
    .dataframe-viewer .dataframe-table th:last-child { border-right:none; }
    .dataframe-viewer .dataframe-table td:last-child { border-right:none; }
    .dataframe-viewer .dataframe-table th.sortable { padding-right:24px; }
    .dataframe-viewer .sort-indicator {
        position:absolute; right:8px; top:50%; transform:translateY(-50%);
        display:flex; align-items:center; justify-content:center;
        color:var(--moonstorm-dfv-accent, #8b9aff);
    }
    .dataframe-viewer .sort-indicator .sort-icon-asc,
    .dataframe-viewer .sort-indicator .sort-icon-desc { display:none; }
    .dataframe-viewer .dataframe-table th.sort-asc .sort-indicator .sort-icon-asc { display:inline-flex; }
    .dataframe-viewer .dataframe-table th.sort-desc .sort-indicator .sort-icon-desc { display:inline-flex; }
    .dataframe-viewer .sort-indicator .sort-icon-svg { width:14px; height:14px; }
    .dataframe-viewer .dataframe-table th .resize-handle {
        position:absolute; top:0; right:0; width:5px; height:100%;
        cursor:col-resize; background:transparent; z-index:1;
    }
    .dataframe-viewer .dataframe-table th .resize-handle:hover { background:var(--moonstorm-dfv-accent, #8b9aff); opacity:.5; }
    .dataframe-viewer .dataframe-table tbody tr { background:#1e1e1e; }
    .dataframe-viewer .dataframe-table td {
        padding:6px 10px; border:1px solid #333; color:#d0d0d0;
        word-wrap:break-word; overflow-wrap:break-word;
        background:#1e1e1e; text-align:left !important;
    }
    .dataframe-viewer .dataframe-table tbody tr:hover,
    .dataframe-viewer .dataframe-table tbody tr:hover td { background:#2a2a2a; }
    .dataframe-viewer .dataframe-table tbody tr:last-child td { border-bottom:none; }
    .dataframe-viewer .dataframe-footer {
        flex:0 0 auto;
        position:relative;
        background:#252525;
        padding:6px calc(28px + var(--dfv-scrollbar-width)) 6px 12px;
        border-top:1px solid #404040;
        font-size:12px; color:#999; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;
        box-sizing:border-box;
    }
    .dataframe-viewer .dataframe-footer .columns-hidden-notice {
        display:inline-flex; align-items:center; gap:6px;
        color:#d97706; font-size:12px;
    }
    .dataframe-viewer .dataframe-footer .columns-hidden-icon { width:16px; height:16px; flex-shrink:0; }
    .dataframe-viewer .dataframe-footer-rows { margin-left:auto; }
    .dataframe-viewer .dataframe-resize-corner {
        position:absolute;
        right:2px;
        bottom:2px;
        width:18px;
        height:18px;
        padding:0;
        margin:0;
        border:none;
        background:transparent;
        color:#777;
        cursor:ns-resize;
        display:inline-flex;
        align-items:flex-end;
        justify-content:flex-end;
        z-index:6;
        opacity:.9;
        touch-action:none;
    }
    .dataframe-viewer .dataframe-resize-corner:hover,
    .dataframe-viewer .dataframe-footer:hover .dataframe-resize-corner,
    .dataframe-viewer .dataframe-resize-corner.is-dragging {
        color:var(--moonstorm-dfv-accent, #8b9aff);
    }
    .dataframe-viewer .dataframe-resize-corner-icon {
        display:block;
        width:14px;
        height:14px;
        pointer-events:none;
    }
    .dataframe-viewer .dataframe-null { color:#666; font-style:italic; }
    /* Expandable complex objects (match dataframe tab viewer). */
    .dataframe-viewer .dataframe-table tbody td:has(.complex-value) {
        max-width: min(72ch, 60vw);
        overflow: visible;
        text-overflow: unset;
        white-space: normal;
        vertical-align: top;
    }
    .dataframe-viewer .complex-value { position:relative; min-width:12ch; }
    .dataframe-viewer .complex-toggle {
        display:inline-flex; align-items:flex-start; gap:6px;
        margin:0; padding:0; border:none; background:transparent;
        color: var(--moonstorm-text-secondary, var(--jp-ui-font-color2, #858585));
        font:inherit; font-weight:500; cursor:pointer; text-align:left;
    }
    .dataframe-viewer .complex-toggle:hover {
        color: var(--moonstorm-text, var(--jp-ui-font-color1, #cccccc));
    }
    .dataframe-viewer .complex-toggle:focus-visible {
        outline:2px solid var(--moonstorm-dfv-accent, #8b9aff);
        outline-offset:2px;
        border-radius:3px;
    }
    .dataframe-viewer .toggle-icon {
        display:inline-block; flex:0 0 auto;
        margin-top:0.2em;
        font-size:10px; line-height:1;
        color: var(--moonstorm-text-secondary, var(--jp-ui-font-color2, #858585));
        transition: transform 0.15s ease, color 0.12s ease;
    }
    .dataframe-viewer .complex-preview {
        flex:1 1 auto; min-width:0;
        font-style:italic; color:inherit;
    }
    .dataframe-viewer .complex-toggle:hover .toggle-icon {
        color: var(--moonstorm-text, var(--jp-ui-font-color1, #cccccc));
    }
    .dataframe-viewer .toggle-icon.expanded { transform:rotate(90deg); }
    .dataframe-viewer .complex-content {
        margin-top:8px; padding:8px; border-radius:4px;
        border-left:3px solid var(--moonstorm-border, var(--jp-border-color1, #3c3c3c));
        background: var(--moonstorm-cell-bg, var(--jp-layout-color1, #252525));
    }
    .dataframe-viewer .complex-json {
        margin:0; padding:0; max-height:280px; overflow:auto;
        background:transparent !important;
        color: var(--moonstorm-text, var(--jp-ui-font-color1, #d4d4d4));
        font-family: var(--jp-code-font-family, ui-monospace, monospace);
        font-size:12px; line-height:1.45; white-space:pre;
    }
    .dataframe-viewer .complex-json .json-key {
        color: var(--jp-mirror-editor-meta-color, #c586c0) !important;
    }
    .dataframe-viewer .complex-json .json-string {
        color: var(--jp-mirror-editor-string-color, #ce9178) !important;
    }
    .dataframe-viewer .complex-json .json-number {
        color: var(--jp-mirror-editor-number-color, #b5cea8) !important;
    }
    .dataframe-viewer .complex-json .json-boolean {
        color: var(--jp-mirror-editor-keyword-color, #569cd6) !important;
    }
    .dataframe-viewer .complex-json .json-null {
        color: var(--jp-mirror-editor-comment-color, #808080) !important;
    }
    .dataframe-viewer .dataframe-table pre:not(.complex-json) { background:#252525 !important; color:#d4d4d4 !important; margin:0; padding:0; }
    .dataframe-viewer .dataframe-table-container::-webkit-scrollbar { width:var(--dfv-scrollbar-width); height:var(--dfv-scrollbar-width); }
    .dataframe-viewer .dataframe-table-container::-webkit-scrollbar-track { background:#2d2d2d; }
    .dataframe-viewer .dataframe-table-container::-webkit-scrollbar-thumb { background:#555; border-radius:4px; }
    .dataframe-viewer .dataframe-table-container::-webkit-scrollbar-thumb:hover { background:#777; }
    .dataframe-viewer .complex-json::-webkit-scrollbar { width:6px; }
    .dataframe-viewer .complex-json::-webkit-scrollbar-track { background:#2d2d2d; }
    .dataframe-viewer .complex-json::-webkit-scrollbar-thumb { background:#555; border-radius:3px; }
    .dataframe-viewer td.dfv-cell-editable {
        cursor:text; min-width:2ch; vertical-align:middle;
        text-decoration:none !important;
        outline:none;
        box-shadow:none;
    }
    .dataframe-viewer td.dfv-cell-editable:focus,
    .dataframe-viewer td.dfv-cell-editable:focus-visible {
        outline:none;
    }
    .dataframe-viewer td.dfv-cell-editable.dfv-empty-string,
    .dataframe-viewer span.dfv-cell-text.dfv-empty-string {
        box-shadow:none !important;
        text-decoration:none !important;
        background:transparent;
    }
    .dataframe-viewer td.dfv-cell-draft {
        box-shadow: inset 0 0 0 2px color-mix(in srgb, var(--moonstorm-dfv-accent, #8b9aff) 65%, transparent);
        background: color-mix(in srgb, var(--moonstorm-dfv-accent, #8b9aff) 12%, transparent);
    }
    .dataframe-viewer td.dfv-cell-pk-locked {
        cursor: not-allowed;
        opacity: 0.72;
        background: color-mix(in srgb, #888 10%, transparent);
    }
    .dataframe-viewer td.dfv-cell-invalid {
        box-shadow: inset 0 0 0 2px color-mix(in srgb, #f87171 80%, transparent);
        background: color-mix(in srgb, #f87171 14%, transparent);
    }
    .dataframe-viewer td.dfv-cell-draft.dfv-cell-invalid {
        box-shadow: inset 0 0 0 2px color-mix(in srgb, #f87171 85%, transparent);
    }
    .dataframe-viewer .dfv-dialog-error-list {
        margin:0; padding:0 0 0 18px; font-size:12px; line-height:1.5; color:#e8e8e8;
    }
    .dataframe-viewer.light-mode .dfv-dialog-error-list { color:#333; }
    .dataframe-viewer .dfv-edit-bar {
        display:flex; flex-wrap:wrap; align-items:center; gap:8px;
        padding:8px 12px; border-top:1px solid rgba(255,255,255,.12);
        background:rgba(0,0,0,.25); font-size:12px;
    }
    .dataframe-viewer .dfv-edit-bar-label { flex:1 1 160px; opacity:.9; }
    .dataframe-viewer .dfv-edit-bar button {
        font:inherit; padding:4px 10px; border-radius:6px; border:1px solid rgba(255,255,255,.25);
        background:rgba(255,255,255,.12); color:inherit; cursor:pointer;
    }
    .dataframe-viewer .dfv-edit-bar button:hover { background:rgba(255,255,255,.22); }
    .dataframe-viewer .dfv-dialog-body {
        min-height:0; max-height:none; padding:12px 16px 8px;
    }
    .dataframe-viewer .dfv-dialog-message {
        margin:0 0 12px; font-size:12px; line-height:1.45; color:#d0d0d0;
    }
    .dataframe-viewer .dfv-code-format-toggle {
        display:inline-flex; gap:0; margin:0 0 10px;
        border-radius:8px; border:1px solid rgba(255,255,255,.22);
        overflow:hidden;
    }
    .dataframe-viewer .dfv-code-format-btn {
        font:inherit; font-size:11px; font-weight:500;
        padding:5px 14px; border:none; background:rgba(255,255,255,.08);
        color:inherit; cursor:pointer;
    }
    .dataframe-viewer .dfv-code-format-btn + .dfv-code-format-btn {
        border-left:1px solid rgba(255,255,255,.22);
    }
    .dataframe-viewer .dfv-code-format-btn.active {
        background: color-mix(in srgb, var(--moonstorm-dfv-accent, #8b9aff) 40%, transparent);
    }
    .dataframe-viewer .dfv-code-format-btn:hover:not(.active) {
        background:rgba(255,255,255,.14);
    }
    .dataframe-viewer .dfv-dialog-field {
        display:block; font-size:11px; margin-bottom:6px; color:#aaa;
    }
    .dataframe-viewer .dfv-dialog-select {
        width:100%; box-sizing:border-box; font:inherit; font-size:12px;
        padding:6px 8px; border-radius:6px; border:1px solid #555;
        background:#1a1a1a; color:#e8e8e8;
    }
    .dataframe-viewer .dfv-dialog-code {
        width:100%; box-sizing:border-box; min-height:220px; max-height:min(50vh, 360px);
        margin:0; padding:10px 12px; border-radius:8px; border:1px solid #555;
        background:#141414; color:#e8e8e8; resize:vertical;
        font-family: var(--jp-code-font-family, ui-monospace, monospace);
        font-size:11px; line-height:1.45;
    }
    .dataframe-viewer .dfv-dialog-footer {
        display:flex; flex-wrap:wrap; justify-content:flex-end; gap:8px;
        padding:10px 12px 12px; border-top:1px solid #404040;
    }
    .dataframe-viewer .dfv-dialog-btn {
        font:inherit; font-size:12px; padding:6px 12px; border-radius:6px;
        border:1px solid rgba(255,255,255,.25); background:rgba(255,255,255,.1);
        color:inherit; cursor:pointer;
    }
    .dataframe-viewer .dfv-dialog-btn:hover { background:rgba(255,255,255,.18); }
    .dataframe-viewer .dfv-dialog-btn-primary {
        font-weight:600;
        border-color: color-mix(in srgb, var(--moonstorm-dfv-accent, #8b9aff) 70%, #fff);
        background: color-mix(in srgb, var(--moonstorm-dfv-accent, #8b9aff) 35%, transparent);
    }
    .dataframe-viewer.light-mode .dfv-dialog-message { color:#444; }
    .dataframe-viewer.light-mode .dfv-code-format-toggle { border-color:#ccc; }
    .dataframe-viewer.light-mode .dfv-code-format-btn {
        background:#f0f0f0; color:#333;
    }
    .dataframe-viewer.light-mode .dfv-code-format-btn + .dfv-code-format-btn {
        border-left-color:#ccc;
    }
    .dataframe-viewer.light-mode .dfv-code-format-btn.active {
        background: color-mix(in srgb, var(--moonstorm-dfv-accent, #6b7fd7) 25%, #fff);
    }
    .dataframe-viewer.light-mode .dfv-dialog-field { color:#666; }
    .dataframe-viewer.light-mode .dfv-dialog-select {
        background:#fff; color:#222; border-color:#ccc;
    }
    .dataframe-viewer.light-mode .dfv-dialog-code {
        background:#fafafa; color:#222; border-color:#ccc;
    }
    .dataframe-viewer.light-mode .dfv-dialog-footer { border-top-color:#e0e0e0; }
    .dataframe-viewer.light-mode .dfv-dialog-btn {
        border-color:#ccc; background:#f5f5f5; color:#333;
    }
    .dataframe-viewer.light-mode .dfv-dialog-btn:hover { background:#ebebeb; }`;
export const DATAFRAME_VIEWER_STYLE_ID = 'moonstorm-dataframe-viewer-styles';
