import {
  DATAFRAME_VIEWER_CSS,
  DATAFRAME_VIEWER_STYLE_ID
} from './dataframeViewerCss.js';

/** Ensure shared DF viewer CSS is present in a document (Lab page or output iframe). */
export function ensureDataframeViewerStyles(doc: Document = document): void {
  if (!doc?.head) {
    return;
  }
  let style = doc.getElementById(
    DATAFRAME_VIEWER_STYLE_ID
  ) as HTMLStyleElement | null;
  if (!style) {
    style = doc.createElement('style');
    style.id = DATAFRAME_VIEWER_STYLE_ID;
    style.setAttribute('data-moonstorm-dfv-shared', 'true');
    doc.head.appendChild(style);
  }
  style.textContent = DATAFRAME_VIEWER_CSS;
}

export function removeDataframeViewerStyles(doc: Document = document): void {
  doc.getElementById(DATAFRAME_VIEWER_STYLE_ID)?.remove();
}

const IFRAME_STYLE_WATCH = 'data-moonstorm-dfv-style-watch';

function injectIntoIframe(iframe: HTMLIFrameElement): void {
  try {
    const doc = iframe.contentDocument;
    if (!doc?.body) {
      return;
    }
    if (doc.querySelector('.dataframe-viewer')) {
      ensureDataframeViewerStyles(doc);
    }
  } catch {
    // Ignore cross-origin iframe access errors.
  }
}

/**
 * Inject shared styles into output iframes that host dataframe viewers.
 * When `targets` is set, only those iframes are processed (mutation batch).
 */
export function ensureDataframeViewerStylesInOutputs(
  root: ParentNode = document,
  targets?: Iterable<HTMLIFrameElement>
): void {
  ensureDataframeViewerStyles(document);

  const iframes =
    targets ??
    root.querySelectorAll('iframe.jp-mod-isolated, iframe.jp-OutputArea-output');

  for (const node of iframes) {
    const iframe = node as HTMLIFrameElement;
    if (!iframe.getAttribute(IFRAME_STYLE_WATCH)) {
      iframe.setAttribute(IFRAME_STYLE_WATCH, 'true');
      iframe.addEventListener('load', () => injectIntoIframe(iframe));
    }
    injectIntoIframe(iframe);
  }
}
