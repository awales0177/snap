"""IPython integration for Moonstorm JupyterLab.

Theme comm, SQL magics, and pretty dataframe HTML formatters (pandas / PySpark).
"""

from __future__ import annotations

import warnings

from moonstorm_jup_theme.dataframe_viewer import (
    ensure_spark_display_formatters,
    register_display_formatters,
)
from moonstorm_jup_theme.sql_magic import register_sql_magic
from moonstorm_jup_theme.theme_comm import register_theme_comm


def pin_pyspark_python() -> str:
    """Point PySpark workers at the kernel Python (avoids Homebrew python3 mismatch)."""
    import os
    import sys

    py = sys.executable
    os.environ.setdefault("PYSPARK_PYTHON", py)
    os.environ.setdefault("PYSPARK_DRIVER_PYTHON", py)
    return py


def load_ipython_extension(ipython) -> None:
    """Register Moonstorm theme comm, %%sql magic, and dataframe viewers."""
    pin_pyspark_python()
    register_theme_comm(ipython)
    register_sql_magic(ipython)

    if not register_display_formatters(ipython):
        warnings.warn(
            "moonstorm-jup-theme: dataframe viewer was not registered in this kernel.",
            stacklevel=2,
        )
    try:
        ensure_spark_display_formatters(ipython)
    except Exception:  # noqa: BLE001
        pass


def unload_ipython_extension(_ipython) -> None:
    """No-op unload hook for IPython."""
