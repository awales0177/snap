"""
Custom DataFrame viewer with rounded corners and scrolling for Jupyter notebooks.
Supports pandas and PySpark DataFrames with expandable complex types.
"""

from __future__ import annotations

import html as _html
import io
import json
import re
import sys
import traceback
import uuid
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_COMPLEX_TYPE_NAMES = frozenset({"StructType", "ArrayType", "MapType"})

_COL_MIN_PX         = 80
_COL_MAX_PX         = 500
_COL_SAMPLE_ROWS    = 10
_COL_MAX_SAMPLE_LEN = 80   # chars — stops huge blobs from driving column width
_PX_PER_CHAR_HEADER = 8
_PX_PER_CHAR_VALUE  = 7
_COL_PADDING        = 24
# Sort-indicator gutter in th (must fit beside the column name).
_COL_NAME_SORT_GUTTER_PX = 12
_PANEL_HEIGHT_PX    = 260  # default table panel height (vertically resizable)
_PANEL_MIN_HEIGHT_PX = 120
_PANEL_MAX_HEIGHT_PX = 960  # CSS also caps at 85vh
_SCROLLBAR_WIDTH_PX = 8    # must match ::-webkit-scrollbar width/height

# FIX (Perf #4): cap max_rows to prevent accidental driver OOM
_MAX_ROWS_HARD_CAP  = 10_000
_DEFAULT_MAX_ROWS   = 100


def _default_max_rows() -> int:
    """Default dataframe preview row cap for Kubeflow / cluster notebooks."""
    return _DEFAULT_MAX_ROWS

# ---------------------------------------------------------------------------
# One-time stylesheet injection sentinel
# FIX (Perf #3): CSS is only emitted once per kernel session, not per call.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# SVG icons
# ---------------------------------------------------------------------------

def _thm_svg(css_class: str, title: str, body: str) -> str:
    attrs = (
        f'class="{css_class}" title="{title}" '
        'style="display:inline-block;vertical-align:middle" '
        'xmlns="http://www.w3.org/2000/svg" width="14" height="14" '
        'viewBox="0 0 24 24" fill="none" stroke="#000000" '
        'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"'
    )
    return f"<svg {attrs}>{body}</svg>"


ICON_COLUMNS = _thm_svg("column-selector-icon", "Column selector",
    '<path d="M11 5h10M11 9h5" stroke-linecap="round" stroke-linejoin="round"/>'
    '<rect width="4" height="4" x="3" y="5" rx="1" stroke-linecap="round" stroke-linejoin="round"/>'
    '<path d="M11 15h10m-10 4h5" stroke-linecap="round" stroke-linejoin="round"/>'
    '<rect width="4" height="4" x="3" y="15" rx="1" stroke-linecap="round" stroke-linejoin="round"/>')

# From src/icons/minus.svg (filled; header btn inverts like columns).
ICON_MINIMIZE = (
    '<svg class="dataframe-minimize-icon" title="Minimize" '
    'style="display:inline-block;vertical-align:middle" '
    'xmlns="http://www.w3.org/2000/svg" width="14" height="14" '
    'viewBox="0 -12 32 32" aria-hidden="true">'
    '<g transform="translate(-412 -1047)" fill="#000000">'
    '<path d="M440 1053H416c-1.104 0-2-.9-2-2s.896-2 2-2h24c1.104 0 2 .9 2 2s'
    '-.896 2-2 2zm0-6H416c-2.209 0-4 1.79-4 4s1.791 4 4 4h24c2.209 0 4-1.79 '
    '4-4s-1.791-4-4-4z"/>'
    '</g></svg>'
)

# Same warning glyph as cell/output collapse banners (currentColor).
ICON_MINIMIZE_BANNER = (
    '<svg class="dataframe-minimized-icon" viewBox="0 0 24 24" fill="none" '
    'xmlns="http://www.w3.org/2000/svg" width="14" height="14" aria-hidden="true">'
    '<path opacity="0.4" d="M21.0802 8.58003V15.42C21.0802 16.54 20.4802 17.58 '
    '19.5102 18.15L13.5702 21.58C12.6002 22.14 11.4002 22.14 10.4202 21.58L4.48016 '
    '18.15C3.51016 17.59 2.91016 16.55 2.91016 15.42V8.58003C2.91016 7.46003 '
    '3.51016 6.41999 4.48016 5.84999L10.4202 2.42C11.3902 1.86 12.5902 1.86 '
    '13.5702 2.42L19.5102 5.84999C20.4802 6.41999 21.0802 7.45003 21.0802 '
    '8.58003Z" fill="currentColor"/>'
    '<path d="M12 13.75C11.59 13.75 11.25 13.41 11.25 13V7.75C11.25 7.34 11.59 7 '
    '12 7C12.41 7 12.75 7.34 12.75 7.75V13C12.75 13.41 12.41 13.75 12 13.75Z" '
    'fill="currentColor"/>'
    '<path d="M12 17.2499C11.87 17.2499 11.74 17.2198 11.62 17.1698C11.49 17.1198 '
    '11.39 17.0499 11.29 16.9599C11.2 16.8599 11.13 16.7499 11.07 16.6299C11.02 '
    '16.5099 11 16.3799 11 16.2499C11 15.9899 11.1 15.7298 11.29 15.5398C11.39 '
    '15.4498 11.49 15.3799 11.62 15.3299C11.99 15.1699 12.43 15.2598 12.71 '
    '15.5398C12.8 15.6398 12.87 15.7399 12.92 15.8699C12.97 15.9899 13 16.1199 '
    '13 16.2499C13 16.3799 12.97 16.5099 12.92 16.6299C12.87 16.7499 12.8 '
    '16.8599 12.71 16.9599C12.52 17.1499 12.27 17.2499 12 17.2499Z" '
    'fill="currentColor"/>'
    '</svg>'
)

# Restore — table glyph from src/icons/table.svg (currentColor for tray).
ICON_MAXIMIZE = (
    '<svg class="dataframe-maximize-icon" viewBox="0 0 24 24" fill="none" '
    'xmlns="http://www.w3.org/2000/svg" width="14" height="14" aria-hidden="true">'
    '<path d="M12 10V20M3 15L21 15M3 10H21M6.2 20H17.8C18.9201 20 19.4802 20 '
    '19.908 19.782C20.2843 19.5903 20.5903 19.2843 20.782 18.908C21 18.4802 '
    '21 17.9201 21 16.8V7.2C21 6.0799 21 5.51984 20.782 5.09202C20.5903 '
    '4.71569 20.2843 4.40973 19.908 4.21799C19.4802 4 18.9201 4 17.8 4H6.2C5.0799 '
    '4 4.51984 4 4.09202 4.21799C3.71569 4.40973 3.40973 4.71569 3.21799 '
    '5.09202C3 5.51984 3 6.07989 3 7.2V16.8C3 17.9201 3 18.4802 3.21799 '
    '18.908C3.40973 19.2843 3.71569 19.5903 4.09202 19.782C4.51984 20 5.07989 '
    '20 6.2 20Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" '
    'stroke-linejoin="round"/>'
    '</svg>'
)

# Open-in-tab for the minimized tray (currentColor, not inverted header black).
ICON_OPEN_TAB_TRAY = (
    '<svg class="dataframe-open-tab-icon" viewBox="0 0 24 24" '
    'xmlns="http://www.w3.org/2000/svg" width="14" height="14" aria-hidden="true">'
    '<path fill="currentColor" fill-rule="evenodd" d="M5,2 L7,2 C7.55228475,2 8,2.44771525 '
    '8,3 C8,3.51283584 7.61395981,3.93550716 7.11662113,3.99327227 L7,4 L5,4 '
    'C4.48716416,4 4.06449284,4.38604019 4.00672773,4.88337887 L4,5 L4,19 '
    'C4,19.5128358 4.38604019,19.9355072 4.88337887,19.9932723 L5,20 L19,20 '
    'C19.5128358,20 19.9355072,19.6139598 19.9932723,19.1166211 L20,19 L20,17 '
    'C20,16.4477153 20.4477153,16 21,16 C21.5128358,16 21.9355072,16.3860402 '
    '21.9932723,16.8833789 L22,17 L22,19 C22,20.5976809 20.75108,21.9036609 '
    '19.1762728,21.9949073 L19,22 L5,22 C3.40231912,22 2.09633912,20.75108 '
    '2.00509269,19.1762728 L2,19 L2,5 C2,3.40231912 3.24891996,2.09633912 '
    '4.82372721,2.00509269 L5,2 L7,2 L5,2 Z M21,2 L21.081,2.003 L21.2007258,'
    '2.02024007 L21.3121425,2.04973809 L21.4232215,2.09367336 L21.5207088,'
    '2.14599545 L21.6167501,2.21278596 L21.7071068,2.29289322 L21.8036654,'
    '2.40469339 L21.8753288,2.5159379 L21.9063462,2.57690085 L21.9401141,'
    '2.65834962 L21.9641549,2.73400703 L21.9930928,2.8819045 L22,3 L22,9 '
    'C22,9.55228475 21.5522847,10 21,10 C20.4477153,10 20,9.55228475 20,9 '
    'L20,5.414 L13.7071068,11.7071068 C13.3466228,12.0675907 12.7793918,'
    '12.0953203 12.3871006,11.7902954 L12.2928932,11.7071068 C11.9324093,'
    '11.3466228 11.9046797,10.7793918 12.2097046,10.3871006 L12.2928932,'
    '10.2928932 L18.584,4 L15,4 C14.4477153,4 14,3.55228475 14,3 C14,'
    '2.44771525 14.4477153,2 15,2 L21,2 Z"/>'
    '</svg>'
)

# From src/icons/stacked.svg (filled; header btn inverts like columns).
ICON_SPLIT = (
    '<svg class="dataframe-split-icon" title="Separate viewers" '
    'style="display:inline-block;vertical-align:middle" '
    'xmlns="http://www.w3.org/2000/svg" width="11" height="11" '
    'viewBox="0 0 16 16" aria-hidden="true" fill="#000000">'
    '<path d="M3 0h10a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V2a2 2 0 0 1 '
    '2-2zm0 1a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H3zm0 '
    '8h10a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2zm0 1a1 1 '
    '0 0 0-1 1v3a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1H3z"/>'
    '</svg>'
)

# From src/icons/merge.svg (filled; header btn inverts like columns).
ICON_MERGE = (
    '<svg class="dataframe-merge-icon" title="Merge into one viewer" '
    'style="display:inline-block;vertical-align:middle" '
    'xmlns="http://www.w3.org/2000/svg" width="16" height="16" '
    'viewBox="0 0 100 100" aria-hidden="true" fill="#000000">'
    '<path d="M70.5,72.5c-7-3.4-12-9.4-14.5-16.3c-1-2.6-1.6-5.3-1.9-7.9v-4.4h13.6'
    'c1.1,0,1.7-1.2,1-2.2L51,20.5c-0.6-0.8-2-0.8-2.5,0L31.2,41.7c-0.6,0.8,0,2.2,1,'
    '2.2h13.7c0,1.9,0,4.3,0,4.3v0.1l0,0c-0.3,2.7-1,5.5-1.9,7.9c-2.6,6.8-7.5,12.9-'
    '14.5,16.3c-1,0.4-1.4,1.6-1,2.6l1.6,3.8c0.5,1.1,1.6,1.4,2.7,0.8c7.6-3.6,13.5-'
    '9.4,17.2-16.2c3.7,6.9,9.6,12.6,17.3,16.2c1.1,0.5,2.2,0.4,2.7-0.8l1.6-3.8C72,'
    '74.1,71.5,72.9,70.5,72.5z"/>'
    '</svg>'
)

# Pencil (stroke; header btn inverts like column selector / open-tab).
ICON_ROW_EDIT = _thm_svg(
    "dataframe-row-edit-icon",
    "Edit rows",
    '<path d="M12 20h9"/>'
    '<path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>',
)

ICON_OPEN_TAB = (
    '<svg class="dataframe-open-tab-icon" title="Open in tab" '
    'style="display:inline-block;vertical-align:middle" '
    'xmlns="http://www.w3.org/2000/svg" width="14" height="14" '
    'viewBox="0 0 24 24" aria-hidden="true">'
    '<path fill="#000000" fill-rule="evenodd" d="M5,2 L7,2 C7.55228475,2 8,2.44771525 '
    '8,3 C8,3.51283584 7.61395981,3.93550716 7.11662113,3.99327227 L7,4 L5,4 '
    'C4.48716416,4 4.06449284,4.38604019 4.00672773,4.88337887 L4,5 L4,19 '
    'C4,19.5128358 4.38604019,19.9355072 4.88337887,19.9932723 L5,20 L19,20 '
    'C19.5128358,20 19.9355072,19.6139598 19.9932723,19.1166211 L20,19 L20,17 '
    'C20,16.4477153 20.4477153,16 21,16 C21.5128358,16 21.9355072,16.3860402 '
    '21.9932723,16.8833789 L22,17 L22,19 C22,20.5976809 20.75108,21.9036609 '
    '19.1762728,21.9949073 L19,22 L5,22 C3.40231912,22 2.09633912,20.75108 '
    '2.00509269,19.1762728 L2,19 L2,5 C2,3.40231912 3.24891996,2.09633912 '
    '4.82372721,2.00509269 L5,2 L7,2 L5,2 Z M21,2 L21.081,2.003 L21.2007258,'
    '2.02024007 L21.3121425,2.04973809 L21.4232215,2.09367336 L21.5207088,'
    '2.14599545 L21.6167501,2.21278596 L21.7071068,2.29289322 L21.8036654,'
    '2.40469339 L21.8753288,2.5159379 L21.9063462,2.57690085 L21.9401141,'
    '2.65834962 L21.9641549,2.73400703 L21.9930928,2.8819045 L22,3 L22,9 '
    'C22,9.55228475 21.5522847,10 21,10 C20.4477153,10 20,9.55228475 20,9 '
    'L20,5.414 L13.7071068,11.7071068 C13.3466228,12.0675907 12.7793918,'
    '12.0953203 12.3871006,11.7902954 L12.2928932,11.7071068 C11.9324093,'
    '11.3466228 11.9046797,10.7793918 12.2097046,10.3871006 L12.2928932,'
    '10.2928932 L18.584,4 L15,4 C14.4477153,4 14,3.55228475 14,3 C14,'
    '2.44771525 14.4477153,2 15,2 L21,2 Z"/>'
    '</svg>'
)

# From src/icons/corner-bottom-right.svg — footer drag affordance.
ICON_RESIZE_CORNER = (
    '<svg class="dataframe-resize-corner-icon" viewBox="0 0 15 15" '
    'xmlns="http://www.w3.org/2000/svg" width="14" height="14" '
    'aria-hidden="true" focusable="false">'
    '<path fill-rule="evenodd" clip-rule="evenodd" fill="currentColor" '
    'd="M5.12263 12H5.1H3.5C3.22386 12 3 11.7761 3 11.5C3 11.2239 3.22386 11 '
    '3.5 11H5.1C6.22836 11 7.04455 10.9996 7.68648 10.9472C8.32256 10.8952 '
    '8.74338 10.7946 9.08897 10.6185C9.74753 10.283 10.283 9.74753 10.6185 '
    '9.08897C10.7946 8.74338 10.8952 8.32256 10.9472 7.68648C10.9996 7.04455 '
    '11 6.22836 11 5.1V3.5C11 3.22386 11.2239 3 11.5 3C11.7761 3 12 3.22386 '
    '12 3.5V5.1V5.12263C12 6.22359 12 7.08052 11.9438 7.76791C11.8868 8.46584 '
    '11.7694 9.0329 11.5095 9.54296C11.0781 10.3897 10.3897 11.0781 9.54296 '
    '11.5095C9.0329 11.7694 8.46584 11.8868 7.76791 11.9438C7.08052 12 '
    '6.22359 12 5.12263 12Z"/>'
    '</svg>'
)

ICON_LAYERS = (
    '<svg class="column-selector-layers-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<path d="M20 10L12 5L4 10L12 15L20 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    '<path d="M20 14L12 19L4 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    '</svg>'
)
ICON_SORT_UP = (
    '<svg class="sort-icon-svg" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<path d="M5 15L10 9.84985C10.2563 9.57616 10.566 9.35814 10.9101 9.20898C11.2541 9.05983 11.625 8.98291 12 8.98291C12.375 8.98291 12.7459 9.05983 13.0899 9.20898C13.434 9.35814 13.7437 9.57616 14 9.84985L19 15" '
    'stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'
    '</svg>'
)
ICON_SORT_DOWN = (
    '<svg class="sort-icon-svg" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<path d="M19 9L14 14.1599C13.7429 14.4323 13.4329 14.6493 13.089 14.7976C12.7451 14.9459 12.3745 15.0225 12 15.0225C11.6255 15.0225 11.2549 14.9459 10.9109 14.7976C10.567 14.6493 10.2571 14.4323 10 14.1599L5 9" '
    'stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'
    '</svg>'
)
ICON_WARNING = (
    '<svg class="columns-hidden-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<path d="M12 15H12.01M12 12V9M4.98207 19H19.0179C20.5615 19 21.5233 17.3256 20.7455 15.9923L13.7276 3.96153C12.9558 2.63852 11.0442 2.63852 10.2724 3.96153L3.25452 15.9923C2.47675 17.3256 3.43849 19 4.98207 19Z" '
    'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    '</svg>'
)
ICON_LAYERS_DESELECTED = (
    '<svg class="column-selector-layers-icon column-selector-layers-deselected" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<path d="M4 4L20 20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
    '<path fill-rule="evenodd" clip-rule="evenodd" d="M7.32711 6.74132L3.47001 9.152C3.17763 9.33474 3.00001 9.65521 3.00001 10C3.00001 10.3448 3.17763 10.6653 3.47001 10.848L11.47 15.848C11.7943 16.0507 12.2057 16.0507 12.53 15.848L14.9323 14.3465L13.481 12.8952L12 13.8208L5.88681 10L8.77849 8.1927L7.32711 6.74132ZM15.2215 11.8073L18.1132 10L12 6.17925L10.5191 7.10484L9.06768 5.65346L11.47 4.152C11.7943 3.94933 12.2057 3.94933 12.53 4.152L20.53 9.152C20.8224 9.33474 21 9.65521 21 10C21 10.3448 20.8224 10.6653 20.53 10.848L16.6729 13.2587L15.2215 11.8073ZM15.9425 15.3567L12 17.8208L4.53001 13.152C4.06167 12.8593 3.44472 13.0017 3.15201 13.47C2.8593 13.9383 3.00168 14.5553 3.47001 14.848L11.47 19.848C11.7943 20.0507 12.2057 20.0507 12.53 19.848L17.3939 16.8081L15.9425 15.3567ZM19.1344 15.7202L17.6831 14.2688L19.47 13.152C19.9383 12.8593 20.5553 13.0017 20.848 13.47C21.1407 13.9383 20.9983 14.5553 20.53 14.848L19.1344 15.7202Z" fill="currentColor"/>'
    '</svg>'
)

try:
    from IPython.display import HTML, display as _ipython_display
    IPYTHON_AVAILABLE = True
except ImportError:
    IPYTHON_AVAILABLE = False


# ---------------------------------------------------------------------------
# Internal data structures
# ---------------------------------------------------------------------------

@dataclass
class _ViewerIds:
    uid:    str
    viewer: str
    table:  str
    col_sel: str
    col_sel_modal: str
    open_tab_btn: str
    edit_btn: str
    minimize_btn: str
    footer: str


@dataclass
class _ColumnMeta:
    name:          str
    data_type:     object   # pyspark DataType
    type_str:      str
    display_dtype: str
    width_px:      int
    name_min_width_px: int


@dataclass
class _TableData:
    display_rows: list
    has_more:     bool
    # FIX (Design #1): removed redundant num_display field; use len(display_rows) directly.


@dataclass
class _BufferedSparkFrame:
    """Spark rows/schema captured while the driver session is still alive."""

    schema: object
    data: _TableData


class _SparkSchemaView:
    """Minimal df stand-in for column metadata from a stashed Spark schema."""

    def __init__(self, schema: object) -> None:
        self.schema = schema


# ---------------------------------------------------------------------------
# Step 1 — Validation
# ---------------------------------------------------------------------------

def _is_pandas_df(df) -> bool:
    try:
        import pandas as pd
    except ImportError:
        return False
    return isinstance(df, pd.DataFrame)


def _is_spark_df(df) -> bool:
    try:
        from pyspark.sql import DataFrame as SparkDataFrame

        if isinstance(df, SparkDataFrame):
            return True
    except ImportError:
        pass
    # Enterprise Gateway / late pyspark import: match by module path.
    cls = type(df)
    mod = getattr(cls, "__module__", "") or ""
    return (
        cls.__name__ == "DataFrame"
        and mod.startswith("pyspark.sql")
        and hasattr(df, "columns")
        and callable(getattr(df, "take", None))
    )


def _dataframe_engine(df) -> str:
    """Return 'pandas' or 'pyspark' for a validated dataframe."""
    if isinstance(df, _BufferedSparkFrame):
        return "pyspark"
    if _is_pandas_df(df):
        return "pandas"
    if _is_spark_df(df):
        return "pyspark"
    raise TypeError(
        "Expected a pandas or PySpark DataFrame, "
        f"got {type(df).__name__}"
    )


def _engine_version_label(engine: str) -> str:
    """Human-readable engine name + installed package version for tooltips."""
    if engine == "pandas":
        try:
            import pandas as pd

            return f"pandas {pd.__version__}"
        except Exception:
            return "pandas"
    try:
        import pyspark

        return f"PySpark {pyspark.__version__}"
    except Exception:
        return "PySpark"


def _is_null(val) -> bool:
    if val is None:
        return True
    try:
        import pandas as pd

        # pd.isna(list/array) returns a mask; only scalar missing values are null.
        return bool(pd.isna(val))
    except (ImportError, ValueError, TypeError):
        return False


def _validate_inputs(df, max_rows: int) -> None:
    if isinstance(df, _BufferedSparkFrame):
        if max_rows < 0:
            raise ValueError(f"max_rows must be non-negative, got {max_rows}.")
        if max_rows > _MAX_ROWS_HARD_CAP:
            raise ValueError(
                f"max_rows={max_rows} exceeds the hard cap of {_MAX_ROWS_HARD_CAP:,}. "
                "Increase _MAX_ROWS_HARD_CAP if you intentionally need more rows."
            )
        return
    if not (_is_pandas_df(df) or _is_spark_df(df)):
        raise TypeError(
            "Expected a pandas or PySpark DataFrame, "
            f"got {type(df).__name__!r}."
        )
    if max_rows < 0:
        raise ValueError(f"max_rows must be non-negative, got {max_rows}.")
    # FIX (Perf #4): guard against accidental OOM from huge max_rows values.
    if max_rows > _MAX_ROWS_HARD_CAP:
        raise ValueError(
            f"max_rows={max_rows} exceeds the hard cap of {_MAX_ROWS_HARD_CAP:,}. "
            "Increase _MAX_ROWS_HARD_CAP if you intentionally need more rows."
        )


# ---------------------------------------------------------------------------
# Step 2 — Unique DOM IDs
# ---------------------------------------------------------------------------

def _build_viewer_ids() -> _ViewerIds:
    uid = uuid.uuid4().hex[:8]
    return _ViewerIds(
        uid=uid,
        viewer=f"dfv_{uid}",
        table=f"dft_{uid}",
        col_sel=f"dfcolsel_{uid}",
        col_sel_modal=f"dfcolselmodal_{uid}",
        open_tab_btn=f"dftabbtn_{uid}",
        edit_btn=f"dfeditbtn_{uid}",
        minimize_btn=f"dfminbtn_{uid}",
        footer=f"dffoot_{uid}",
    )


def _build_pane_ids(base: _ViewerIds, index: int) -> _ViewerIds:
    """Per-result IDs that share the outer viewer / minimize chrome."""
    uid = f"{base.uid}_{index}"
    return _ViewerIds(
        uid=uid,
        viewer=base.viewer,
        table=f"dft_{uid}",
        col_sel=f"dfcolsel_{uid}",
        col_sel_modal=f"dfcolselmodal_{uid}",
        open_tab_btn=f"dftabbtn_{uid}",
        edit_btn=f"dfeditbtn_{uid}",
        minimize_btn=base.minimize_btn,
        footer=f"dffoot_{uid}",
    )


def is_displayable_dataframe(df) -> bool:
    """True when ``df`` can be rendered in the Moonstorm dataframe viewer."""
    try:
        if not (_is_pandas_df(df) or _is_spark_df(df)):
            return False
        columns = getattr(df, "columns", None)
        if columns is None:
            return False
        return len(list(columns)) > 0
    except Exception:
        return False


def _sql_result_tab_title(sql: str, max_len: int = 120) -> str:
    text = " ".join(sql.split())
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "…"


# ---------------------------------------------------------------------------
# Step 3 — Row collection
# ---------------------------------------------------------------------------

def _collect_rows_spark(df, max_rows: int) -> _TableData:
    rows = df.take(max_rows + 1)
    has_more = len(rows) > max_rows
    display_rows = rows[:max_rows]
    return _TableData(
        display_rows=display_rows,
        has_more=has_more,
    )


def _collect_rows_pandas(df, max_rows: int) -> _TableData:
    preview = df.head(max_rows + 1)
    has_more = len(preview) > max_rows
    display = preview.head(max_rows)
    display_rows = display.to_dict(orient="records")
    for row in display_rows:
        for key, value in list(row.items()):
            if _is_null(value):
                row[key] = None
    return _TableData(
        display_rows=display_rows,
        has_more=has_more,
    )


def _collect_rows(df, max_rows: int) -> _TableData:
    if _is_pandas_df(df):
        return _collect_rows_pandas(df, max_rows)
    return _collect_rows_spark(df, max_rows)


# ---------------------------------------------------------------------------
# Step 4 — Column metadata
# ---------------------------------------------------------------------------

def _infer_value_dtype_label(value) -> Optional[str]:
    """Map a Python cell value to a short dtype label."""
    if value is None or _is_null(value):
        return None
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int) and not isinstance(value, bool):
        return "int"
    if isinstance(value, float):
        return "float"
    if isinstance(value, str):
        return "string"
    if isinstance(value, (bytes, bytearray, memoryview)):
        return "bytes"
    if _has_as_dict(value) or isinstance(value, dict):
        return "struct"
    if isinstance(value, list):
        elem = _infer_array_element_label(value)
        if elem:
            return f"array<{elem}>"
        return "list"
    if isinstance(value, tuple):
        return "tuple"
    if isinstance(value, (set, frozenset)):
        return "set"
    try:
        import numpy as np

        if isinstance(value, np.ndarray):
            elem = _infer_array_element_label(value.tolist())
            if elem:
                return f"array<{elem}>"
            return "array"
    except ImportError:
        pass
    return None


def _has_as_dict(value) -> bool:
    return hasattr(value, "asDict") and callable(getattr(value, "asDict"))


def _row_to_dict(value) -> dict:
    try:
        return value.asDict(recursive=True)
    except TypeError:
        return value.asDict()


def _infer_element_dtype_label(value) -> Optional[str]:
    """Infer dtype label for a single array element."""
    if value is None or _is_null(value):
        return None
    if _has_as_dict(value) or isinstance(value, dict):
        return "struct"
    if isinstance(value, (list, tuple)):
        elem = _infer_array_element_label(list(value))
        return f"array<{elem}>" if elem else "array"
    if isinstance(value, (set, frozenset)):
        return "set"
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int) and not isinstance(value, bool):
        return "int"
    if isinstance(value, float):
        return "float"
    if isinstance(value, str):
        return "string"
    if isinstance(value, (bytes, bytearray, memoryview)):
        return "bytes"
    return None


def _infer_array_element_label(items) -> Optional[str]:
    labels: set[str] = set()
    for item in items:
        label = _infer_element_dtype_label(item)
        if label:
            labels.add(label)
    if not labels:
        return None
    if len(labels) == 1:
        return next(iter(labels))
    return "mixed"


def _to_json_safe(value):
    """Convert nested Python / Spark / pandas values into JSON-serializable data."""
    if value is None or _is_null(value):
        return None
    if _has_as_dict(value):
        return _to_json_safe(_row_to_dict(value))
    if isinstance(value, dict):
        return {str(k): _to_json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_json_safe(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return [_to_json_safe(v) for v in sorted(value, key=str)]
    try:
        import numpy as np

        if isinstance(value, np.ndarray):
            return _to_json_safe(value.tolist())
        if isinstance(value, np.generic):
            return value.item()
    except ImportError:
        pass
    try:
        import pandas as pd

        if isinstance(value, pd.Series):
            return _to_json_safe(value.tolist())
        if isinstance(value, pd.DataFrame):
            return _to_json_safe(value.to_dict(orient="records"))
        if isinstance(value, (pd.Timestamp, pd.Timedelta, pd.Interval)):
            return str(value)
    except ImportError:
        pass
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).decode("utf-8", errors="replace")
    if isinstance(value, (bool, int, float, str)):
        return value
    return str(value)


def _array_preview(raw: list, *, element_label: Optional[str] = None) -> str:
    count = len(raw)
    if element_label == "struct":
        suffix = "struct" if count == 1 else "structs"
        return f"Array[{count} {suffix}]"
    if element_label and element_label != "mixed":
        suffix = "item" if count == 1 else "items"
        return f"Array[{count} {suffix}]"
    suffix = "item" if count == 1 else "items"
    return f"Array[{count} {suffix}]"


def _infer_object_column_dtype(values) -> str:
    """Infer a display dtype for pandas object columns from sample values."""
    inferred: Optional[str] = None
    for value in values:
        label = _infer_value_dtype_label(value)
        if label is None:
            continue
        if inferred is None:
            inferred = label
        elif label != inferred:
            return "object"
    return inferred or "object"


def _format_header_dtype(
    data_type: object,
    type_str: str,
    *,
    sample_values: Optional[list] = None,
) -> str:
    """Short lowercase dtype label shown under each column name."""
    try:
        from pyspark.sql.types import DataType

        if isinstance(data_type, DataType):
            type_name = type(data_type).__name__
            if type_name == "StructType":
                return "struct"
            if type_name == "ArrayType":
                try:
                    from pyspark.sql.types import ArrayType

                    if isinstance(data_type, ArrayType):
                        elem_label = _format_header_dtype(
                            data_type.elementType,
                            str(data_type.elementType),
                        )
                        return f"array<{elem_label}>"
                except ImportError:
                    pass
                return "array"
            if type_name == "MapType":
                return "map"
            if type_name.endswith("Type"):
                return type_name[:-4].lower()
    except ImportError:
        pass

    label = str(type_str).strip().lower()
    if label.startswith("dtype(") and label.endswith(")"):
        label = label[6:-1].strip("'\"")

    if label == "boolean":
        return "bool"

    generic_object_labels = {"object", "mixed", "mixed-integer", "mixed-integer-float"}
    if label in generic_object_labels and sample_values is not None:
        inferred = _infer_object_column_dtype(sample_values)
        if inferred != "object":
            return inferred

    return label


def _header_name_min_width_px(name: str) -> int:
    """Minimum column width so the full header name is visible (not dtype)."""
    label = name or ""
    return max(
        _COL_MIN_PX,
        len(label) * _PX_PER_CHAR_HEADER + _COL_PADDING + _COL_NAME_SORT_GUTTER_PX,
    )


def _estimate_display_len(val) -> int:
    """
    FIX (Perf #2): Estimate the rendered string length of a value without
    building the full string. Short-circuits on known cheap types so that large
    structs/arrays don't pay the full str() cost just to measure width.
    """
    if val is None:
        return 4   # "null"
    if isinstance(val, bool):
        return 5   # "False" (worst case)
    if isinstance(val, (int, float)):
        # Fast path: avoids str() for common numeric types.
        return len(repr(val))
    if isinstance(val, str):
        return min(len(val), _COL_MAX_SAMPLE_LEN)
    # For complex / unknown types clamp at the sample limit immediately.
    return min(len(str(val)), _COL_MAX_SAMPLE_LEN)


def _get_column_metadata_spark(
    df,
    data: _TableData,
) -> List[_ColumnMeta]:
    metas: List[_ColumnMeta] = []
    for field_obj in df.schema.fields:
        name      = field_obj.name
        data_type = field_obj.dataType
        type_str  = str(data_type)
        display_dtype = _format_header_dtype(data_type, type_str)

        width = max(
            len(name),
            len(display_dtype),
        ) * _PX_PER_CHAR_HEADER + _COL_PADDING
        for row in data.display_rows[:_COL_SAMPLE_ROWS]:
            val = row[name]
            if val is not None:
                width = max(width, _estimate_display_len(val) * _PX_PER_CHAR_VALUE + _COL_PADDING)
        name_min = _header_name_min_width_px(name)
        width = max(name_min, min(width, _COL_MAX_PX))

        metas.append(_ColumnMeta(
            name=name,
            data_type=data_type,
            type_str=type_str,
            display_dtype=display_dtype,
            width_px=width,
            name_min_width_px=name_min,
        ))
    return metas


def _get_column_metadata_pandas(
    df,
    data: _TableData,
) -> List[_ColumnMeta]:
    metas: List[_ColumnMeta] = []
    for name in df.columns:
        dtype = df.dtypes[name]
        type_str = str(dtype)
        sample_values = [row.get(name) for row in data.display_rows[:_COL_SAMPLE_ROWS]]
        display_dtype = _format_header_dtype(
            dtype,
            type_str,
            sample_values=sample_values,
        )

        width = max(
            len(name),
            len(display_dtype),
        ) * _PX_PER_CHAR_HEADER + _COL_PADDING
        for row in data.display_rows[:_COL_SAMPLE_ROWS]:
            val = row.get(name)
            if val is not None:
                width = max(width, _estimate_display_len(val) * _PX_PER_CHAR_VALUE + _COL_PADDING)
        name_min = _header_name_min_width_px(name)
        width = max(name_min, min(width, _COL_MAX_PX))

        metas.append(_ColumnMeta(
            name=name,
            data_type=dtype,
            type_str=type_str,
            display_dtype=display_dtype,
            width_px=width,
            name_min_width_px=name_min,
        ))
    return metas


def _get_column_metadata(
    df,
    data: _TableData,
) -> List[_ColumnMeta]:
    if _is_pandas_df(df):
        return _get_column_metadata_pandas(df, data)
    return _get_column_metadata_spark(df, data)


# ---------------------------------------------------------------------------
# Step 5 — Cell formatting
# ---------------------------------------------------------------------------

def _is_complex_type(data_type) -> bool:
    """Prefer isinstance; fall back to name check if PySpark types unavailable or type is unknown."""
    try:
        from pyspark.sql import types as T
        if T is None:
            raise AttributeError("types module not available")
        if isinstance(data_type, (T.StructType, T.ArrayType, T.MapType)):
            return True
    except (ImportError, AttributeError):
        pass
    return type(data_type).__name__ in _COMPLEX_TYPE_NAMES


# FIX (Bug #1): sentinel strings for pandas object columns (dict/list).
_FORCE_ARRAY_DISPLAY = "__force_array__"
_FORCE_STRUCT_DISPLAY = "__force_struct__"
_FORCE_MAP_DISPLAY = "__force_map__"
_FORCE_SET_DISPLAY = "__force_set__"
_FORCE_TUPLE_DISPLAY = "__force_tuple__"
_FORCE_BYTES_DISPLAY = "__force_bytes__"

_JSON_TOKEN_RE = re.compile(
    r'("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?'
    r'|\b(true|false|null)\b'
    r'|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)'
)


def _json_token_class(token: str) -> str:
    if token.startswith('"'):
        return "json-key" if token.rstrip().endswith(":") else "json-string"
    if token in {"true", "false"}:
        return "json-boolean"
    if token == "null":
        return "json-null"
    return "json-number"


def _highlight_json_html(json_str: str) -> str:
    """Return HTML-safe JSON with VS Code-style token spans."""
    escaped = _html.escape(json_str, quote=False)

    def _replace(match: re.Match[str]) -> str:
        token = match.group(0)
        return f'<span class="{_json_token_class(token)}">{token}</span>'

    return _JSON_TOKEN_RE.sub(_replace, escaped)


def _format_tuple_literal(value) -> str:
    """Python-style tuple literal for display (parens, not JSON arrays)."""
    items = list(value) if value is not None else []
    if not items:
        return "()"
    encoded = [
        json.dumps(item, default=str, ensure_ascii=False)
        for item in items
    ]
    if len(encoded) == 1:
        return f"({encoded[0]},)"
    return f"({', '.join(encoded)})"


def _complex_type_name(data_type) -> str:
    """Map Spark / pandas sentinel types to a display handler name."""
    if data_type is _FORCE_ARRAY_DISPLAY:
        return "ArrayType"
    if data_type is _FORCE_STRUCT_DISPLAY:
        return "StructType"
    if data_type is _FORCE_MAP_DISPLAY:
        return "MapType"
    if data_type is _FORCE_SET_DISPLAY:
        return "SetType"
    if data_type is _FORCE_TUPLE_DISPLAY:
        return "TupleType"
    if data_type is _FORCE_BYTES_DISPLAY:
        return "BytesType"
    return type(data_type).__name__


def _truncate_complex_preview(text: str) -> str:
    """Single-line object preview for collapsed complex cells (matches tab viewer)."""
    compact = " ".join(str(text).split())
    if len(compact) > _COL_MAX_SAMPLE_LEN:
        return compact[:_COL_MAX_SAMPLE_LEN] + "…"
    return compact


def _compact_json(value) -> str:
    safe = _to_json_safe(value)
    return json.dumps(safe, ensure_ascii=False, separators=(",", ": "))


def _complex_cell_payload(value, data_type) -> tuple[str, str]:
    """Return (preview_text, json_or_literal_body) for complex cells."""
    type_name = _complex_type_name(data_type)

    if type_name == "StructType":
        raw = _to_json_safe(value)
        json_str = json.dumps(raw, indent=2, default=str, ensure_ascii=False)
        preview = _truncate_complex_preview(_compact_json(raw))
    elif type_name == "ArrayType":
        raw = _to_json_safe(value)
        if not isinstance(raw, list):
            raw = []
        json_str = json.dumps(raw, indent=2, default=str, ensure_ascii=False)
        preview = _truncate_complex_preview(_compact_json(raw))
    elif type_name == "MapType":
        raw = _to_json_safe(value)
        json_str = json.dumps(raw, indent=2, default=str, ensure_ascii=False)
        preview = _truncate_complex_preview(_compact_json(raw))
    elif type_name == "SetType":
        raw = _to_json_safe(value)
        if not isinstance(raw, list):
            raw = sorted(value, key=str) if value is not None else []
        json_str = json.dumps(raw, indent=2, default=str, ensure_ascii=False)
        preview = _truncate_complex_preview(_compact_json(raw))
    elif type_name == "TupleType":
        raw = _to_json_safe(value)
        if not isinstance(raw, list):
            raw = list(value) if value is not None else []
        json_str = _format_tuple_literal(raw)
        preview = _truncate_complex_preview(json_str)
    elif type_name == "BytesType":
        data = bytes(value) if value is not None else b""
        payload = {
            "length": len(data),
            "utf8": data.decode("utf-8", errors="replace"),
            "hex": data.hex(),
        }
        json_str = json.dumps(payload, indent=2, ensure_ascii=False)
        preview = _truncate_complex_preview(_compact_json(payload))
    else:
        raise ValueError(f"unsupported complex type: {type_name}")

    return preview, json_str


def _format_complex_cell(value, data_type, cell_id: str, uid: str) -> str:
    if value is None:
        return '<span class="dataframe-null">null</span>'

    type_name = _complex_type_name(data_type)
    try:
        preview, json_str = _complex_cell_payload(value, data_type)
    except Exception:
        json_str = str(value)
        preview = type_name

    # Defer syntax highlighting until expand — keeps MIME HTML small.
    raw_script = json_str.replace("</", "<\\/")
    return (
        f'<div class="complex-value">'
        f'<button type="button" class="complex-toggle" '
        f'data-dfv-cell-id="{cell_id}" aria-expanded="false">'
        f'<span class="toggle-icon" id="icon_{cell_id}" aria-hidden="true">'
        f'&#9654;</span>'
        f'<span class="complex-preview">{_html.escape(preview, quote=True)}</span>'
        f'</button>'
        f'<div class="complex-content" id="{cell_id}" style="display:none;" '
        f'data-dfv-lazy-json="1">'
        f'<script type="application/json" id="{cell_id}-raw">{raw_script}</script>'
        f'<pre class="complex-json"></pre>'
        f'</div>'
        f'</div>'
    )


def _format_simple_cell(value) -> str:
    if _is_null(value):
        return '<span class="dataframe-null dfv-cell-text">null</span>'
    if value == "":
        return (
            '<span class="dfv-cell-text dfv-empty-string" '
            'aria-label="empty string"></span>'
        )
    if isinstance(value, (list, tuple)):
        parts = []
        for item in value:
            if _is_null(item):
                parts.append("null")
            else:
                parts.append(_html.escape(str(item), quote=True))
        return ", ".join(parts)
    if isinstance(value, bool):
        text = _html.escape(str(value), quote=True)
        return f'<span class="dfv-cell-text">{text}</span>'
    text = _html.escape(str(value), quote=True)
    return f'<span class="dfv-cell-text">{text}</span>'


def _sort_attr_value(value) -> str:
    """HTML-attribute-safe sort key using html.escape(quote=True).

    Complex values use a short stable key (not a full JSON dump) so large
    nested cells do not inflate every ``<td>`` attribute.
    """
    if _is_null(value):
        return ""
    if isinstance(value, dict) or _has_as_dict(value):
        try:
            raw = value.asDict(recursive=False) if _has_as_dict(value) else value
            return _html.escape(f"map:{len(raw)}", quote=True)
        except Exception:
            return _html.escape("map", quote=True)
    if isinstance(value, (list, tuple)):
        return _html.escape(f"list:{len(value)}", quote=True)
    if isinstance(value, (set, frozenset)):
        return _html.escape(f"set:{len(value)}", quote=True)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return _html.escape(f"bytes:{len(value)}", quote=True)
    try:
        import numpy as np

        if isinstance(value, np.ndarray):
            return _html.escape(f"ndarray:{value.size}", quote=True)
    except ImportError:
        pass
    return _html.escape(str(value), quote=True)


def _complex_display_type(value, data_type) -> Optional[object]:
    if _is_complex_type(data_type):
        return data_type
    if isinstance(value, dict) or _has_as_dict(value):
        return _FORCE_STRUCT_DISPLAY
    if isinstance(value, list):
        return _FORCE_ARRAY_DISPLAY
    if isinstance(value, tuple):
        return _FORCE_TUPLE_DISPLAY
    if isinstance(value, (set, frozenset)):
        return _FORCE_SET_DISPLAY
    if isinstance(value, (bytes, bytearray, memoryview)):
        return _FORCE_BYTES_DISPLAY
    try:
        import numpy as np

        if isinstance(value, np.ndarray):
            return _FORCE_ARRAY_DISPLAY
    except ImportError:
        pass
    return None


# ---------------------------------------------------------------------------
# Step 6 — Footer row-count text
# ---------------------------------------------------------------------------

def _build_rows_text(data: _TableData, total_rows: Optional[int]) -> str:
    """Always shows how many rows are displayed; adds total when available."""
    # FIX (Design #1): use len(data.display_rows) instead of removed num_display field.
    n = len(data.display_rows)
    if data.has_more:
        if total_rows is not None:
            return f"showing {n:,} of {total_rows:,} rows"
        return f"showing first {n:,} rows"
    # All rows fit in the preview window
    if total_rows is not None:
        return f"{total_rows:,} rows"
    return f"{n:,} rows"


# ---------------------------------------------------------------------------
# Step 7 — CSS
# FIX (Perf #3): per-viewer CSS includes JSON token colors so highlighting
# survives cleared/re-rendered notebook output (no one-shot global inject).
# ---------------------------------------------------------------------------

def _render_css(ids: _ViewerIds) -> str:
    """Shared DF CSS is injected by the Lab extension (see style/dataframe-viewer.css).

    Per-output MIME HTML no longer embeds the ~22KB rule block. ``ids`` is
    retained for call-site compatibility.
    """
    del ids  # unused — styles are class-scoped under .dataframe-viewer
    return ""



# ---------------------------------------------------------------------------
# Step 8 — JavaScript
# FIX (Design #3): The JS is no longer one giant f-string. Instead, static JS
# blocks are plain strings and only the small dynamic sections (IDs, column
# count, filter keys) use f-string interpolation. This minimises the surface
# area where {{ / }} escaping can go wrong and makes the code far easier to
# read and edit.
# ---------------------------------------------------------------------------

# ── Static JS helpers (no viewer-specific IDs needed) ──────────────────────
# These are plain strings — no {{ }} escaping required.

_JS_TOGGLE_FN_TMPL = """\
    // ── Complex cell toggle (+ lazy JSON highlight on first expand) ───────
    // No inline onclick — CSP / sandboxed output iframes block it. Bind clicks
    // on the table and publish dfToggle_<uid> on window (deferred multi-pane
    // scripts run inside a binder closure, so globals are assigned explicitly).
    (function() {{
        var uid = '{uid}';
        var tableId = '{table_id}';
        var viewerId = '{viewer_id}';
        var toggleGlobal = 'dfToggle_' + uid;

        function moonstormHighlightJson(jsonStr) {{
            var re = /("(?:\\\\u[a-zA-Z0-9]{{4}}|\\\\[^u]|[^\\\\"])*"(?:\\s*:)?|\\b(?:true|false|null)\\b|-?\\d+(?:\\.\\d*)?(?:[eE][+-]?\\d+)?)/g;
            function esc(s) {{
                return String(s)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;');
            }}
            function tokenClass(token) {{
                if (token.charAt(0) === '"') {{
                    return /:\\s*$/.test(token) ? 'json-key' : 'json-string';
                }}
                if (token === 'true' || token === 'false') return 'json-boolean';
                if (token === 'null') return 'json-null';
                return 'json-number';
            }}
            var out = '';
            var last = 0;
            var m;
            var text = String(jsonStr == null ? '' : jsonStr);
            while ((m = re.exec(text)) !== null) {{
                out += esc(text.slice(last, m.index));
                var tok = m[0];
                out += '<span class="' + tokenClass(tok) + '">' + esc(tok) + '</span>';
                last = m.index + tok.length;
            }}
            out += esc(text.slice(last));
            return out;
        }}

        function dfToggle(cellId) {{
            var content = document.getElementById(cellId);
            var icon    = document.getElementById('icon_' + cellId);
            if (!content) return;
            var opening = content.style.display === 'none';
            if (opening && content.getAttribute('data-dfv-lazy-json') === '1') {{
                var pre = content.querySelector('pre.complex-json');
                var raw = document.getElementById(cellId + '-raw');
                if (pre && raw) {{
                    pre.innerHTML = moonstormHighlightJson(raw.textContent || '');
                }}
                content.removeAttribute('data-dfv-lazy-json');
            }}
            content.style.display = opening ? 'block' : 'none';
            if (icon) icon.classList.toggle('expanded', opening);
            var toggle = content.parentElement
                ? content.parentElement.querySelector('.complex-toggle')
                : null;
            if (toggle) toggle.setAttribute('aria-expanded', opening ? 'true' : 'false');
        }}

        window[toggleGlobal] = dfToggle;
        window['moonstormHighlightJson_' + uid] = moonstormHighlightJson;

        function activateToggle(toggle) {{
            if (!toggle) return;
            var cellId = toggle.getAttribute('data-dfv-cell-id');
            if (cellId) dfToggle(cellId);
        }}

        function bindComplexToggles(root) {{
            if (!root || root.getAttribute('data-dfv-complex-bound') === uid) return;
            root.setAttribute('data-dfv-complex-bound', uid);
            root.addEventListener('click', function(e) {{
                var toggle = e.target.closest('.complex-toggle');
                if (!toggle || !root.contains(toggle)) return;
                e.preventDefault();
                activateToggle(toggle);
            }});
            root.addEventListener('keydown', function(e) {{
                if (e.key !== 'Enter' && e.key !== ' ') return;
                var toggle = e.target.closest('.complex-toggle');
                if (!toggle || !root.contains(toggle)) return;
                e.preventDefault();
                activateToggle(toggle);
            }});
        }}

        var table = document.getElementById(tableId);
        if (table) bindComplexToggles(table);

        var viewer = document.getElementById(viewerId);
        if (viewer && viewer.__moonstormOnCleanup) {{
            viewer.__moonstormOnCleanup(function() {{
                try {{ delete window[toggleGlobal]; }} catch (err) {{}}
                try {{ delete window['moonstormHighlightJson_' + uid]; }} catch (err) {{}}
            }});
        }}
    }})();"""

# Column resize — static (no uid needed, scoped by table id placeholder {table_id})
# Shared cleanup registry so document listeners / observers cannot outlive the iframe.
_JS_TEARDOWN_TMPL = """\
    // ── Teardown registry (pagehide / unload) ────────────────────────────
    (function() {{
        var viewer = document.getElementById('{viewer_id}');
        if (!viewer) return;
        var cleanups = [];
        viewer.__moonstormOnCleanup = function(fn) {{
            if (typeof fn === 'function') cleanups.push(fn);
        }};
        function runCleanup() {{
            while (cleanups.length) {{
                try {{ cleanups.pop()(); }} catch (err) {{}}
            }}
        }};
        viewer.__moonstormCleanup = runCleanup;
        window.addEventListener('pagehide', runCleanup);
        window.addEventListener('unload', runCleanup);
        viewer.__moonstormOnCleanup(function() {{
            window.removeEventListener('pagehide', runCleanup);
            window.removeEventListener('unload', runCleanup);
        }});
    }})();"""

_JS_RESIZE_TMPL = """\
    // ── Column resize (colgroup — O(1) per column, not O(rows)) ───────────
    (function() {{
        var isResizing = false, colIdx = -1, startX = 0, startWidth = 0;
        var pendingX = 0, rafId = 0;
        var table = document.getElementById('{table_id}');
        var viewer = document.getElementById('{viewer_id}');
        if (!table) return;

        var colGroup = table.querySelector('colgroup');
        var colEls = colGroup ? Array.from(colGroup.children) : [];
        var thEls = Array.from(table.querySelectorAll('thead th'));

        function headerNameMinWidth(th) {{
            var fromAttr = parseInt(th.getAttribute('data-name-min-width'), 10);
            var floor = Number.isFinite(fromAttr) ? fromAttr : 80;
            var nameEl = th.querySelector('.column-header-name');
            if (!nameEl) return floor;
            var probe = document.createElement('span');
            probe.style.cssText =
                'position:absolute;left:-9999px;top:0;visibility:hidden;white-space:nowrap;';
            var cs = window.getComputedStyle(nameEl);
            probe.style.fontFamily = cs.fontFamily;
            probe.style.fontSize = cs.fontSize;
            probe.style.fontWeight = cs.fontWeight;
            probe.style.fontStyle = cs.fontStyle;
            probe.style.letterSpacing = cs.letterSpacing;
            probe.textContent = nameEl.textContent || '';
            document.body.appendChild(probe);
            var textW = probe.offsetWidth;
            probe.remove();
            var thPad =
                (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0);
            return Math.max(floor, Math.ceil(textW + thPad + 12));
        }}

        var minWidths = thEls.map(headerNameMinWidth);

        thEls.forEach(function(th, i) {{
            if (i >= thEls.length - 1) return;
            var handle = document.createElement('div');
            handle.className = 'resize-handle';
            th.appendChild(handle);
            handle.addEventListener('mousedown', function(e) {{
                e.preventDefault();
                isResizing = true;
                colIdx     = i;
                startX     = e.pageX;
                startWidth = th.offsetWidth;
                document.body.style.cursor     = 'col-resize';
                document.body.style.userSelect = 'none';
            }});
        }});

        function applyWidth(idx, newW) {{
            var minW = minWidths[idx] || 80;
            var px = Math.max(minW, Math.round(newW)) + 'px';
            if (thEls[idx]) {{
                thEls[idx].style.width = thEls[idx].style.minWidth = thEls[idx].style.maxWidth = px;
            }}
            if (colEls[idx]) {{
                colEls[idx].style.width = colEls[idx].style.minWidth = px;
            }}
        }}
        function paint() {{
            rafId = 0;
            if (!isResizing || colIdx < 0) return;
            applyWidth(colIdx, startWidth + (pendingX - startX));
        }}
        function onMove(e) {{
            if (!isResizing || colIdx < 0) return;
            pendingX = e.pageX;
            if (!rafId) rafId = requestAnimationFrame(paint);
        }}
        function onUp() {{
            if (!isResizing) return;
            if (rafId) {{ cancelAnimationFrame(rafId); rafId = 0; paint(); }}
            isResizing = false; colIdx = -1;
            document.body.style.cursor = document.body.style.userSelect = '';
        }}
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        if (viewer && viewer.__moonstormOnCleanup) {{
            viewer.__moonstormOnCleanup(function() {{
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                if (rafId) cancelAnimationFrame(rafId);
                document.body.style.cursor = document.body.style.userSelect = '';
            }});
        }}
    }})();"""

# Drag the footer corner to resize the table shell; keep host iframe in sync.
# Shell height grows downward in normal block layout — do not nudge notebook
# scroll during drag (that pinTop logic fought user scroll and looked like
# upward growth in windowed notebooks).
_JS_HEIGHT_RESIZE_TMPL = """\
    // ── Footer corner vertical resize (per pane / single viewer) ─────────
    (function() {{
        var viewer = document.getElementById('{viewer_id}');
        if (!viewer) return;

        var minH = {min_height};
        var maxH = {max_height};

        function hostFrame() {{
            try {{ return window.frameElement; }} catch (e) {{ return null; }}
        }}

        var syncRaf = 0;
        function syncHostFrameNow() {{
            try {{
                var frame = hostFrame();
                if (frame && frame.style) {{
                    var doc = document.documentElement;
                    var body = document.body;
                    var h = Math.max(
                        body ? body.scrollHeight : 0,
                        doc ? doc.scrollHeight : 0
                    );
                    frame.style.height = h + 'px';
                }}
            }} catch (e) {{}}
        }}

        function syncHostFrame() {{
            if (syncRaf) return;
            syncRaf = requestAnimationFrame(function() {{
                syncRaf = 0;
                syncHostFrameNow();
            }});
        }}

        function bindHandle(handle) {{
            var pane = handle.closest('.dataframe-result-pane');
            var root = pane || viewer;
            var shell = root.querySelector('.dataframe-table-shell');
            if (!shell) return;

            var dragging = false;

            function applyHeight(px) {{
                shell.style.height = px + 'px';
                syncHostFrame();
            }}

            function clampHeight(px) {{
                var vhCap = Math.floor(window.innerHeight * 0.85);
                return Math.max(minH, Math.min(maxH, vhCap, Math.round(px)));
            }}

            function onPointerDown(e) {{
                if (e.button != null && e.button !== 0) return;
                e.preventDefault();
                e.stopPropagation();
                var startY = e.screenY;
                var startH = shell.getBoundingClientRect().height;
                dragging = true;
                viewer.setAttribute('data-dfv-resizing', 'true');
                handle.classList.add('is-dragging');
                document.body.style.cursor = 'ns-resize';
                document.body.style.userSelect = 'none';
                try {{ handle.setPointerCapture(e.pointerId); }} catch (err) {{}}

                function onPointerMove(ev) {{
                    applyHeight(clampHeight(startH + (ev.screenY - startY)));
                }}
                function onPointerUp() {{
                    dragging = false;
                    viewer.removeAttribute('data-dfv-resizing');
                    handle.classList.remove('is-dragging');
                    document.body.style.cursor = '';
                    document.body.style.userSelect = '';
                    handle.removeEventListener('pointermove', onPointerMove);
                    handle.removeEventListener('pointerup', onPointerUp);
                    handle.removeEventListener('pointercancel', onPointerUp);
                    if (syncRaf) {{
                        cancelAnimationFrame(syncRaf);
                        syncRaf = 0;
                    }}
                    syncHostFrameNow();
                }}
                handle.addEventListener('pointermove', onPointerMove);
                handle.addEventListener('pointerup', onPointerUp);
                handle.addEventListener('pointercancel', onPointerUp);
            }}

            handle.addEventListener('pointerdown', onPointerDown);
            var ro = null;
            if (typeof ResizeObserver !== 'undefined') {{
                ro = new ResizeObserver(function() {{
                    if (dragging) return;
                    syncHostFrame();
                }});
                ro.observe(shell);
            }}
            if (viewer.__moonstormOnCleanup) {{
                viewer.__moonstormOnCleanup(function() {{
                    handle.removeEventListener('pointerdown', onPointerDown);
                    if (ro) {{
                        try {{ ro.disconnect(); }} catch (err) {{}}
                    }}
                }});
            }}
        }}

        viewer.querySelectorAll('.dataframe-resize-corner').forEach(bindHandle);
    }})();"""

# Minimize / restore the notebook dataframe viewer (header minus + minimized tray).
_JS_MINIMIZE_TMPL = """\
    (function() {{
        var viewer = document.getElementById('{viewer_id}');
        var btn = document.getElementById('{minimize_btn_id}');
        var banner = viewer && viewer.querySelector('.dataframe-minimized-banner');
        var maximizeBtn = viewer && viewer.querySelector('.dataframe-maximize-btn');
        var trayOpenTab = viewer && viewer.querySelector('.dataframe-minimized-open-tab');
        if (!viewer || !btn || !banner) return;

        function activeOpenTabBtn() {{
            return (
                viewer.querySelector(
                    '.dataframe-result-pane:not([hidden]) .dataframe-open-tab-btn'
                ) ||
                document.getElementById('{open_tab_btn_id}')
            );
        }}

        function setMinimized(on) {{
            if (on) {{
                viewer.setAttribute('data-minimized', 'true');
                btn.setAttribute('aria-pressed', 'true');
                btn.title = 'Restore dataframe';
            }} else {{
                viewer.removeAttribute('data-minimized');
                btn.setAttribute('aria-pressed', 'false');
                btn.title = 'Minimize dataframe';
            }}
        }}

        btn.addEventListener('click', function(event) {{
            event.preventDefault();
            event.stopPropagation();
            setMinimized(viewer.getAttribute('data-minimized') !== 'true');
        }});
        function restore(event) {{
            event.preventDefault();
            event.stopPropagation();
            setMinimized(false);
        }}
        banner.addEventListener('click', restore);
        if (maximizeBtn) maximizeBtn.addEventListener('click', restore);
        if (trayOpenTab) {{
            trayOpenTab.addEventListener('click', function(event) {{
                event.preventDefault();
                event.stopPropagation();
                var openBtn = activeOpenTabBtn();
                if (openBtn) openBtn.click();
            }});
        }}
    }})();"""

# Ask the JupyterLab host to open a native main-area dataframe browser tab
# (structured columns/rows — not an embed of this HTML viewer).
_JS_OPEN_TAB_TMPL = """\
    // ── Open table data in a JupyterLab tab (native browser) ─────────────
    (function() {{
        var btn = document.getElementById('{open_tab_btn_id}');
        if (!btn) return;

        function resolveViewer() {{
            return (
                btn.closest('.dataframe-viewer') ||
                document.getElementById('{viewer_id}')
            );
        }}

        function resolveTargetPane(viewer) {{
            var pane = btn.closest('.dataframe-result-pane');
            if (pane) return pane;
            var controls = btn.closest('.dataframe-result-controls');
            if (controls && viewer) {{
                var idx = controls.getAttribute('data-result-index');
                if (idx != null) {{
                    var byIndex = viewer.querySelector(
                        '.dataframe-result-pane[data-result-index="' + idx + '"]'
                    );
                    if (byIndex) return byIndex;
                }}
            }}
            if (viewer) {{
                var visible = viewer.querySelector(
                    '.dataframe-result-pane:not([hidden])'
                );
                if (visible) return visible;
            }}
            return null;
        }}

        function cellText(td) {{
            if (td.querySelector('.dataframe-null')) return '';
            var complex = td.querySelector('.complex-value');
            if (complex) {{
                var preview = complex.querySelector('.complex-preview');
                return preview ? preview.textContent.trim() : '';
            }}
            var pre = td.querySelector('pre');
            var raw = pre ? pre.textContent : td.textContent;
            return (raw || '').replace(/\\s+/g, ' ').trim();
        }}

        function collectCell(td) {{
            var isNull = !!td.querySelector('.dataframe-null');
            var cell = {{
                text: isNull ? '' : cellText(td),
                sort: td.getAttribute('data-sort-value') || '',
                isNull: isNull
            }};
            var complex = td.querySelector('.complex-value');
            if (complex && !isNull) {{
                var previewEl = complex.querySelector('.complex-preview');
                var jsonEl = complex.querySelector('pre.complex-json');
                var jsonText = jsonEl ? (jsonEl.textContent || '') : '';
                if (!jsonText) {{
                    var toggle = complex.querySelector('.complex-toggle');
                    var cellId = toggle
                        ? toggle.getAttribute('data-dfv-cell-id')
                        : '';
                    if (cellId) {{
                        var raw = document.getElementById(cellId + '-raw');
                        if (raw) jsonText = raw.textContent || '';
                    }}
                }}
                cell.complex = {{
                    preview: previewEl ? previewEl.textContent.trim() : cell.text,
                    json: jsonText
                }};
            }}
            return cell;
        }}

        function collectTable() {{
            var viewer = resolveViewer();
            var pane = resolveTargetPane(viewer);
            var root = pane || viewer;
            var table = root ? root.querySelector('table.dataframe-table') : null;
            var columns = [];
            var rows = [];
            if (!table) return {{ columns: columns, rows: rows }};

            Array.from(table.querySelectorAll('thead th')).forEach(function(th) {{
                var nameEl = th.querySelector('.column-header-name');
                var dtypeEl = th.querySelector('.column-header-dtype');
                var title = th.getAttribute('title') || '';
                columns.push({{
                    name: nameEl ? nameEl.textContent.trim() : (th.textContent || '').trim(),
                    dtype: dtypeEl ? dtypeEl.textContent.trim() : '',
                    type: title.replace(/^Type:\\s*/i, '')
                }});
            }});

            Array.from(table.querySelectorAll('tbody tr')).forEach(function(tr) {{
                if (tr.classList.contains('column-selector-empty-row')) return;
                if (tr.querySelector('.filter-show-all')) return;
                var cells = [];
                Array.from(tr.querySelectorAll('td[data-column]')).forEach(function(td) {{
                    cells.push(collectCell(td));
                }});
                if (cells.length) rows.push(cells);
            }});

            return {{ columns: columns, rows: rows }};
        }}

        function readEmbeddedOpenTab() {{
            var viewer = resolveViewer();
            var pane = resolveTargetPane(viewer);
            var root = pane || viewer;
            if (!root) return null;
            var script = root.querySelector('script[data-dfv-open-tab]');
            if (!script || !script.textContent) return null;
            try {{
                return JSON.parse(script.textContent);
            }} catch (e) {{
                return null;
            }}
        }}

        function requestOpenTab() {{
            var viewer = resolveViewer();
            var pane = resolveTargetPane(viewer);
            var engine = (pane && pane.getAttribute('data-engine')) ||
                (viewer && viewer.getAttribute('data-engine')) ||
                'dataframe';
            var title =
                (pane && (pane.getAttribute('title') || pane.getAttribute('data-label'))) ||
                (engine === 'pyspark' ? 'PySpark DataFrame' : 'DataFrame');
            var embedded = readEmbeddedOpenTab();
            var table = embedded && embedded.columns && embedded.columns.length
                ? embedded
                : collectTable();
            if (!table.columns.length) return;
            var viewerId = (viewer && viewer.id) || '{viewer_id}';
            if (pane) {{
                var resultIndex = pane.getAttribute('data-result-index');
                if (resultIndex != null && viewer && viewer.getAttribute('data-result-count')) {{
                    viewerId = viewerId + ':r' + resultIndex;
                }}
            }}
            var resultLabel = null;
            if (pane && viewer && viewer.getAttribute('data-result-count')) {{
                resultLabel = pane.getAttribute('data-label');
            }}
            var payload = {{
                type: 'moonstorm-dfv-open-tab',
                viewerId: viewerId,
                title: title,
                resultLabel: resultLabel || undefined,
                engine: engine,
                columns: table.columns,
                rows: table.rows
            }};
            try {{
                if (window.parent && window.parent !== window) {{
                    window.parent.postMessage(payload, '*');
                    return;
                }}
            }} catch (e) {{}}
            window.dispatchEvent(new CustomEvent('moonstorm-dfv-open-tab', {{
                detail: payload
            }}));
        }}

        btn.addEventListener('click', function(e) {{
            e.preventDefault();
            e.stopPropagation();
            requestOpenTab();
        }});
    }})();"""

_JS_ROW_EDIT_TMPL = """\
    // ── Manual row edit (pandas / PySpark) — draft cells, copy patch code ───
    (function() {{
        var btn = document.getElementById('{edit_btn_id}');
        var viewerId = '{viewer_id}';
        var tableId = '{table_id}';
        if (!btn) return;

        function escapeHtml(text) {{
            return String(text)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        }}

        function showDfvDialog(viewer, opts) {{
            if (!viewer) return null;
            var backdrop = document.createElement('div');
            backdrop.className = 'column-selector-backdrop dfv-dialog-backdrop open';
            backdrop.innerHTML =
                '<div class="column-selector-modal dfv-dialog-modal" role="dialog" aria-modal="true">' +
                '<div class="column-selector-modal-header">' +
                '<span class="column-selector-modal-title">' + escapeHtml(opts.title || '') + '</span>' +
                '<button type="button" class="column-selector-close" aria-label="Close">&times;</button>' +
                '</div>' +
                '<div class="column-selector-modal-body dfv-dialog-body">' + (opts.bodyHtml || '') + '</div>' +
                (opts.footerHtml
                    ? '<div class="dfv-dialog-footer">' + opts.footerHtml + '</div>'
                    : '') +
                '</div>';
            viewer.appendChild(backdrop);
            var modalBox = backdrop.querySelector('.column-selector-modal');
            if (modalBox) {{
                modalBox.addEventListener('click', function(e) {{ e.stopPropagation(); }});
            }}
            backdrop.addEventListener('click', function(e) {{
                if (e.target === backdrop && opts.backdropCloses) {{
                    if (typeof opts.onBackdrop === 'function') opts.onBackdrop();
                }}
            }});
            var closeBtn = backdrop.querySelector('.column-selector-close');
            if (closeBtn) {{
                closeBtn.addEventListener('click', function() {{
                    if (typeof opts.onClose === 'function') opts.onClose();
                }});
            }}
            return backdrop;
        }}

        function closeDfvDialog(backdrop) {{
            if (!backdrop) return;
            backdrop.classList.remove('open');
            if (backdrop.parentNode) backdrop.parentNode.removeChild(backdrop);
        }}

        function resolveViewer() {{
            return document.getElementById(viewerId);
        }}

        function resolvePane(viewer) {{
            if (!viewer) return null;
            var pane = btn.closest('.dataframe-result-pane');
            if (pane) return pane;
            var controls = btn.closest('.dataframe-result-controls');
            if (controls) {{
                var idx = controls.getAttribute('data-result-index');
                if (idx != null) {{
                    var byIndex = viewer.querySelector(
                        '.dataframe-result-pane[data-result-index="' + idx + '"]'
                    );
                    if (byIndex) return byIndex;
                }}
            }}
            var active = viewer.querySelector('.dataframe-result-pane:not([hidden])');
            return active || viewer;
        }}

        function resolveEditEngine(viewer, pane, snapshot) {{
            if (snapshot && snapshot.engine) return String(snapshot.engine);
            var fromPane = pane && pane.getAttribute('data-engine');
            if (fromPane) return fromPane;
            return (viewer && viewer.getAttribute('data-engine')) || '';
        }}

        function supportsRowEdit(engine) {{
            return engine === 'pyspark' || engine === 'pandas';
        }}

        function readSnapshot(root) {{
            if (!root) return null;
            var script = root.querySelector('script[data-dfv-edit-snapshot]');
            if (!script || !script.textContent) return null;
            try {{ return JSON.parse(script.textContent); }} catch (e) {{ return null; }}
        }}

        function cellText(td) {{
            var el = td.querySelector('.dfv-cell-text');
            if (el) return (el.textContent || '').trim();
            if (td.querySelector('.complex-toggle')) return null;
            return (td.textContent || '').trim();
        }}

        function stripEditArtifacts(text) {{
            return String(text).replace(/\\u200b/g, '').replace(/\\ufeff/g, '');
        }}

        function cellRawText(td) {{
            if (td.querySelector('.complex-toggle')) return null;
            var el = td.querySelector('.dfv-cell-text');
            if (el) return stripEditArtifacts(el.textContent);
            return stripEditArtifacts(td.textContent || '');
        }}

        function cellValueFromDom(td) {{
            if (td.querySelector('.complex-toggle')) return undefined;
            var el = td.querySelector('.dfv-cell-text');
            if (el && el.classList.contains('dataframe-null')) return null;
            if (el) return stripEditArtifacts(el.textContent);
            if (td.querySelector('.dataframe-null')) return null;
            return stripEditArtifacts(td.textContent || '');
        }}

        function isEmptyEditCell(td) {{
            return cellRawText(td) === '';
        }}

        function focusEmptyEditableCell(td) {{
            if (!isEmptyEditCell(td)) return;
            try {{
                var range = document.createRange();
                range.selectNodeContents(td);
                range.collapse(true);
                var sel = window.getSelection();
                if (!sel) return;
                sel.removeAllRanges();
                sel.addRange(range);
            }} catch (e) {{ /* ignore */ }}
        }}

        function isStringSqlType(base) {{
            return (
                base === 'STRING' || base === 'CHAR' || base === 'VARCHAR' ||
                base.startsWith('VARCHAR') || base.startsWith('CHAR')
            );
        }}

        function parseCellInput(text, sqlType) {{
            if (text === null || text === undefined) return null;
            var raw = stripEditArtifacts(String(text));
            if (/^null$/i.test(raw.trim())) return null;
            if (raw === '') return '';
            if (raw === 'True') return true;
            if (raw === 'False') return false;
            var n = Number(raw);
            if (Number.isFinite(n) && String(n) === raw.trim()) return n;
            return raw;
        }}

        function normalizeDisplay(text, sqlType) {{
            return parseCellInput(text, sqlType);
        }}

        function renderCellText(value) {{
            if (value === null || value === undefined) {{
                return '<span class="dataframe-null dfv-cell-text">null</span>';
            }}
            var cls = 'dfv-cell-text' + (value === '' ? ' dfv-empty-string' : '');
            return '<span class="' + cls + '">' + escapeHtml(String(value)) + '</span>';
        }}

        function prepareEditableCell(td) {{
            if (td.querySelector('.complex-toggle')) return false;
            var el = td.querySelector('.dfv-cell-text');
            if (!el) {{
                td.innerHTML = '<span class="dfv-cell-text"></span>';
                el = td.querySelector('.dfv-cell-text');
            }}
            if (el && el.classList.contains('dataframe-null')) {{
                el.classList.remove('dataframe-null');
                if (el.textContent === '') el.textContent = 'null';
            }}
            return true;
        }}

        function columnName(table, colIdx) {{
            var th = table.querySelector('thead th[data-column="' + colIdx + '"] .column-header-name');
            return th ? th.textContent.trim() : '';
        }}

        function pkColumnIndex(snapshot) {{
            if (!state.primaryKey || !snapshot || !snapshot.columns) return -1;
            for (var pi = 0; pi < snapshot.columns.length; pi++) {{
                if (snapshot.columns[pi].name === state.primaryKey) return pi;
            }}
            return -1;
        }}

        function isPkLockedCell(td, tr, snapshot) {{
            var pkIdx = pkColumnIndex(snapshot);
            if (pkIdx < 0) return false;
            var colIdx = parseInt(td.getAttribute('data-column'), 10);
            if (!Number.isFinite(colIdx) || colIdx !== pkIdx) return false;
            if (tr.getAttribute('data-dfv-new-row') === '1') return false;
            return true;
        }}

        var state = {{
            active: false,
            primaryKey: '',
            bar: null,
            snapshot: null
        }};

        function setDraft(td, on) {{
            if (on) td.classList.add('dfv-cell-draft');
            else td.classList.remove('dfv-cell-draft');
        }}

        function validateDisplayValue(rawText, sqlType) {{
            var text = rawText === null || rawText === undefined ? '' : String(rawText);
            var trimmed = text.trim();
            var base = String(sqlType || 'STRING').split('(')[0].trim().toUpperCase();
            if (/^null$/i.test(trimmed)) {{
                return {{ ok: true }};
            }}
            if (text === '') {{
                if (isStringSqlType(base)) return {{ ok: true }};
                return {{
                    ok: false,
                    message: 'Use null for missing values in this column'
                }};
            }}
            if (base === 'BOOLEAN' || base === 'BOOL') {{
                if (/^(true|false)$/i.test(text)) return {{ ok: true }};
                return {{ ok: false, message: 'Use true or false' }};
            }}
            if (base === 'BIGINT' || base === 'LONG') {{
                if (/^-?\\d+$/.test(text)) return {{ ok: true }};
                return {{
                    ok: false,
                    message: 'Whole numbers only — no letters, spaces, or decimals'
                }};
            }}
            if (
                base === 'INT' || base === 'INTEGER' ||
                base === 'SMALLINT' || base === 'TINYINT'
            ) {{
                if (/^-?\\d+$/.test(text)) return {{ ok: true }};
                return {{ ok: false, message: 'Whole numbers only' }};
            }}
            if (
                base === 'DOUBLE' || base === 'FLOAT' || base === 'REAL' ||
                base.startsWith('DECIMAL') || base === 'NUMERIC'
            ) {{
                if (/^-?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?$/.test(text)) {{
                    return {{ ok: true }};
                }}
                return {{ ok: false, message: 'Enter a valid number' }};
            }}
            if (base === 'DATE') {{
                if (/^\\d{{4}}-\\d{{2}}-\\d{{2}}$/.test(text)) {{
                    return {{ ok: true }};
                }}
                return {{ ok: false, message: 'Use YYYY-MM-DD' }};
            }}
            return {{ ok: true }};
        }}

        function validateDraftCell(td, table, snapshot) {{
            if (!td || !snapshot) return true;
            var colIdx = td.getAttribute('data-column');
            if (colIdx === null || colIdx === undefined) return true;
            var colName = columnName(table, String(colIdx));
            var sqlType = sqlTypeForColumn(snapshot, colName);
            var raw = cellRawText(td);
            if (raw === null) raw = '';
            var check = validateDisplayValue(raw, sqlType);
            if (!check.ok) {{
                td.classList.add('dfv-cell-invalid');
                td.setAttribute(
                    'data-dfv-validation-msg',
                    check.message || ('Invalid value for ' + sqlType)
                );
                td.title = check.message || ('Invalid value for ' + sqlType);
                return false;
            }}
            td.classList.remove('dfv-cell-invalid');
            td.removeAttribute('data-dfv-validation-msg');
            if (td.classList.contains('dfv-cell-editable')) {{
                td.title = '';
            }}
            return true;
        }}

        function collectValidationErrors(table, snapshot) {{
            var errors = [];
            if (!table || !snapshot) return errors;
            var seen = Object.create(null);
            table.querySelectorAll('td.dfv-cell-editable').forEach(function(td) {{
                if (!validateDraftCell(td, table, snapshot)) {{
                    var colIdx = td.getAttribute('data-column');
                    var colName = columnName(table, String(colIdx));
                    var msg = td.getAttribute('data-dfv-validation-msg') || 'Invalid value';
                    var key = colName + '|' + msg;
                    if (!seen[key]) {{
                        seen[key] = true;
                        errors.push({{ column: colName, message: msg }});
                    }}
                }}
            }});
            return errors;
        }}

        function refreshDraft(td) {{
            var origJson = td.getAttribute('data-dfv-original-json');
            if (!origJson) return;
            var orig;
            try {{ orig = JSON.parse(origJson); }} catch (e) {{ return; }}
            var table = document.getElementById(tableId);
            var snapshot = state.snapshot;
            var colIdx = td.getAttribute('data-column');
            var colName = table && colIdx != null
                ? columnName(table, String(colIdx))
                : '';
            var sqlType = snapshot && colName
                ? sqlTypeForColumn(snapshot, colName)
                : 'STRING';
            var raw = cellRawText(td);
            if (raw === null) return;
            var now = parseCellInput(raw, sqlType);
            setDraft(td, JSON.stringify(now) !== JSON.stringify(orig));
            if (table && snapshot) validateDraftCell(td, table, snapshot);
        }}

        function revertDraftEdits(table) {{
            if (!table) return;
            table.querySelectorAll('tbody tr[data-dfv-new-row]').forEach(function(tr) {{
                tr.parentNode.removeChild(tr);
            }});
            table.querySelectorAll('td[data-dfv-original-json]').forEach(function(td) {{
                var origJson = td.getAttribute('data-dfv-original-json') || 'null';
                var orig;
                try {{ orig = JSON.parse(origJson); }} catch (e) {{ orig = null; }}
                if (!td.querySelector('.complex-toggle')) {{
                    td.innerHTML = renderCellText(orig);
                }}
                td.classList.remove('dfv-cell-draft', 'dfv-cell-invalid');
                td.removeAttribute('data-dfv-validation-msg');
            }});
        }}

        function exitEditMode(discardDrafts) {{
            state.active = false;
            btn.classList.remove('active');
            btn.setAttribute('aria-pressed', 'false');
            var viewer = resolveViewer();
            var pane = resolvePane(viewer);
            var table = document.getElementById(tableId);
            if (table && discardDrafts) revertDraftEdits(table);
            if (table) {{
                table.querySelectorAll('td[data-column]').forEach(function(td) {{
                    td.removeAttribute('contenteditable');
                    td.classList.remove(
                        'dfv-cell-editable', 'dfv-cell-draft', 'dfv-cell-invalid', 'dfv-cell-pk-locked'
                    );
                    td.removeAttribute('data-dfv-original-json');
                    td.removeAttribute('data-dfv-validation-msg');
                }});
            }}
            if (state.bar && state.bar.parentNode) state.bar.parentNode.removeChild(state.bar);
            state.bar = null;
        }}

        function collectOperations(table, snapshot) {{
            var ops = [];
            var pk = state.primaryKey;
            var colCount = snapshot.columns.length;
            var origRows = snapshot.rows || [];

            table.querySelectorAll('tbody tr[data-dfv-row-index]').forEach(function(tr) {{
                if (tr.classList.contains('column-selector-empty-row')) return;
                if (tr.getAttribute('data-dfv-new-row') === '1') {{
                    var values = {{}};
                    for (var ci = 0; ci < colCount; ci++) {{
                        var td = tr.querySelector('td[data-column="' + ci + '"]');
                        if (!td) continue;
                        var name = columnName(table, String(ci));
                        if (!name) continue;
                        values[name] = parseCellInput(
                            cellRawText(td) || '',
                            sqlTypeForColumn(snapshot, name)
                        );
                    }}
                    ops.push({{ op: 'insert', values: values }});
                    return;
                }}
                var rowIdx = parseInt(tr.getAttribute('data-dfv-row-index'), 10);
                if (!Number.isFinite(rowIdx) || !origRows[rowIdx]) return;
                var orig = origRows[rowIdx];
                var match = {{}};
                var set = {{}};
                var pkIdx = -1;
                for (var pi = 0; pi < snapshot.columns.length; pi++) {{
                    if (snapshot.columns[pi].name === pk) {{ pkIdx = pi; break; }}
                }}
                var pkVal = pkIdx >= 0 ? orig[pkIdx] : null;
                for (var cj = 0; cj < colCount; cj++) {{
                    var nameJ = snapshot.columns[cj].name;
                    if (nameJ === pk) continue;
                    var tdJ = tr.querySelector('td[data-column="' + cj + '"]');
                    if (!tdJ || !tdJ.classList.contains('dfv-cell-draft')) continue;
                        var newVal = parseCellInput(
                            cellRawText(tdJ) || '',
                            sqlTypeForColumn(snapshot, nameJ)
                        );
                    var oldVal = orig[cj];
                    if (JSON.stringify(newVal) !== JSON.stringify(oldVal)) {{
                        set[nameJ] = newVal;
                    }}
                }}
                if (Object.keys(set).length && pkVal !== null && pkVal !== undefined) {{
                    match[pk] = pkVal;
                    ops.push({{ op: 'replace', match: match, set: set }});
                }}
            }});
            return ops;
        }}

        function sqlTypeForColumn(snapshot, colName) {{
            var cols = snapshot.columns || [];
            for (var i = 0; i < cols.length; i++) {{
                if (cols[i].name === colName) {{
                    return String(cols[i].sqlType || 'STRING').toUpperCase();
                }}
            }}
            return 'STRING';
        }}

        function sqlEscapeLiteral(value) {{
            return String(value).replace(/'/g, "''");
        }}

        function sparkTryCastExpr(value, sqlType) {{
            if (value === null || value === undefined) {{
                return 'F.lit(None).cast("' + sqlType + '")';
            }}
            if (typeof value === 'boolean') {{
                return value ? 'F.lit(True)' : 'F.lit(False)';
            }}
            if (typeof value === 'number' && Number.isFinite(value)) {{
                return 'F.lit(' + String(value) + ').cast("' + sqlType + '")';
            }}
            if (value === '') {{
                return (
                    'F.expr("try_cast(\\'\\' AS ' + sqlType + ')")'
                );
            }}
            return (
                'F.expr("try_cast(\\'' + sqlEscapeLiteral(value) +
                '\\' AS ' + sqlType + ')")'
            );
        }}

        function sqlTryCastFragment(value, sqlType) {{
            if (value === null || value === undefined) {{
                return 'CAST(NULL AS ' + sqlType + ')';
            }}
            if (typeof value === 'boolean') {{
                return value ? 'true' : 'false';
            }}
            if (typeof value === 'number' && Number.isFinite(value)) {{
                return 'try_cast(' + String(value) + ' AS ' + sqlType + ')';
            }}
            if (value === '') {{
                return "try_cast('' AS " + sqlType + ')';
            }}
            return (
                "try_cast('" + sqlEscapeLiteral(value) + "' AS " + sqlType + ')'
            );
        }}

        function sparkMatchCondition(match, snapshot) {{
            var parts = [];
            for (var k in match) {{
                if (!Object.prototype.hasOwnProperty.call(match, k)) continue;
                var v = match[k];
                var sqlType = sqlTypeForColumn(snapshot, k);
                var colRef = 'F.col(' + JSON.stringify(k) + ')';
                var schemaCast =
                    'F.lit(None).cast(_source.schema[' + JSON.stringify(k) + '].dataType)';
                var rhs;
                if (typeof v === 'number' && Number.isFinite(v)) {{
                    rhs = 'F.lit(' + String(v) + ').cast(_source.schema[' +
                        JSON.stringify(k) + '].dataType)';
                }} else if (typeof v === 'boolean') {{
                    rhs = 'F.lit(' + (v ? 'True' : 'False') + ').cast(_source.schema[' +
                        JSON.stringify(k) + '].dataType)';
                }} else if (v === null) {{
                    rhs = schemaCast;
                }} else {{
                    rhs = sparkTryCastExpr(v, sqlType);
                }}
                parts.push('(' + colRef + ' == ' + rhs + ')');
            }}
            return parts.length ? parts.join(' & ') : 'F.lit(True)';
        }}

        function resolveDataframeVarName(viewer, pane) {{
            var ident = /^[A-Za-z_][A-Za-z0-9_]*$/;
            var resultTab = /^Result \\d+$/;
            function varFrom(el) {{
                if (!el) return '';
                var vn = (el.getAttribute('data-var-name') || '').trim();
                return vn && ident.test(vn) ? vn : '';
            }}
            function labelFrom(el) {{
                if (!el) return '';
                var lab = (el.getAttribute('data-label') || '').trim();
                return lab && ident.test(lab) && !resultTab.test(lab) ? lab : '';
            }}
            var vn = varFrom(pane) || varFrom(viewer);
            if (vn) return {{ name: vn, known: true }};
            var lab = labelFrom(pane) || labelFrom(viewer);
            if (lab) return {{ name: lab, known: true }};
            return {{ name: 'df', known: false }};
        }}

        function buildPySparkPatchSource(primaryKey, varInfo, ops, snapshot) {{
            var name = (varInfo.name || 'df').trim() || 'df';
            var known = !!varInfo.known;
            var lines = [
                '# Moonstorm dataframe viewer — manual edits (review before running)',
                '# Primary key: ' + primaryKey,
                'from pyspark.sql import functions as F',
                ''
            ];
            if (!known) {{
                lines.push('# TODO: set `_source` to your DataFrame variable name');
            }}
            lines.push('_source = ' + name, '_work = _source', '');

            for (var oi = 0; oi < ops.length; oi++) {{
                var op = ops[oi];
                if (op.op === 'replace') {{
                    var cond = sparkMatchCondition(op.match, snapshot);
                    for (var col in op.set) {{
                        if (!Object.prototype.hasOwnProperty.call(op.set, col)) continue;
                        var val = op.set[col];
                        var sqlType = sqlTypeForColumn(snapshot, col);
                        lines.push('_work = _work.withColumn(');
                        lines.push('    ' + JSON.stringify(col) + ',');
                        lines.push(
                            '    F.when(' + cond + ', ' +
                            sparkTryCastExpr(val, sqlType) +
                            ').otherwise(F.col(' + JSON.stringify(col) + '))'
                        );
                        lines.push(')');
                    }}
                }} else if (op.op === 'insert') {{
                    var selectParts = [];
                    var cols = snapshot.columns || [];
                    for (var ci = 0; ci < cols.length; ci++) {{
                        var cname = cols[ci].name;
                        var st = sqlTypeForColumn(snapshot, cname);
                        var ival = Object.prototype.hasOwnProperty.call(op.values, cname)
                            ? op.values[cname]
                            : null;
                        selectParts.push(
                            sqlTryCastFragment(ival, st) + ' AS ' + cname
                        );
                    }}
                    lines.push('_work = _work.unionByName(');
                    lines.push(
                        "    spark.sql('SELECT " + selectParts.join(', ') + "'),"
                    );
                    lines.push('    allowMissingColumns=True,');
                    lines.push(')');
                }}
            }}

            lines.push('', name + ' = _work');
            return lines.join('\\n');
        }}

        function pyLiteral(value) {{
            if (value === null || value === undefined) return 'None';
            if (typeof value === 'boolean') return value ? 'True' : 'False';
            if (typeof value === 'number' && Number.isFinite(value)) return String(value);
            if (value === '') return "''";
            return JSON.stringify(String(value));
        }}

        function pyColRef(name) {{
            return JSON.stringify(String(name));
        }}

        function buildPandasPatchSource(primaryKey, varInfo, ops, snapshot) {{
            var name = (varInfo.name || 'df').trim() || 'df';
            var known = !!varInfo.known;
            var lines = [
                '# Moonstorm dataframe viewer — manual edits (review before running)',
                '# Primary key: ' + primaryKey,
                'import pandas as pd',
                ''
            ];
            if (!known) {{
                lines.push('# TODO: set `_source` to your DataFrame variable name');
            }}
            lines.push('_source = ' + name, '_work = _source.copy()', '');

            for (var oi = 0; oi < ops.length; oi++) {{
                var op = ops[oi];
                if (op.op === 'replace') {{
                    var maskParts = [];
                    for (var mk in op.match) {{
                        if (!Object.prototype.hasOwnProperty.call(op.match, mk)) continue;
                        maskParts.push(
                            '(_work[' + pyColRef(mk) + '] == ' +
                            pyLiteral(op.match[mk]) + ')'
                        );
                    }}
                    if (!maskParts.length) continue;
                    var maskVar = '_mask_' + String(oi);
                    lines.push(maskVar + ' = ' + maskParts.join(' & '));
                    for (var col in op.set) {{
                        if (!Object.prototype.hasOwnProperty.call(op.set, col)) continue;
                        lines.push(
                            '_work.loc[' + maskVar + ', ' + pyColRef(col) + '] = ' +
                            pyLiteral(op.set[col])
                        );
                    }}
                    lines.push('');
                }} else if (op.op === 'insert') {{
                    var dictParts = [];
                    var cols = snapshot.columns || [];
                    for (var ci = 0; ci < cols.length; ci++) {{
                        var cname = cols[ci].name;
                        var ival = Object.prototype.hasOwnProperty.call(op.values, cname)
                            ? op.values[cname]
                            : null;
                        dictParts.push(
                            '        ' + pyColRef(cname) + ': ' + pyLiteral(ival)
                        );
                    }}
                    lines.push('_new = pd.DataFrame([');
                    lines.push('    {{');
                    lines.push(dictParts.join(',\\n'));
                    lines.push('    }}');
                    lines.push('])');
                    lines.push('_work = pd.concat([_work, _new], ignore_index=True)');
                    lines.push('');
                }}
            }}

            lines.push('', name + ' = _work');
            return lines.join('\\n');
        }}

        function sqlIdent(name) {{
            return '`' + String(name).replace(/`/g, '``') + '`';
        }}

        function buildSqlPatchSource(primaryKey, varInfo, ops, snapshot) {{
            var name = (varInfo.name || 'df').trim() || 'df';
            var viewName = '_dfv_patch_base';
            var lines = [
                '-- Moonstorm dataframe viewer — manual edits (review before running)',
                '-- Primary key: ' + primaryKey,
                '-- Register your DataFrame, then run each statement (e.g. spark.sql(...)):',
                '--   ' + name + '.createOrReplaceTempView("' + viewName + '")',
                ''
            ];
            for (var oi = 0; oi < ops.length; oi++) {{
                var op = ops[oi];
                if (op.op === 'replace') {{
                    var setParts = [];
                    for (var col in op.set) {{
                        if (!Object.prototype.hasOwnProperty.call(op.set, col)) continue;
                        var val = op.set[col];
                        var sqlType = sqlTypeForColumn(snapshot, col);
                        setParts.push(
                            sqlIdent(col) + ' = ' + sqlTryCastFragment(val, sqlType)
                        );
                    }}
                    var whereParts = [];
                    for (var mk in op.match) {{
                        if (!Object.prototype.hasOwnProperty.call(op.match, mk)) continue;
                        var mv = op.match[mk];
                        var mType = sqlTypeForColumn(snapshot, mk);
                        whereParts.push(
                            sqlIdent(mk) + ' = ' + sqlTryCastFragment(mv, mType)
                        );
                    }}
                    if (!setParts.length || !whereParts.length) continue;
                    lines.push('UPDATE ' + viewName);
                    lines.push('SET ' + setParts.join(', '));
                    lines.push('WHERE ' + whereParts.join(' AND ') + ';');
                    lines.push('');
                }} else if (op.op === 'insert') {{
                    var selectParts = [];
                    var cols = snapshot.columns || [];
                    for (var ci = 0; ci < cols.length; ci++) {{
                        var cname = cols[ci].name;
                        var st = sqlTypeForColumn(snapshot, cname);
                        var ival = Object.prototype.hasOwnProperty.call(op.values, cname)
                            ? op.values[cname]
                            : null;
                        selectParts.push(
                            sqlTryCastFragment(ival, st) + ' AS ' + sqlIdent(cname)
                        );
                    }}
                    lines.push('INSERT INTO ' + viewName);
                    lines.push('SELECT');
                    lines.push('  ' + selectParts.join(',\\n  ') + ';');
                    lines.push('');
                }}
            }}
            return lines.join('\\n');
        }}

        function showCopyPatchModal(codes) {{
            var viewer = resolveViewer();
            var areaId = 'dfv-patch-code-' + viewerId;
            var formatMeta = [
                {{ key: 'pandas', label: 'pandas', title: 'pandas patch code' }},
                {{ key: 'pyspark', label: 'PySpark', title: 'PySpark patch code' }},
                {{ key: 'sql', label: 'SQL', title: 'SQL patch statements' }}
            ].filter(function(f) {{ return !!codes[f.key]; }});
            if (!formatMeta.length) return;
            var mode = formatMeta[0].key;
            var modalTitles = {{}};
            formatMeta.forEach(function(f) {{ modalTitles[f.key] = f.title; }});
            var toggleHtml = '';
            if (formatMeta.length > 1) {{
                toggleHtml =
                    '<div class="dfv-code-format-toggle" role="tablist" aria-label="Code format">' +
                    formatMeta.map(function(f, idx) {{
                        return '<button type="button" class="dfv-code-format-btn' +
                            (idx === 0 ? ' active' : '') + '" data-format="' + f.key +
                            '" role="tab" aria-selected="' + (idx === 0 ? 'true' : 'false') +
                            '">' + escapeHtml(f.label) + '</button>';
                    }}).join('') +
                    '</div>';
            }}
            var helpHtml = codes.pandas
                ? 'Copy into a <strong>new code cell</strong> below, then run it to apply your edits.'
                : 'Copy into a new cell below. Use <strong>PySpark</strong> as-is, or register a temp view and run <strong>SQL</strong> via <code>spark.sql</code>.';
            var backdrop = showDfvDialog(viewer, {{
                title: modalTitles[mode],
                bodyHtml:
                    '<p class="dfv-dialog-message">' + helpHtml + '</p>' +
                    toggleHtml +
                    '<textarea id="' + areaId + '" class="dfv-dialog-code" readonly spellcheck="false"></textarea>',
                footerHtml:
                    '<button type="button" class="dfv-dialog-btn dfv-dialog-btn-primary" data-action="copy">Copy to clipboard</button>' +
                    '<button type="button" class="dfv-dialog-btn" data-action="close">Close</button>',
                backdropCloses: true,
                onBackdrop: function() {{ closeDfvDialog(backdrop); }},
                onClose: function() {{ closeDfvDialog(backdrop); }}
            }});
            if (!backdrop) return;
            var area = backdrop.querySelector('#' + areaId);
            var titleEl = backdrop.querySelector('.column-selector-modal-title');
            function applyCodeFormat(next) {{
                if (!codes[next]) return;
                mode = next;
                if (titleEl) titleEl.textContent = modalTitles[next] || formatMeta[0].title;
                if (area) area.value = codes[next];
                backdrop.querySelectorAll('.dfv-code-format-btn').forEach(function(btn) {{
                    var on = btn.getAttribute('data-format') === next;
                    btn.classList.toggle('active', on);
                    btn.setAttribute('aria-selected', on ? 'true' : 'false');
                }});
            }}
            applyCodeFormat(mode);
            backdrop.querySelectorAll('.dfv-code-format-btn').forEach(function(btn) {{
                btn.addEventListener('click', function() {{
                    applyCodeFormat(btn.getAttribute('data-format') || mode);
                }});
            }});
            var copyBtn = backdrop.querySelector('[data-action="copy"]');
            var copyFeedback = function(ok) {{
                if (!copyBtn) return;
                var prev = copyBtn.textContent;
                copyBtn.textContent = ok ? 'Copied!' : 'Copy failed — select text above';
                window.setTimeout(function() {{ copyBtn.textContent = prev; }}, 2000);
            }};
            if (copyBtn) {{
                copyBtn.addEventListener('click', function() {{
                    var text = area ? area.value : (codes[mode] || codes[formatMeta[0].key]);
                    if (navigator.clipboard && navigator.clipboard.writeText) {{
                        navigator.clipboard.writeText(text).then(function() {{
                            copyFeedback(true);
                        }}).catch(function() {{
                            if (area) {{ area.focus(); area.select(); }}
                            copyFeedback(false);
                        }});
                    }} else if (area) {{
                        area.focus();
                        area.select();
                        try {{
                            copyFeedback(document.execCommand('copy'));
                        }} catch (e) {{
                            copyFeedback(false);
                        }}
                    }}
                }});
            }}
            backdrop.querySelector('[data-action="close"]').addEventListener('click', function() {{
                closeDfvDialog(backdrop);
            }});
        }}

        function commitEdits() {{
            var viewer = resolveViewer();
            var pane = resolvePane(viewer);
            var table = document.getElementById(tableId);
            var snapshot = state.snapshot || readSnapshot(pane || viewer);
            if (!table || !snapshot) return;
            var validationErrors = collectValidationErrors(table, snapshot);
            if (validationErrors.length) {{
                showValidationErrorsModal(validationErrors);
                return;
            }}
            var ops = collectOperations(table, snapshot);
            if (!ops.length) {{
                exitEditMode(false);
                return;
            }}
            var varInfo = resolveDataframeVarName(viewer, pane);
            var editEngine = resolveEditEngine(viewer, pane, snapshot);
            var patchCodes = {{}};
            if (editEngine === 'pandas') {{
                patchCodes.pandas = buildPandasPatchSource(
                    state.primaryKey, varInfo, ops, snapshot
                );
            }} else {{
                patchCodes.pyspark = buildPySparkPatchSource(
                    state.primaryKey, varInfo, ops, snapshot
                );
                patchCodes.sql = buildSqlPatchSource(
                    state.primaryKey, varInfo, ops, snapshot
                );
            }}
            exitEditMode(false);
            showCopyPatchModal(patchCodes);
        }}

        function pendingOperations() {{
            var viewer = resolveViewer();
            var pane = resolvePane(viewer);
            var table = document.getElementById(tableId);
            var snapshot = state.snapshot || readSnapshot(pane || viewer);
            if (!table || !snapshot) return [];
            return collectOperations(table, snapshot);
        }}

        function showValidationErrorsModal(errors) {{
            var viewer = resolveViewer();
            var items = errors.map(function(err) {{
                return '<li><strong>' + escapeHtml(err.column) + '</strong>: ' +
                    escapeHtml(err.message) + '</li>';
            }}).join('');
            var backdrop = showDfvDialog(viewer, {{
                title: 'Fix cell values',
                bodyHtml:
                    '<p class="dfv-dialog-message">Some edited cells do not match their column types.</p>' +
                    '<ul class="dfv-dialog-error-list">' + items + '</ul>',
                footerHtml:
                    '<button type="button" class="dfv-dialog-btn dfv-dialog-btn-primary" data-action="ok">OK</button>',
                backdropCloses: true,
                onBackdrop: function() {{ closeDfvDialog(backdrop); }},
                onClose: function() {{ closeDfvDialog(backdrop); }}
            }});
            if (!backdrop) return;
            backdrop.querySelector('[data-action="ok"]').addEventListener('click', function() {{
                closeDfvDialog(backdrop);
            }});
        }}

        function attemptFinishEditMode() {{
            var viewer = resolveViewer();
            var pane = resolvePane(viewer);
            var table = document.getElementById(tableId);
            var snapshot = state.snapshot || readSnapshot(pane || viewer);
            if (table && snapshot) {{
                var validationErrors = collectValidationErrors(table, snapshot);
                if (validationErrors.length) {{
                    showValidationErrorsModal(validationErrors);
                    return;
                }}
            }}
            var ops = pendingOperations();
            if (!ops.length) {{
                exitEditMode(false);
                return;
            }}
            var backdrop = showDfvDialog(viewer, {{
                title: 'Apply edits?',
                bodyHtml:
                    '<p class="dfv-dialog-message">You changed cells in this view. Generate patch code to copy into a cell below?</p>',
                footerHtml:
                    '<button type="button" class="dfv-dialog-btn dfv-dialog-btn-primary" data-action="apply">Generate code</button>' +
                    '<button type="button" class="dfv-dialog-btn" data-action="discard">Discard</button>' +
                    '<button type="button" class="dfv-dialog-btn" data-action="cancel">Keep editing</button>',
                backdropCloses: true,
                onBackdrop: function() {{ closeDfvDialog(backdrop); }},
                onClose: function() {{ closeDfvDialog(backdrop); }}
            }});
            if (!backdrop) return;
            backdrop.querySelector('[data-action="apply"]').addEventListener('click', function() {{
                closeDfvDialog(backdrop);
                commitEdits();
            }});
            backdrop.querySelector('[data-action="discard"]').addEventListener('click', function() {{
                closeDfvDialog(backdrop);
                exitEditMode(true);
            }});
            backdrop.querySelector('[data-action="cancel"]').addEventListener('click', function() {{
                closeDfvDialog(backdrop);
            }});
        }}

        function addDraftRow(table, snapshot) {{
            var tbody = table.querySelector('tbody');
            if (!tbody) return;
            var tr = document.createElement('tr');
            tr.setAttribute('data-dfv-new-row', '1');
            tr.setAttribute('data-dfv-row-index', '-1');
            for (var ci = 0; ci < snapshot.columns.length; ci++) {{
                var td = document.createElement('td');
                td.setAttribute('data-column', String(ci));
                td.setAttribute('data-sort-value', '');
                td.setAttribute('data-dfv-original-json', JSON.stringify(''));
                td.classList.add('dfv-cell-editable', 'dfv-cell-draft');
                td.setAttribute('contenteditable', 'true');
                td.setAttribute('spellcheck', 'false');
                td.innerHTML = '';
                td.addEventListener('input', function() {{ refreshDraft(td); }});
                td.addEventListener('focus', function() {{ focusEmptyEditableCell(td); }});
                tr.appendChild(td);
            }}
            var emptyRow = tbody.querySelector('.column-selector-empty-row');
            if (emptyRow) tbody.insertBefore(tr, emptyRow);
            else tbody.appendChild(tr);
        }}

        function activateEditMode(snapshot) {{
            var viewer = resolveViewer();
            var pane = resolvePane(viewer);
            state.snapshot = snapshot;
            state.active = true;
            btn.classList.add('active');
            btn.setAttribute('aria-pressed', 'true');

            var table = document.getElementById(tableId);
            if (!table) return;
            table.querySelectorAll('tbody tr[data-dfv-row-index]').forEach(function(tr) {{
                if (tr.classList.contains('column-selector-empty-row')) return;
                tr.querySelectorAll('td[data-column]').forEach(function(td) {{
                    if (td.querySelector('.complex-toggle')) return;
                    var origVal = cellValueFromDom(td);
                    if (origVal === undefined) return;
                    if (!prepareEditableCell(td)) return;
                    if (isPkLockedCell(td, tr, snapshot)) {{
                        td.classList.add('dfv-cell-pk-locked');
                        td.title = 'Primary key column cannot be edited';
                        return;
                    }}
                    td.setAttribute('data-dfv-original-json', JSON.stringify(origVal));
                    td.classList.add('dfv-cell-editable');
                    if (origVal === '') {{
                        td.innerHTML = '';
                    }}
                    td.setAttribute('contenteditable', 'true');
                    td.setAttribute('spellcheck', 'false');
                    td.addEventListener('input', function() {{
                        refreshDraft(td);
                    }});
                    td.addEventListener('focus', function() {{ focusEmptyEditableCell(td); }});
                }});
            }});

            if (!state.bar) {{
                var bar = document.createElement('div');
                bar.className = 'dfv-edit-bar';
                bar.innerHTML =
                    '<span class="dfv-edit-bar-label">Draft edits — click cells, then turn off the pencil to finish</span>' +
                    '<button type="button" class="dfv-edit-add-row">Add row</button>';
                var shell = table.closest('.dataframe-table-shell');
                if (shell) shell.appendChild(bar);
                else viewer.appendChild(bar);
                state.bar = bar;
                bar.querySelector('.dfv-edit-add-row').addEventListener('click', function() {{
                    addDraftRow(table, snapshot);
                }});
            }}
        }}

        function promptPrimaryKey(snapshot, onChosen) {{
            var viewer = resolveViewer();
            var selectId = 'dfv-pk-select-' + viewerId;
            var options = snapshot.columns.map(function(c, idx) {{
                var sel = idx === 0 ? ' selected' : '';
                return '<option value="' + escapeHtml(c.name) + '"' + sel + '>' +
                    escapeHtml(c.name) + '</option>';
            }}).join('');
            var backdrop = showDfvDialog(viewer, {{
                title: 'Primary key column',
                bodyHtml:
                    '<p class="dfv-dialog-message">Pick the column that uniquely identifies each row (used for updates).</p>' +
                    '<label class="dfv-dialog-field" for="' + selectId + '">Column</label>' +
                    '<select id="' + selectId + '" class="dfv-dialog-select">' + options + '</select>',
                footerHtml:
                    '<button type="button" class="dfv-dialog-btn dfv-dialog-btn-primary" data-action="ok">Start editing</button>' +
                    '<button type="button" class="dfv-dialog-btn" data-action="cancel">Cancel</button>',
                backdropCloses: true,
                onBackdrop: function() {{ closeDfvDialog(backdrop); }},
                onClose: function() {{ closeDfvDialog(backdrop); }}
            }});
            if (!backdrop) return;
            backdrop.querySelector('[data-action="cancel"]').addEventListener('click', function() {{
                closeDfvDialog(backdrop);
            }});
            backdrop.querySelector('[data-action="ok"]').addEventListener('click', function() {{
                var sel = backdrop.querySelector('#' + selectId);
                var picked = sel ? sel.value : '';
                if (!picked) return;
                var ok = snapshot.columns.some(function(c) {{ return c.name === picked; }});
                if (!ok) return;
                closeDfvDialog(backdrop);
                onChosen(picked);
            }});
        }}

        function enterEditMode() {{
            var viewer = resolveViewer();
            var pane = resolvePane(viewer);
            var engine = (pane && pane.getAttribute('data-engine')) ||
                (viewer && viewer.getAttribute('data-engine')) || '';
            if (!supportsRowEdit(engine)) return;

            var snapshot = readSnapshot(pane || viewer);
            if (!snapshot || !snapshot.columns || !snapshot.columns.length) return;

            if (state.primaryKey) {{
                activateEditMode(snapshot);
                return;
            }}
            promptPrimaryKey(snapshot, function(picked) {{
                state.primaryKey = picked;
                activateEditMode(snapshot);
            }});
        }}

        function syncVisibility() {{
            var viewer = resolveViewer();
            var pane = resolvePane(viewer);
            var engine = (pane && pane.getAttribute('data-engine')) ||
                (viewer && viewer.getAttribute('data-engine')) || '';
            var editable = supportsRowEdit(engine);
            var wrap = btn.closest('.dfv-row-edit-wrap');
            if (wrap) wrap.style.display = editable ? '' : 'none';
            btn.disabled = false;
            btn.title = 'Edit rows — turn off pencil to apply or discard changes';
            if (!editable) {{
                if (state.active) exitEditMode(true);
            }}
        }}

        btn.addEventListener('click', function(e) {{
            e.preventDefault();
            e.stopPropagation();
            if (state.active) attemptFinishEditMode();
            else enterEditMode();
        }});

        syncVisibility();
    }})();"""

# FIX (Bug #2): Sort now reads sort values via data-column attribute on each td
# rather than by positional index. This means hidden columns (via column selector
# or tag filter) no longer cause the sort to read the wrong cell.
_JS_SORT_TMPL = """\
    // ── Column sort — uses data-column attribute, not positional td index ─
    // FIX: previously used tr.querySelectorAll('td')[colIdx] which broke when
    // columns were hidden (column selector / tag filter). Now td lookup is done
    // via data-column attribute, so hidden columns are correctly skipped.
    (function() {{
        var table = document.getElementById('{table_id}');
        if (!table) return;
        var headers = Array.from(table.querySelectorAll('thead th.sortable'));
        var tbody   = table.querySelector('tbody');
        if (!tbody) return;

        // Exclude notice row and "columns hidden" empty row.
        var rowEls = Array.from(tbody.querySelectorAll('tr')).filter(function(tr) {{
            return !tr.querySelector('.filter-show-all') && !tr.classList.contains('column-selector-empty-row');
        }});
        table.__dfvRowPool = rowEls;

        // Snapshot sort keys once keyed by column index, not DOM position,
        // so hide/show operations never invalidate the snapshot.
        var matrix = rowEls.map(function(tr) {{
            var map = {{}};
            Array.from(tr.querySelectorAll('td[data-column]')).forEach(function(td) {{
                map[td.getAttribute('data-column')] = td.getAttribute('data-sort-value') || '';
            }});
            return map;
        }});

        var curCol = null, curDir = null;
        headers.forEach(function(th) {{
            th.addEventListener('click', function() {{
                var ci = th.getAttribute('data-column');
                curDir = (curCol === ci && curDir === 'asc') ? 'desc' : 'asc';
                curCol = ci;
                headers.forEach(function(h) {{ h.classList.remove('sort-asc', 'sort-desc'); }});
                th.classList.add('sort-' + curDir);

                var indices = rowEls.map(function(_, i) {{ return i; }});
                indices.sort(function(a, b) {{
                    var av = matrix[a][ci] != null ? matrix[a][ci] : '';
                    var bv = matrix[b][ci] != null ? matrix[b][ci] : '';
                    if (av === 'null') return  1;
                    if (bv === 'null') return -1;
                    var an = Number(av), bn = Number(bv);
                    if (!isNaN(an) && !isNaN(bn) && String(av).trim() !== '' && String(bv).trim() !== '') {{
                        return curDir === 'asc' ? an - bn : bn - an;
                    }}
                    return curDir === 'asc' ? String(av).localeCompare(bv) : String(bv).localeCompare(av);
                }});
                table.__dfvRowPool = indices.map(function(i) {{ return rowEls[i]; }});
                if (typeof table.__dfvRenderWindow === 'function') {{
                    table.__dfvRenderWindow();
                }} else {{
                    indices.forEach(function(i) {{ tbody.appendChild(rowEls[i]); }});
                }}
            }});
        }});
    }})();"""

_JS_THEME_SYNC_TMPL = """\
    // ── Match JupyterLab light/dark theme ───────────────────────────────
    (function() {{
        var viewer = document.getElementById('{viewer_id}');
        if (!viewer) return;
        function syncTheme() {{
            var body = document.body;
            var isLight = false;
            if (body && body.hasAttribute('data-jp-theme-light')) {{
                isLight = body.getAttribute('data-jp-theme-light') === 'true';
            }} else if (window.matchMedia) {{
                isLight = window.matchMedia('(prefers-color-scheme: light)').matches;
            }}
            viewer.classList.toggle('light-mode', isLight);
        }}
        syncTheme();
        var themeObserver = null;
        if (window.MutationObserver && document.body) {{
            themeObserver = new MutationObserver(syncTheme);
            themeObserver.observe(document.body, {{
                attributes: true,
                attributeFilter: ['data-jp-theme-light', 'data-jp-theme-name']
            }});
        }}
        if (viewer.__moonstormOnCleanup) {{
            viewer.__moonstormOnCleanup(function() {{
                if (themeObserver) {{
                    try {{ themeObserver.disconnect(); }} catch (err) {{}}
                }}
            }});
        }}
    }})();"""

_JS_COL_SELECTOR_TMPL = """\
    // ── Column selector modal ─────────────────────────────────────────────
    (function() {{
        var btn      = document.getElementById('{col_sel_id}');
        var backdrop = document.getElementById('{col_sel_modal_id}');
        var modalBox = backdrop ? backdrop.querySelector('.column-selector-modal') : null;
        var table    = document.getElementById('{table_id}');
        var footerEl = document.getElementById('{footer_id}');
        var total    = {total_columns};
        if (!btn || !backdrop || !table) return;
        function setButtonActive(active) {{
            if (active) btn.classList.add('active'); else btn.classList.remove('active');
        }}
        function closeModal() {{
            backdrop.classList.remove('open');
            setButtonActive(false);
        }}
        btn.addEventListener('click', function(e) {{
            e.stopPropagation();
            backdrop.classList.toggle('open');
            setButtonActive(backdrop.classList.contains('open'));
        }});
        if (modalBox) modalBox.addEventListener('click', function(e) {{ e.stopPropagation(); }});
        backdrop.addEventListener('click', function(e) {{ if (e.target === backdrop) closeModal(); }});
        var closeBtn = backdrop.querySelector('.column-selector-close');
        if (closeBtn) closeBtn.addEventListener('click', closeModal);
        var toggleAllBtn = backdrop.querySelector('.column-selector-toggle-all-btn');
        var emptyRow = table.querySelector('tr.column-selector-empty-row');
        var colNodeCache = Object.create(null);
        function columnNodes(ci) {{
            var key = String(ci);
            if (!colNodeCache[key]) {{
                colNodeCache[key] = {{
                    th: Array.from(table.querySelectorAll('th[data-column="' + key + '"]')),
                    td: Array.from(table.querySelectorAll('td[data-column="' + key + '"]'))
                }};
            }}
            return colNodeCache[key];
        }}
        function applyColumnVisibility(ci, visible) {{
            var nodes = columnNodes(ci);
            nodes.th.forEach(function(el) {{
                el.classList.toggle('column-selector-hidden', !visible);
            }});
            nodes.td.forEach(function(el) {{
                el.classList.toggle('column-selector-hidden', !visible);
            }});
        }}
        // FIX (Bug #5): unified updateFooter used by both this block and the tag
        // filter block — scoped to thead to avoid accidentally counting non-header th
        // elements, and uses a consistent selector across both call sites.
        function updateFooter() {{
            var vis = table.querySelectorAll('thead th:not(.column-selector-hidden)').length;
            if (emptyRow) emptyRow.style.display = vis === 0 ? '' : 'none';
            if (toggleAllBtn) {{
                var stateSelect   = toggleAllBtn.querySelector('.column-selector-toggle-select');
                var stateDeselect = toggleAllBtn.querySelector('.column-selector-toggle-deselect');
                if (stateSelect && stateDeselect) {{
                    stateSelect.style.display   = vis === total ? '' : 'none';
                    stateDeselect.style.display = vis === total ? 'none' : '';
                }}
                toggleAllBtn.setAttribute('title', vis === total ? 'Deselect all columns' : 'Select all columns');
            }}
            if (!footerEl) return;
            if (vis === total) {{
                footerEl.innerHTML = '<strong>' + total + '</strong> columns';
            }} else {{
                footerEl.innerHTML = '<strong>' + vis + '</strong> of <strong>' + total + '</strong> columns';
            }}
            var notice = footerEl.nextElementSibling;
            if (notice && notice.classList.contains('columns-hidden-notice')) {{
                notice.style.display = vis < total ? '' : 'none';
            }}
        }}
        if (toggleAllBtn) toggleAllBtn.addEventListener('click', function() {{
            var vis = table.querySelectorAll('thead th:not(.column-selector-hidden)').length;
            var selectAll = vis < total;
            backdrop.querySelectorAll('.column-selector-check').forEach(function(cb) {{
                cb.checked = selectAll;
                applyColumnVisibility(cb.getAttribute('data-column'), selectAll);
            }});
            updateFooter();
        }});
        backdrop.querySelectorAll('.column-selector-check').forEach(function(cb) {{
            cb.addEventListener('change', function() {{
                applyColumnVisibility(this.getAttribute('data-column'), this.checked);
                updateFooter();
            }});
        }});
    }})();"""

# Lazy pane hydrate: inactive multi-result panes ship as <template> until used.
# Plain JS (no .format placeholders) — use single braces.
_JS_HYDRATE_PANE_TMPL = """\
    // ── Lazy result-pane hydrate ──────────────────────────────────────────
    window.__moonstormDfvBindPane = window.__moonstormDfvBindPane || {};
    window.__moonstormDfvHydratePane = function(pane) {
        if (!pane || pane.getAttribute('data-dfv-hydrated') === '1') return pane;
        var tpl = null;
        for (var c = 0; c < pane.children.length; c++) {
            var child = pane.children[c];
            if (
                child.tagName === 'TEMPLATE' &&
                child.classList.contains('dataframe-result-pane-template')
            ) {
                tpl = child;
                break;
            }
        }
        if (tpl) {
            pane.appendChild(tpl.content);
            tpl.remove();
        }
        pane.setAttribute('data-dfv-hydrated', '1');
        var table = pane.querySelector('table.dataframe-table');
        var bindKey = table && table.id;
        var binder = bindKey && window.__moonstormDfvBindPane[bindKey];
        if (typeof binder === 'function') binder();
        return pane;
    };
    window.__moonstormDfvHydrateAllPanes = function(root) {
        if (!root) return;
        root.querySelectorAll('.dataframe-result-pane').forEach(function(pane) {
            window.__moonstormDfvHydratePane(pane);
        });
    };"""

# Switch Result N tabs inside a multi-statement SQL dataframe viewer.
_JS_RESULT_TABS_TMPL = """\
    (function() {{
        var viewer = document.getElementById('{viewer_id}');
        if (!viewer) return;
        var tabs = Array.from(viewer.querySelectorAll('.dataframe-result-tab'));
        if (tabs.length < 2) return;

        function activate(index) {{
            tabs.forEach(function(tab) {{
                var selected = tab.getAttribute('data-result-index') === String(index);
                tab.setAttribute('aria-selected', selected ? 'true' : 'false');
                tab.tabIndex = selected ? 0 : -1;
            }});
            viewer.querySelectorAll('.dataframe-result-pane').forEach(function(pane) {{
                var on = pane.getAttribute('data-result-index') === String(index);
                if (on) {{
                    if (window.__moonstormDfvHydratePane) {{
                        window.__moonstormDfvHydratePane(pane);
                    }}
                    pane.removeAttribute('hidden');
                }} else {{
                    pane.setAttribute('hidden', '');
                }}
            }});
            viewer.querySelectorAll('.dataframe-result-controls').forEach(function(ctrl) {{
                var on = ctrl.getAttribute('data-result-index') === String(index);
                if (on) ctrl.removeAttribute('hidden');
                else ctrl.setAttribute('hidden', '');
            }});
            try {{
                var frame = window.frameElement;
                if (frame && frame.style) {{
                    var doc = document.documentElement;
                    var body = document.body;
                    frame.style.height = Math.max(
                        body ? body.scrollHeight : 0,
                        doc ? doc.scrollHeight : 0
                    ) + 'px';
                }}
            }} catch (e) {{}}
        }}

        tabs.forEach(function(tab) {{
            tab.addEventListener('click', function(event) {{
                event.preventDefault();
                event.stopPropagation();
                activate(tab.getAttribute('data-result-index'));
            }});
        }});
    }})();"""

# Break a multi-result viewer into standalone viewers; merge reconstitutes tabs.
_JS_SPLIT_RESULTS_TMPL = """\
    (function() {{
        var viewer = document.getElementById('{viewer_id}');
        var splitBtn = document.getElementById('{split_btn_id}');
        if (!viewer || !splitBtn) return;

        var minH = {min_height};
        var maxH = {max_height};
        var mergeBtnHtml = {merge_btn_html};
        window.__moonstormDfvSplit = window.__moonstormDfvSplit || {{}};

        function syncHostFrame() {{
            try {{
                var frame = window.frameElement;
                if (frame && frame.style) {{
                    var doc = document.documentElement;
                    var body = document.body;
                    frame.style.height = Math.max(
                        body ? body.scrollHeight : 0,
                        doc ? doc.scrollHeight : 0
                    ) + 'px';
                }}
            }} catch (e) {{}}
        }}

        function bindTheme(target) {{
            function syncTheme() {{
                var body = document.body;
                var isLight = false;
                if (body && body.hasAttribute('data-jp-theme-light')) {{
                    isLight = body.getAttribute('data-jp-theme-light') === 'true';
                }} else if (window.matchMedia) {{
                    isLight = window.matchMedia('(prefers-color-scheme: light)').matches;
                }}
                target.classList.toggle('light-mode', isLight);
            }}
            syncTheme();
            if (window.MutationObserver && document.body) {{
                var obs = new MutationObserver(syncTheme);
                obs.observe(document.body, {{
                    attributes: true,
                    attributeFilter: ['data-jp-theme-light', 'data-jp-theme-name']
                }});
            }}
        }}

        function bindMinimize(target) {{
            var btn = target.querySelector('.dataframe-minimize-btn');
            var banner = target.querySelector('.dataframe-minimized-banner');
            var maximizeBtn = target.querySelector('.dataframe-maximize-btn');
            var trayOpenTab = target.querySelector('.dataframe-minimized-open-tab');
            if (!btn || !banner || btn._dfvMinBound) return;
            btn._dfvMinBound = true;

            function setMinimized(on) {{
                if (on) {{
                    target.setAttribute('data-minimized', 'true');
                    btn.setAttribute('aria-pressed', 'true');
                    btn.title = 'Restore dataframe';
                }} else {{
                    target.removeAttribute('data-minimized');
                    btn.setAttribute('aria-pressed', 'false');
                    btn.title = 'Minimize dataframe';
                }}
                syncHostFrame();
            }}

            btn.addEventListener('click', function(event) {{
                event.preventDefault();
                event.stopPropagation();
                setMinimized(target.getAttribute('data-minimized') !== 'true');
            }});
            function restore(event) {{
                event.preventDefault();
                event.stopPropagation();
                setMinimized(false);
            }}
            banner.addEventListener('click', restore);
            if (maximizeBtn) maximizeBtn.addEventListener('click', restore);
            if (trayOpenTab) {{
                trayOpenTab.addEventListener('click', function(event) {{
                    event.preventDefault();
                    event.stopPropagation();
                    var openBtn = target.querySelector(
                        '.dataframe-result-pane:not([hidden]) .dataframe-open-tab-btn'
                    ) || target.querySelector('.dataframe-open-tab-btn');
                    if (openBtn) openBtn.click();
                }});
            }}
        }}

        function bindHeight(target) {{
            var shells = target.querySelectorAll('.dataframe-table-shell');
            shells.forEach(function(shell) {{
                var handle = shell.querySelector('.dataframe-resize-corner');
                if (!handle || handle._dfvHeightBound) return;
                handle._dfvHeightBound = true;

                function clampHeight(px) {{
                    var vhCap = Math.floor(window.innerHeight * 0.85);
                    return Math.max(minH, Math.min(maxH, vhCap, Math.round(px)));
                }}

                handle.addEventListener('pointerdown', function(e) {{
                    if (e.button != null && e.button !== 0) return;
                    e.preventDefault();
                    e.stopPropagation();
                    var startY = e.screenY;
                    var startH = shell.getBoundingClientRect().height;
                    handle.classList.add('is-dragging');
                    document.body.style.cursor = 'ns-resize';
                    document.body.style.userSelect = 'none';
                    try {{ handle.setPointerCapture(e.pointerId); }} catch (err) {{}}

                    function onMove(ev) {{
                        shell.style.height = clampHeight(startH + (ev.screenY - startY)) + 'px';
                        syncHostFrame();
                    }}
                    function onUp() {{
                        handle.classList.remove('is-dragging');
                        document.body.style.cursor = '';
                        document.body.style.userSelect = '';
                        handle.removeEventListener('pointermove', onMove);
                        handle.removeEventListener('pointerup', onUp);
                        handle.removeEventListener('pointercancel', onUp);
                        syncHostFrame();
                    }}
                    handle.addEventListener('pointermove', onMove);
                    handle.addEventListener('pointerup', onUp);
                    handle.addEventListener('pointercancel', onUp);
                }});
            }});
        }}

        function bindTabs(target) {{
            var tabs = Array.from(target.querySelectorAll('.dataframe-result-tab'));
            if (tabs.length < 2) return;

            function activate(index) {{
                tabs.forEach(function(tab) {{
                    var selected = tab.getAttribute('data-result-index') === String(index);
                    tab.setAttribute('aria-selected', selected ? 'true' : 'false');
                    tab.tabIndex = selected ? 0 : -1;
                }});
                target.querySelectorAll('.dataframe-result-pane').forEach(function(pane) {{
                    var on = pane.getAttribute('data-result-index') === String(index);
                    if (on) {{
                        if (window.__moonstormDfvHydratePane) {{
                            window.__moonstormDfvHydratePane(pane);
                        }}
                        pane.removeAttribute('hidden');
                    }} else {{
                        pane.setAttribute('hidden', '');
                    }}
                }});
                target.querySelectorAll('.dataframe-result-controls').forEach(function(ctrl) {{
                    var on = ctrl.getAttribute('data-result-index') === String(index);
                    if (on) ctrl.removeAttribute('hidden');
                    else ctrl.setAttribute('hidden', '');
                }});
                syncHostFrame();
            }}

            tabs.forEach(function(tab) {{
                if (tab._dfvTabBound) return;
                tab._dfvTabBound = true;
                tab.addEventListener('click', function(event) {{
                    event.preventDefault();
                    event.stopPropagation();
                    activate(tab.getAttribute('data-result-index'));
                }});
            }});
        }}

        function bindMerge(target) {{
            var btn = target.querySelector('.dataframe-merge-btn');
            if (!btn || btn._dfvMergeBound) return;
            btn._dfvMergeBound = true;
            btn.addEventListener('click', function(event) {{
                event.preventDefault();
                event.stopPropagation();

                var groupId = target.getAttribute('data-dfv-split-group');
                if (!groupId) return;
                var members = Array.from(document.querySelectorAll(
                    '.dataframe-viewer[data-dfv-split-group="' + groupId + '"]'
                ));
                members.sort(function(a, b) {{
                    return (parseInt(a.getAttribute('data-dfv-split-index'), 10) || 0) -
                        (parseInt(b.getAttribute('data-dfv-split-index'), 10) || 0);
                }});
                if (members.length < 2) return;

                var meta = window.__moonstormDfvSplit[groupId] || {{}};
                var baseId = meta.baseId || groupId;
                var splitHtml = meta.splitBtnHtml || '';
                var parent = members[0].parentNode;
                if (!parent) return;

                var merged = document.createElement('div');
                merged.className = 'dataframe-viewer';
                merged.id = baseId;
                merged.setAttribute(
                    'data-engine',
                    members[0].getAttribute('data-engine') || 'dataframe'
                );
                merged.setAttribute('data-result-count', String(members.length));
                if (members[0].classList.contains('light-mode')) {{
                    merged.classList.add('light-mode');
                }}

                var chromeSrc = members[0].querySelector('.dataframe-minimized-chrome');
                if (chromeSrc) merged.appendChild(chromeSrc.cloneNode(true));

                var header = document.createElement('div');
                header.className = 'dataframe-header';
                header.setAttribute(
                    'data-engine',
                    merged.getAttribute('data-engine') || 'dataframe'
                );
                var bar = document.createElement('div');
                bar.className = 'dataframe-header-bar';
                var tabs = document.createElement('div');
                tabs.className = 'dataframe-result-tabs';
                tabs.setAttribute('role', 'tablist');
                tabs.setAttribute('aria-label', 'SQL results');
                var actions = document.createElement('div');
                actions.className = 'dataframe-header-actions';

                var panesFrag = document.createDocumentFragment();
                members.forEach(function(member, i) {{
                    var idx = member.getAttribute('data-dfv-split-index') || String(i);
                    var label = member.getAttribute('data-dfv-split-label') ||
                        ('Result ' + (i + 1));
                    var title = member.getAttribute('data-dfv-split-title') || label;
                    var engine = member.getAttribute('data-engine') ||
                        merged.getAttribute('data-engine') ||
                        'dataframe';
                    var selected = i === 0;

                    var tab = document.createElement('button');
                    tab.type = 'button';
                    tab.className = 'dataframe-result-tab';
                    tab.setAttribute('role', 'tab');
                    tab.id = baseId + '-tab-' + idx;
                    tab.setAttribute('data-result-index', idx);
                    tab.setAttribute('aria-controls', baseId + '-pane-' + idx);
                    tab.setAttribute('aria-selected', selected ? 'true' : 'false');
                    tab.tabIndex = selected ? 0 : -1;
                    tab.title = title;
                    tab.textContent = label;
                    tabs.appendChild(tab);

                    var controls = document.createElement('span');
                    controls.className = 'dataframe-result-controls';
                    controls.setAttribute('data-result-index', idx);
                    if (!selected) controls.setAttribute('hidden', '');
                    var memberActions = member.querySelector('.dataframe-header-actions');
                    if (memberActions) {{
                        Array.from(memberActions.children).forEach(function(child) {{
                            if (
                                child.querySelector &&
                                (child.querySelector('.dataframe-merge-btn') ||
                                    child.querySelector('.dataframe-minimize-btn'))
                            ) {{
                                return;
                            }}
                            controls.appendChild(child);
                        }});
                    }}
                    actions.appendChild(controls);

                    var pane = document.createElement('div');
                    pane.className = 'dataframe-result-pane';
                    pane.id = baseId + '-pane-' + idx;
                    pane.setAttribute('role', 'tabpanel');
                    pane.setAttribute('aria-labelledby', baseId + '-tab-' + idx);
                    pane.setAttribute('data-result-index', idx);
                    pane.setAttribute('data-engine', engine);
                    pane.setAttribute('data-label', label);
                    pane.title = title;
                    if (!selected) pane.setAttribute('hidden', '');
                    Array.from(member.children).forEach(function(child) {{
                        if (
                            child.classList &&
                            (child.classList.contains('dataframe-header') ||
                                child.classList.contains('dataframe-minimized-chrome'))
                        ) {{
                            return;
                        }}
                        pane.appendChild(child);
                    }});
                    panesFrag.appendChild(pane);
                }});

                if (splitHtml) {{
                    var splitHost = document.createElement('div');
                    splitHost.innerHTML = splitHtml;
                    var splitWrap = splitHost.firstElementChild;
                    if (splitWrap) {{
                        var newSplitBtn = splitWrap.querySelector('.dataframe-split-btn');
                        if (newSplitBtn) {{
                            newSplitBtn.id = baseId + '-split-btn';
                            newSplitBtn._dfvSplitBound = false;
                        }}
                        actions.appendChild(splitWrap);
                    }}
                }}

                var minTemplate = members[0].querySelector('.dataframe-minimize-btn');
                if (minTemplate) {{
                    var minWrap = document.createElement('span');
                    minWrap.className = 'column-selector-wrap';
                    var minBtn = minTemplate.cloneNode(true);
                    minBtn.id = baseId + '_min';
                    minBtn.setAttribute('aria-pressed', 'false');
                    minBtn.title = 'Minimize dataframe';
                    minBtn._dfvMinBound = false;
                    minWrap.appendChild(minBtn);
                    actions.appendChild(minWrap);
                }}

                bar.appendChild(tabs);
                bar.appendChild(actions);
                header.appendChild(bar);
                merged.appendChild(header);
                merged.appendChild(panesFrag);

                // Keep minimized chrome above the header when present.
                var chromeNow = merged.querySelector('.dataframe-minimized-chrome');
                if (chromeNow) merged.insertBefore(chromeNow, header);

                parent.insertBefore(merged, members[0]);

                members.forEach(function(member) {{ member.remove(); }});
                delete window.__moonstormDfvSplit[groupId];

                bindTheme(merged);
                bindMinimize(merged);
                bindHeight(merged);
                bindTabs(merged);
                var reboundSplit = document.getElementById(baseId + '-split-btn');
                if (reboundSplit) bindSplit(merged, reboundSplit);
                syncHostFrame();
            }});
        }}

        function bindSplit(root, btn) {{
            if (!root || !btn || btn._dfvSplitBound) return;
            btn._dfvSplitBound = true;
            btn.addEventListener('click', function(event) {{
                event.preventDefault();
                event.stopPropagation();

                var panes = Array.from(root.querySelectorAll('.dataframe-result-pane'));
                if (panes.length < 2) return;

                var parent = root.parentNode;
                if (!parent) return;
                if (window.__moonstormDfvHydrateAllPanes) {{
                    window.__moonstormDfvHydrateAllPanes(root);
                }}
                var chrome = root.querySelector('.dataframe-minimized-chrome');
                var minBtnTemplate = root.querySelector('.dataframe-minimize-btn');
                var splitWrap = btn.closest('.column-selector-wrap');
                var groupId = root.id;
                var frag = document.createDocumentFragment();
                var created = [];

                window.__moonstormDfvSplit[groupId] = {{
                    baseId: root.id,
                    splitBtnHtml: splitWrap ? splitWrap.outerHTML : ''
                }};

                panes.forEach(function(pane, i) {{
                    var idx = pane.getAttribute('data-result-index') || String(i);
                    var engine = pane.getAttribute('data-engine') ||
                        root.getAttribute('data-engine') ||
                        'dataframe';
                    var tab = root.querySelector(
                        '.dataframe-result-tab[data-result-index="' + idx + '"]'
                    );
                    var label = pane.getAttribute('data-label') ||
                        (tab && tab.textContent.trim()) ||
                        ('Result ' + (i + 1));
                    var title = pane.getAttribute('title') ||
                        (tab && tab.title) ||
                        label;
                    var newId = root.id + '_split_' + idx;
                    var newViewer = document.createElement('div');
                    newViewer.className = 'dataframe-viewer';
                    newViewer.id = newId;
                    newViewer.setAttribute('data-engine', engine);
                    newViewer.setAttribute('data-dfv-split-group', groupId);
                    newViewer.setAttribute('data-dfv-split-index', idx);
                    newViewer.setAttribute('data-dfv-split-label', label);
                    newViewer.setAttribute('data-dfv-split-title', title);
                    if (root.classList.contains('light-mode')) {{
                        newViewer.classList.add('light-mode');
                    }}

                    if (chrome) {{
                        newViewer.appendChild(chrome.cloneNode(true));
                    }}

                    var header = document.createElement('div');
                    header.className = 'dataframe-header';
                    header.setAttribute('data-engine', engine);
                    var bar = document.createElement('div');
                    bar.className = 'dataframe-header-bar';
                    var actions = document.createElement('div');
                    actions.className = 'dataframe-header-actions';

                    var controls = root.querySelector(
                        '.dataframe-result-controls[data-result-index="' + idx + '"]'
                    );
                    if (controls) {{
                        while (controls.firstChild) {{
                            actions.appendChild(controls.firstChild);
                        }}
                    }}

                    var mergeHost = document.createElement('div');
                    mergeHost.innerHTML = mergeBtnHtml;
                    if (mergeHost.firstElementChild) {{
                        actions.appendChild(mergeHost.firstElementChild);
                    }}

                    if (minBtnTemplate) {{
                        var minWrap = document.createElement('span');
                        minWrap.className = 'column-selector-wrap';
                        var minBtn = minBtnTemplate.cloneNode(true);
                        minBtn.id = newId + '_min';
                        minBtn.setAttribute('aria-pressed', 'false');
                        minBtn.title = 'Minimize dataframe';
                        minBtn._dfvMinBound = false;
                        minWrap.appendChild(minBtn);
                        actions.appendChild(minWrap);
                    }}

                    bar.appendChild(actions);
                    header.appendChild(bar);
                    newViewer.appendChild(header);

                    pane.removeAttribute('hidden');
                    while (pane.firstChild) {{
                        newViewer.appendChild(pane.firstChild);
                    }}

                    frag.appendChild(newViewer);
                    created.push(newViewer);
                }});

                parent.insertBefore(frag, root);
                root.remove();

                created.forEach(function(target) {{
                    bindTheme(target);
                    bindMinimize(target);
                    bindHeight(target);
                    bindMerge(target);
                }});
                syncHostFrame();
            }});
        }}

        bindSplit(viewer, splitBtn);
    }})();"""

# FIX (Bug #5): column selector uses thead-scoped selector for visible column count.

def _render_pane_script_blocks(
    ids: _ViewerIds,
    total_columns: int,
    *,
    defer_until_table: bool = False,
) -> List[str]:
    """Scripts that bind to one result pane (or a single-viewer table).

    When ``defer_until_table`` is True (multi-result inactive panes), bindings
    register under ``__moonstormDfvBindPane[tableId]`` and run on first hydrate.
    """
    blocks = [
        _JS_TOGGLE_FN_TMPL.format(
            uid=ids.uid,
            table_id=ids.table,
            viewer_id=ids.viewer,
        ),
        _JS_RESIZE_TMPL.format(table_id=ids.table, viewer_id=ids.viewer),
        _JS_OPEN_TAB_TMPL.format(
            viewer_id=ids.viewer,
            open_tab_btn_id=ids.open_tab_btn,
        ),
        _JS_ROW_EDIT_TMPL.format(
            viewer_id=ids.viewer,
            edit_btn_id=ids.edit_btn,
            table_id=ids.table,
        ),
        _JS_SORT_TMPL.format(table_id=ids.table),
        _JS_COL_SELECTOR_TMPL.format(
            col_sel_id=ids.col_sel,
            col_sel_modal_id=ids.col_sel_modal,
            table_id=ids.table,
            footer_id=ids.footer,
            total_columns=total_columns,
        ),
    ]
    if not defer_until_table:
        return blocks
    # Avoid f-strings here: pane JS contains `{` / `}` that must stay literal.
    table_key = json.dumps(ids.table)
    inner = "\n".join(blocks)
    wrapper = """
    (function() {
        window.__moonstormDfvBindPane = window.__moonstormDfvBindPane || {};
        window.__moonstormDfvBindPane[__TABLE__] = function() {
            var entry = window.__moonstormDfvBindPane[__TABLE__];
            if (entry && entry._done) return;
            if (entry) entry._done = true;
__INNER__
        };
        if (document.getElementById(__TABLE__)) {
            window.__moonstormDfvBindPane[__TABLE__]();
        }
    })();"""
    return [
        wrapper.replace("__TABLE__", table_key).replace("__INNER__", inner)
    ]


def _render_scripts(
    ids: _ViewerIds,
    total_columns: int,
) -> str:
    """
    Assemble the per-viewer <script> block by filling named placeholders into
    each static JS template. Each template section is kept as a plain string
    constant above so it can be read and edited without worrying about {{ / }}
    escaping in unrelated code.
    """
    blocks = [
        "<script>",
        _JS_TEARDOWN_TMPL.format(viewer_id=ids.viewer),
        *_render_pane_script_blocks(ids, total_columns),
        _JS_HEIGHT_RESIZE_TMPL.format(
            viewer_id=ids.viewer,
            min_height=_PANEL_MIN_HEIGHT_PX,
            max_height=_PANEL_MAX_HEIGHT_PX,
        ),
        _JS_MINIMIZE_TMPL.format(
            viewer_id=ids.viewer,
            minimize_btn_id=ids.minimize_btn,
            open_tab_btn_id=ids.open_tab_btn,
        ),
        _JS_THEME_SYNC_TMPL.format(
            viewer_id=ids.viewer,
        ),
        "</script>",
    ]
    return "\n".join(blocks)


def _render_multi_scripts(
    base: _ViewerIds,
    pane_specs: Sequence[Tuple[_ViewerIds, int]],
) -> str:
    """Shared chrome scripts + per-pane bindings for multi-result viewers."""
    blocks = [
        "<script>",
        _JS_TEARDOWN_TMPL.format(viewer_id=base.viewer),
        _JS_HYDRATE_PANE_TMPL,
        _JS_HEIGHT_RESIZE_TMPL.format(
            viewer_id=base.viewer,
            min_height=_PANEL_MIN_HEIGHT_PX,
            max_height=_PANEL_MAX_HEIGHT_PX,
        ),
        _JS_MINIMIZE_TMPL.format(
            viewer_id=base.viewer,
            minimize_btn_id=base.minimize_btn,
            open_tab_btn_id=pane_specs[0][0].open_tab_btn,
        ),
        _JS_THEME_SYNC_TMPL.format(viewer_id=base.viewer),
        _JS_RESULT_TABS_TMPL.format(viewer_id=base.viewer),
        _JS_SPLIT_RESULTS_TMPL.format(
            viewer_id=base.viewer,
            split_btn_id=f"{base.viewer}-split-btn",
            min_height=_PANEL_MIN_HEIGHT_PX,
            max_height=_PANEL_MAX_HEIGHT_PX,
            merge_btn_html=json.dumps(_render_merge_button()),
        ),
    ]
    for pane_ids, total_columns in pane_specs:
        blocks.extend(
            _render_pane_script_blocks(
                pane_ids, total_columns, defer_until_table=True
            )
        )
    blocks.append("</script>")
    return "\n".join(blocks)


# ---------------------------------------------------------------------------
# Step 9 — HTML sub-renderers
# ---------------------------------------------------------------------------

def _render_column_selector_modal(ids: _ViewerIds, col_metas: List[_ColumnMeta]) -> str:
    """Backdrop + centered modal with header (title + X) and scrollable checkbox list."""
    rows = "".join(
        f'<label class="column-selector-row">'
        f'<input type="checkbox" class="column-selector-check" data-column="{ci}" checked>'
        f'<span>{_html.escape(cm.name, quote=True)}</span></label>'
        for ci, cm in enumerate(col_metas)
    )
    return (
        f'<div class="column-selector-backdrop" id="{ids.col_sel_modal}">'
        f'<div class="column-selector-modal" role="dialog" aria-modal="true" aria-labelledby="{ids.col_sel_modal}-title">'
        f'<div class="column-selector-modal-header">'
        f'<span class="column-selector-title-row">'
        f'<span class="column-selector-modal-title" id="{ids.col_sel_modal}-title">Columns</span>'
        f'<button type="button" class="column-selector-toggle-all-btn" title="Select all columns">'
        f'<span class="column-selector-toggle-state column-selector-toggle-select">{ICON_LAYERS}</span>'
        f'<span class="column-selector-toggle-state column-selector-toggle-deselect" style="display:none">{ICON_LAYERS_DESELECTED}</span>'
        f'</button>'
        f'</span>'
        f'<button type="button" class="column-selector-close" aria-label="Close">&times;</button>'
        f'</div>'
        f'<div class="column-selector-modal-body">{rows}</div>'
        f'</div></div>'
    )


def _render_pane_action_buttons(ids: _ViewerIds, engine: str = "") -> str:
    open_tab_btn = (
        f'<span class="column-selector-wrap">'
        f'<button type="button" class="column-filter-btn dataframe-open-tab-btn" '
        f'id="{ids.open_tab_btn}" title="Open in tab">'
        f'{ICON_OPEN_TAB}</button>'
        f'</span>'
    )
    col_sel_btn = (
        f'<span class="column-selector-wrap">'
        f'<button type="button" class="column-filter-btn column-selector-btn" id="{ids.col_sel}" '
        f'title="Show/hide columns">{ICON_COLUMNS}</button>'
        f'</span>'
    )
    edit_btn = ""
    if engine in ("pyspark", "pandas"):
        edit_btn = (
            f'<span class="column-selector-wrap dfv-row-edit-wrap">'
            f'<button type="button" class="column-filter-btn dataframe-row-edit-btn" '
            f'id="{ids.edit_btn}" title="Edit rows" aria-pressed="false">'
            f'{ICON_ROW_EDIT}</button>'
            f'</span>'
        )
    return f'{col_sel_btn}{open_tab_btn}{edit_btn}'


def _render_minimize_button(ids: _ViewerIds) -> str:
    return (
        f'<span class="column-selector-wrap">'
        f'<button type="button" class="column-filter-btn dataframe-minimize-btn" '
        f'id="{ids.minimize_btn}" title="Minimize dataframe" aria-pressed="false">'
        f'{ICON_MINIMIZE}</button>'
        f'</span>'
    )


def _render_split_button(viewer_id: str) -> str:
    return (
        f'<span class="column-selector-wrap">'
        f'<button type="button" class="column-filter-btn dataframe-split-btn" '
        f'id="{viewer_id}-split-btn" title="Break into separate viewers" '
        f'aria-label="Break into separate viewers">'
        f'{ICON_SPLIT}</button>'
        f'</span>'
    )


def _render_merge_button() -> str:
    return (
        f'<span class="column-selector-wrap">'
        f'<button type="button" class="column-filter-btn dataframe-merge-btn" '
        f'title="Merge into one viewer" aria-label="Merge into one viewer">'
        f'{ICON_MERGE}</button>'
        f'</span>'
    )


def _render_header(ids: _ViewerIds, engine: str) -> str:
    return (
        f'<div class="dataframe-header" data-engine="{_html.escape(engine, quote=True)}">'
        f'<div class="dataframe-header-bar">'
        f'<div class="dataframe-header-actions">'
        f'{_render_pane_action_buttons(ids, engine)}{_render_minimize_button(ids)}'
        f'</div>'
        f'</div>'
        f'</div>'
    )


def _render_multi_header(
    base: _ViewerIds,
    pane_ids: List[_ViewerIds],
    labels: List[str],
    titles: List[str],
    engine: str,
    pane_engines: Sequence[str],
) -> str:
    tabs = []
    controls = []
    for i, pane in enumerate(pane_ids):
        selected = i == 0
        tabs.append(
            f'<button type="button" class="dataframe-result-tab" role="tab" '
            f'id="{base.viewer}-tab-{i}" data-result-index="{i}" '
            f'aria-controls="{base.viewer}-pane-{i}" '
            f'aria-selected="{"true" if selected else "false"}" '
            f'tabindex="{0 if selected else -1}" '
            f'title="{_html.escape(titles[i], quote=True)}">'
            f'{_html.escape(labels[i])}</button>'
        )
        hidden = "" if selected else " hidden"
        controls.append(
            f'<span class="dataframe-result-controls" data-result-index="{i}"{hidden}>'
            f'{_render_pane_action_buttons(pane, pane_engines[i] if i < len(pane_engines) else engine)}'
            f'</span>'
        )
    return (
        f'<div class="dataframe-header" data-engine="{_html.escape(engine, quote=True)}">'
        f'<div class="dataframe-header-bar">'
        f'<div class="dataframe-result-tabs" role="tablist" '
        f'aria-label="SQL results">{"".join(tabs)}</div>'
        f'<div class="dataframe-header-actions">'
        f'{"".join(controls)}'
        f'{_render_split_button(base.viewer)}'
        f'{_render_minimize_button(base)}'
        f'</div>'
        f'</div>'
        f'</div>'
    )


def _render_minimized_chrome() -> str:
    """Collapsed-output-style row: warning banner + open-tab / maximize tray."""
    return (
        f'<div class="dataframe-minimized-chrome">'
        f'<button type="button" class="dataframe-minimized-banner" '
        f'title="Click to restore dataframe" '
        f'aria-label="DataFrame is minimized. Click to restore.">'
        f'<span class="dataframe-minimized-icon" aria-hidden="true">'
        f'{ICON_MINIMIZE_BANNER}</span>'
        f'<span class="dataframe-minimized-label">DataFrame minimized</span>'
        f'</button>'
        f'<div class="dataframe-minimized-tray" role="toolbar" aria-label="DataFrame actions">'
        f'<button type="button" class="dataframe-minimized-tray-btn dataframe-minimized-open-tab" '
        f'title="Open in tab" aria-label="Open in tab">{ICON_OPEN_TAB_TRAY}</button>'
        f'<button type="button" class="dataframe-minimized-tray-btn dataframe-maximize-btn" '
        f'title="Restore dataframe" aria-label="Restore dataframe">{ICON_MAXIMIZE}</button>'
        f'</div>'
        f'</div>'
    )


def _open_tab_cell_dict(value, data_type) -> dict:
    """Serialize one cell for lazy open-tab (no DOM scrape)."""
    if _is_null(value):
        return {"text": "", "sort": "", "isNull": True}
    sort_val = _sort_attr_value(value)
    complex_type = _complex_display_type(value, data_type)
    if complex_type is not None:
        try:
            preview, json_str = _complex_cell_payload(value, complex_type)
        except Exception:
            json_str = str(value)
            preview = str(value)
        return {
            "text": preview,
            "sort": sort_val,
            "isNull": False,
            "complex": {"preview": preview, "json": json_str},
        }
    text = str(value) if not isinstance(value, bool) else str(value)
    return {"text": text, "sort": sort_val, "isNull": False}


def _build_open_tab_payload(
    col_metas: List[_ColumnMeta],
    data: _TableData,
    *,
    viewer_id: str,
    engine: str,
    title: str,
    result_label: str = "",
) -> str:
    columns = [
        {
            "name": cm.name,
            "dtype": cm.display_dtype,
            "type": cm.type_str,
        }
        for cm in col_metas
    ]
    rows = []
    for row in data.display_rows:
        cells = []
        for cm in col_metas:
            value = row[cm.name]
            cells.append(_open_tab_cell_dict(value, cm.data_type))
        rows.append(cells)
    payload = {
        "type": "moonstorm-dfv-open-tab",
        "viewerId": viewer_id,
        "title": title,
        "engine": engine,
        "columns": columns,
        "rows": rows,
    }
    if result_label:
        payload["resultLabel"] = result_label
    return json.dumps(payload, ensure_ascii=False)


def _pandas_validation_type(data_type: object, type_str: str = "") -> str:
    """Type label for client validation / pandas patch hints (matches Spark categories)."""
    text = (type_str or str(data_type)).lower()
    if "bool" in text:
        return "BOOLEAN"
    if "datetime64" in text or "timestamp" in text:
        return "TIMESTAMP"
    if "date" in text and "datetime" not in text:
        return "DATE"
    if "int64" in text or text in ("int64", "uint64"):
        return "BIGINT"
    if any(t in text for t in ("int32", "int16", "int8", "int")) and "point" not in text:
        return "INT"
    if any(t in text for t in ("float64", "float32", "float")):
        return "DOUBLE"
    return "STRING"


def _edit_validation_type(engine: str, data_type: object, type_str: str = "") -> str:
    if engine == "pandas":
        return _pandas_validation_type(data_type, type_str)
    return _spark_sql_cast_type(data_type, type_str)


def _spark_sql_cast_type(data_type: object, type_str: str = "") -> str:
    """Spark SQL type name for ``try_cast(... AS TYPE)`` in generated patch code."""
    try:
        from pyspark.sql.types import DataType

        if isinstance(data_type, DataType):
            return data_type.simpleString().upper()
    except Exception:
        pass
    text = (type_str or "").lower()
    if "long" in text or "bigint" in text:
        return "BIGINT"
    if "int" in text and "point" not in text:
        return "INT"
    if "double" in text:
        return "DOUBLE"
    if "float" in text:
        return "FLOAT"
    if "bool" in text:
        return "BOOLEAN"
    if "timestamp" in text:
        return "TIMESTAMP"
    if "date" in text:
        return "DATE"
    if "decimal" in text:
        return "DECIMAL(38,18)"
    return "STRING"


def _build_edit_snapshot(
    col_metas: List[_ColumnMeta],
    data: _TableData,
    *,
    engine: str,
) -> str:
    columns = [
        {
            "name": cm.name,
            "sqlType": _edit_validation_type(engine, cm.data_type, cm.type_str),
        }
        for cm in col_metas
    ]
    rows: List[List[object]] = []
    for row in data.display_rows:
        rows.append([_to_json_safe(row[cm.name]) for cm in col_metas])
    return json.dumps(
        {"engine": engine, "columns": columns, "rows": rows},
        ensure_ascii=False,
    )


def _render_edit_snapshot_script(
    ids: _ViewerIds,
    col_metas: List[_ColumnMeta],
    data: _TableData,
    *,
    engine: str,
) -> str:
    payload = _build_edit_snapshot(col_metas, data, engine=engine)
    safe = payload.replace("</", "<\\/")
    return (
        f'<script type="application/json" id="{ids.viewer}-edit-{ids.uid}" '
        f'data-dfv-edit-snapshot="1">{safe}</script>'
    )


def _render_open_tab_payload_script(
    ids: _ViewerIds,
    col_metas: List[_ColumnMeta],
    data: _TableData,
    *,
    engine: str,
    title: str = "DataFrame",
    result_label: str = "",
) -> str:
    payload = _build_open_tab_payload(
        col_metas,
        data,
        viewer_id=ids.viewer,
        engine=engine,
        title=title,
        result_label=result_label,
    )
    safe = payload.replace("</", "<\\/")
    return (
        f'<script type="application/json" id="{ids.viewer}-open-tab-{ids.uid}" '
        f'data-dfv-open-tab="1">{safe}</script>'
    )


def _render_table(
    ids: _ViewerIds,
    col_metas: List[_ColumnMeta],
    data: _TableData,
) -> str:
    # FIX (Perf #1): use io.StringIO to avoid O(n) list-of-strings overhead;
    # write() is a single call per piece rather than building many intermediate
    # f-strings that all get joined at the end.
    buf = io.StringIO()
    w = buf.write

    w('<div class="dataframe-table-shell">')
    w('<div class="dataframe-table-container">')
    w(f'<table class="dataframe-table" id="{ids.table}">')
    w("<colgroup>")
    for cm in col_metas:
        w(
            f'<col style="min-width:{cm.width_px}px;width:{cm.width_px}px;" '
            f'data-name-min-width="{cm.name_min_width_px}">'
        )
    w("</colgroup>")
    w("<thead><tr>")

    for ci, cm in enumerate(col_metas):
        w(
            f'<th class="sortable" data-column="{ci}" '
            f'data-name-min-width="{cm.name_min_width_px}" '
            f'style="min-width:{cm.width_px}px;width:{cm.width_px}px;" '
            f'title="Type: {_html.escape(cm.type_str, quote=True)}">'
            f'<span class="column-header">'
            f'<span class="column-header-name">{_html.escape(cm.name, quote=True)}</span>'
            f'<span class="column-header-dtype">{_html.escape(cm.display_dtype, quote=True)}</span>'
            f'</span>'
            f'<span class="sort-indicator">'
            f'<span class="sort-icon-asc">{ICON_SORT_UP}</span>'
            f'<span class="sort-icon-desc">{ICON_SORT_DOWN}</span>'
            f'</span>'
            f'</th>'
        )
    w("</tr></thead><tbody>")

    td_opens = [f'<td data-column="{ci}"' for ci, _ in enumerate(col_metas)]

    # FIX (Design #1): use len(data.display_rows) instead of removed num_display.
    for ri, row in enumerate(data.display_rows):
        w(f'<tr data-dfv-row-index="{ri}">')
        for ci, cm in enumerate(col_metas):
            value    = row[cm.name]
            sort_val = _sort_attr_value(value)
            td_open  = f'{td_opens[ci]} data-sort-value="{sort_val}">'

            if (complex_type := _complex_display_type(value, cm.data_type)) is not None:
                cell_id = f"cell_{ids.uid}_{ri}_{ci}"
                inner   = _format_complex_cell(value, complex_type, cell_id, ids.uid)
            else:
                inner = _format_simple_cell(value)
            w(f"{td_open}{inner}</td>")
        w("</tr>")

    w(
        f'<tr class="column-selector-empty-row" style="display:none;">'
        f'<td class="column-selector-empty-cell" colspan="{len(col_metas)}">No columns selected. Use the column selector to show columns.</td>'
        f'</tr>'
    )
    w("</tbody></table></div>")
    w("</div>")  # .dataframe-table-shell
    return buf.getvalue()


def _render_footer(
    ids: _ViewerIds,
    total_columns: int,
    rows_text: str,
) -> str:
    return (
        f'<div class="dataframe-footer">'
        f'<span id="{ids.footer}"><strong>{total_columns}</strong> columns</span>'
        f'<span class="columns-hidden-notice" style="display:none">{ICON_WARNING} Columns are hidden</span>'
        f'<span class="dataframe-footer-rows">{rows_text}</span>'
        f'<button type="button" class="dataframe-resize-corner" '
        f'title="Drag to resize height" aria-label="Drag to resize height">'
        f'{ICON_RESIZE_CORNER}</button>'
        f'</div>'
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _prepare_dataframe_view(
    df,
    max_rows: int,
    show_total_rows: bool,
) -> tuple[str, _TableData, List[_ColumnMeta], str, int]:
    """Validate/collect one frame; return engine, rows, columns, footer text, col count."""
    _validate_inputs(df, max_rows)

    if isinstance(df, _BufferedSparkFrame):
        engine = "pyspark"
        data = df.data
        col_metas = _get_column_metadata_spark(_SparkSchemaView(df.schema), data)
        total_columns = len(col_metas)
        if total_columns == 0:
            raise ValueError(
                "DataFrame has no columns; the viewer requires at least one column."
            )
        rows_text = _build_rows_text(data, None)
        return engine, data, col_metas, rows_text, total_columns

    engine = _dataframe_engine(df)
    data = _collect_rows(df, max_rows)

    total_rows: Optional[int] = None
    if show_total_rows:
        if engine == "pandas":
            total_rows = len(df)
        else:
            try:
                total_rows = df.count()
            except Exception:
                total_rows = None

    col_metas = _get_column_metadata(df, data)
    total_columns = len(col_metas)
    if total_columns == 0:
        raise ValueError("DataFrame has no columns; the viewer requires at least one column.")
    rows_text = _build_rows_text(data, total_rows)
    return engine, data, col_metas, rows_text, total_columns


def build_dataframe_html(
    df,
    max_rows: Optional[int] = None,
    show_total_rows: bool = False,
    var_name: str = "",
) -> str:
    """Build HTML for the Moonstorm dataframe viewer without displaying it."""
    if max_rows is None:
        max_rows = _default_max_rows()
    engine, data, col_metas, rows_text, total_columns = _prepare_dataframe_view(
        df, max_rows, show_total_rows
    )
    ids = _build_viewer_ids()
    resolved_var = _canonical_var_name(var_name) or _resolve_dataframe_var_name(df)
    var_attr = ""
    if resolved_var:
        var_attr = f' data-var-name="{_html.escape(resolved_var, quote=True)}"'

    html_parts = [
        _render_css(ids),
        _render_scripts(ids, total_columns),
        f'<div class="dataframe-viewer" id="{ids.viewer}" data-engine="{engine}"{var_attr}>',
        _render_minimized_chrome(),
        _render_header(ids, engine),
        _render_open_tab_payload_script(
            ids, col_metas, data, engine=engine, title="DataFrame"
        ),
        _render_edit_snapshot_script(ids, col_metas, data, engine=engine)
        if engine in ("pyspark", "pandas")
        else "",
        _render_table(ids, col_metas, data),
        _render_footer(ids, total_columns, rows_text),
        _render_column_selector_modal(ids, col_metas),
        "</div>",
    ]

    return "\n".join(html_parts)


def build_multi_dataframe_html(
    frames: Sequence[Tuple[str, object]],
    max_rows: Optional[int] = None,
    show_total_rows: bool = False,
) -> str:
    """Build one viewer with a Result tab per labeled dataframe.

    ``frames`` is a sequence of ``(label_or_sql, dataframe)`` pairs. Labels are
    shown as Result 1..N; the SQL/text is kept as each tab's tooltip.
    """
    if not frames:
        raise ValueError("frames must contain at least one dataframe")
    if max_rows is None:
        max_rows = _default_max_rows()
    if len(frames) == 1:
        hint, lone_df = frames[0]
        return build_dataframe_html(
            lone_df,
            max_rows=max_rows,
            show_total_rows=show_total_rows,
            var_name=hint,
        )

    prepared = []
    for sql, df in frames:
        engine, data, col_metas, rows_text, total_columns = _prepare_dataframe_view(
            df, max_rows, show_total_rows
        )
        prepared.append((sql, engine, data, col_metas, rows_text, total_columns))

    base = _build_viewer_ids()
    pane_ids = [_build_pane_ids(base, i) for i in range(len(prepared))]
    raw_hints = [sql for sql, *_rest in prepared]
    labels = [_result_tab_label(i, hint) for i, hint in enumerate(raw_hints)]
    var_names = [
        _canonical_var_name(hint) or _resolve_dataframe_var_name(frames[i][1])
        for i, hint in enumerate(raw_hints)
    ]
    titles = [_sql_result_tab_title(sql) for sql, *_ in prepared]
    primary_engine = prepared[0][1]

    pane_specs: List[Tuple[_ViewerIds, int]] = [
        (pane_ids[i], prepared[i][5]) for i in range(len(prepared))
    ]

    html_parts = [
        _render_css(base),
        _render_multi_scripts(base, pane_specs),
        (
            f'<div class="dataframe-viewer" id="{base.viewer}" '
            f'data-engine="{primary_engine}" data-result-count="{len(prepared)}">'
        ),
        _render_minimized_chrome(),
        _render_multi_header(
            base,
            pane_ids,
            labels,
            titles,
            primary_engine,
            [item[1] for item in prepared],
        ),
    ]

    for i, (sql, engine, data, col_metas, rows_text, total_columns) in enumerate(prepared):
        ids = pane_ids[i]
        hidden = "" if i == 0 else " hidden"
        hydrated = ' data-dfv-hydrated="1"' if i == 0 else ""
        pane_body = [
            _render_open_tab_payload_script(
                ids,
                col_metas,
                data,
                engine=engine,
                title=titles[i],
                result_label=labels[i],
            ),
            _render_edit_snapshot_script(ids, col_metas, data, engine=engine)
            if engine in ("pyspark", "pandas")
            else "",
            _render_table(ids, col_metas, data),
            _render_footer(ids, total_columns, rows_text),
            _render_column_selector_modal(ids, col_metas),
        ]
        html_parts.append(
            f'<div class="dataframe-result-pane" id="{base.viewer}-pane-{i}" '
            f'role="tabpanel" aria-labelledby="{base.viewer}-tab-{i}" '
            f'data-result-index="{i}" data-engine="{_html.escape(engine, quote=True)}" '
            f'data-label="{_html.escape(labels[i], quote=True)}" '
            + (
                f'data-var-name="{_html.escape(var_names[i], quote=True)}" '
                if var_names[i]
                else ""
            )
            + f'title="{_html.escape(titles[i], quote=True)}"{hydrated}{hidden}>'
        )
        if i == 0:
            html_parts.extend(pane_body)
        else:
            # Inactive panes stay out of the live DOM until tab/split hydrate.
            html_parts.append(
                f'<template class="dataframe-result-pane-template" '
                f'data-result-index="{i}">'
            )
            html_parts.extend(pane_body)
            html_parts.append("</template>")
        html_parts.append("</div>")

    html_parts.append("</div>")
    return "\n".join(html_parts)


_FORMATTERS_REGISTERED = False
_ORIGINAL_PANDAS_REPR_HTML = None

# Coalesce multiple dataframe displays from one Python/SQL cell into Result tabs.
_CELL_DF_BATCHING = False
_CELL_DF_FLUSHING = False
_CELL_DF_BUFFER: List[Tuple[str, object]] = []
_CELL_DF_SOURCE_LABELS: List[str] = []
_CELL_DF_RAW_CELL = ""
_CELL_DF_EVENTS_REGISTERED = False
_IDENT_LABEL_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_DISPLAY_CALL_NAMES = frozenset({"display", "displays"})
_SKIP_LABEL_FRAME_PREFIXES = (
    "moonstorm_jup_theme",
    "IPython.",
    "ipykernel",
    "pandas.",
    "pyspark.",
    "py4j.",
)


def _result_tab_label(index: int, hint: str) -> str:
    """Prefer a short variable name; otherwise Result N."""
    text = " ".join((hint or "").split())
    if text and _IDENT_LABEL_RE.match(text) and len(text) <= 48:
        return text
    return f"Result {index + 1}"


def _call_func_name(func: object) -> str | None:
    import ast

    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return None


def _label_from_expr_value(value: object) -> str:
    """Return a variable tab label from a bare name or ``display(name)`` expr."""
    import ast

    if isinstance(value, ast.Name) and _IDENT_LABEL_RE.match(value.id):
        return value.id
    if not isinstance(value, ast.Call) or not value.args:
        return ""
    name = _call_func_name(value.func)
    if name not in _DISPLAY_CALL_NAMES:
        return ""
    arg0 = value.args[0]
    if isinstance(arg0, ast.Name) and _IDENT_LABEL_RE.match(arg0.id):
        return arg0.id
    return ""


def _last_assigned_var_name(source: str) -> str:
    """Last simple assignment target in the cell (``sales = ...``)."""
    import ast

    text = source if isinstance(source, str) else ""
    if not text.strip():
        return ""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return ""
    last = ""
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if isinstance(target, ast.Name) and _IDENT_LABEL_RE.match(target.id):
                last = target.id
    return last


def _labels_from_cell_source(source: str) -> List[str]:
    """Extract display target names from cell source in evaluation order.

    Supports bare names (``df``) and ``display(df)`` / ``displays(...)`` so
    multi-result tabs can show the variable the user typed.
    """
    import ast

    text = source if isinstance(source, str) else ""
    if not text.strip():
        return []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []

    labels: List[str] = []
    for node in tree.body:
        if not isinstance(node, ast.Expr):
            continue
        label = _label_from_expr_value(node.value)
        if label:
            labels.append(label)
    return labels


def _label_at_source_line(source: str, lineno: int) -> str:
    """Label for the expression statement covering ``lineno`` (1-based)."""
    import ast

    text = source if isinstance(source, str) else ""
    if not text.strip() or lineno < 1:
        return ""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return ""

    for node in tree.body:
        if not isinstance(node, ast.Expr):
            continue
        start = getattr(node, "lineno", None)
        if not isinstance(start, int):
            continue
        end = getattr(node, "end_lineno", None)
        if not isinstance(end, int):
            end = start
        if start <= lineno <= end:
            return _label_from_expr_value(node.value)
    return ""


def _label_from_call_site() -> str:
    """Best-effort variable name from the user code that triggered display."""
    import inspect
    import linecache

    raw = _CELL_DF_RAW_CELL if isinstance(_CELL_DF_RAW_CELL, str) else ""
    try:
        frames = inspect.stack(context=1)
    except Exception:
        return ""

    try:
        for fr in frames[1:]:
            mod = fr.frame.f_globals.get("__name__", "") or ""
            if any(
                mod == prefix or mod.startswith(prefix)
                for prefix in _SKIP_LABEL_FRAME_PREFIXES
            ):
                continue
            lineno = fr.lineno or 0
            if raw:
                label = _label_at_source_line(raw, lineno)
                if label:
                    return label
            line = ""
            if fr.code_context:
                line = fr.code_context[0]
            if not line and fr.filename and lineno:
                line = linecache.getline(fr.filename, lineno)
            label = _label_from_expr_value_line(line)
            if label:
                return label
    finally:
        del frames
    return ""


def _label_from_expr_value_line(line: str) -> str:
    """Parse a single source line as an expression for a display label."""
    import ast

    text = (line or "").strip()
    if not text:
        return ""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return ""
    if len(tree.body) != 1 or not isinstance(tree.body[0], ast.Expr):
        return ""
    return _label_from_expr_value(tree.body[0].value)


def _label_for_dataframe(df, user_ns: dict | None = None) -> str:
    """Best-effort variable name for ``df``; empty when unknown."""
    if isinstance(user_ns, dict):
        for name, value in user_ns.items():
            if not isinstance(name, str) or name.startswith("_"):
                continue
            if value is df and _IDENT_LABEL_RE.match(name):
                return name
    return ""


def _canonical_var_name(hint: str) -> str:
    """Return ``hint`` when it is a valid Python identifier, else ``""``."""
    text = (hint or "").strip()
    if text and _IDENT_LABEL_RE.match(text):
        return text
    return ""


def _resolve_dataframe_var_name(df, explicit: str | None = None) -> str:
    """Best-effort Python name for patch code (``_source = name``)."""
    text = _canonical_var_name(explicit or "")
    if text:
        return text
    text = _label_from_call_site()
    if text:
        return text
    if _CELL_DF_SOURCE_LABELS:
        text = _canonical_var_name(_CELL_DF_SOURCE_LABELS[0])
        if text:
            return text
    raw = _CELL_DF_RAW_CELL if isinstance(_CELL_DF_RAW_CELL, str) else ""
    text = _canonical_var_name(_last_assigned_var_name(raw))
    if text:
        return text
    try:
        from IPython.core.getipython import get_ipython

        ip = get_ipython()
        ns = getattr(ip, "user_ns", None) if ip is not None else None
    except Exception:
        ns = None
    return _label_for_dataframe(df, ns if isinstance(ns, dict) else None)


def _batching_enabled() -> bool:
    return _CELL_DF_BATCHING and not _CELL_DF_FLUSHING


def _raw_cell_from_pre_run_info(info) -> str:
    """Extract cell source from IPython ``pre_run_cell`` info."""
    if info is None:
        return ""
    if isinstance(info, str):
        return info
    for attr in ("raw_cell", "cell", "transformed_cell"):
        raw = getattr(info, attr, None)
        if isinstance(raw, str) and raw.strip():
            return raw
        if raw is not None and not isinstance(raw, str):
            text = str(raw)
            if text.strip():
                return text
    return ""


def _buffer_dataframe(df, label: str | None = None) -> None:
    """Queue a dataframe for the end-of-cell multi-tab flush."""
    if not is_displayable_dataframe(df):
        return
    text = (label or "").strip()
    if not text:
        # Call site first: reliable for display(df) even when pre_run info is empty.
        text = _label_from_call_site()
    if not text:
        # Fall back to names parsed from the whole cell, in evaluation order.
        idx = len(_CELL_DF_BUFFER)
        if idx < len(_CELL_DF_SOURCE_LABELS):
            text = _CELL_DF_SOURCE_LABELS[idx]
    if not text:
        try:
            from IPython.core.getipython import get_ipython

            ip = get_ipython()
            ns = getattr(ip, "user_ns", None) if ip is not None else None
        except Exception:
            ns = None
        text = _label_for_dataframe(df, ns if isinstance(ns, dict) else None)
    if _is_spark_df(df):
        # Snapshot rows while the Spark session is still alive. post_run_cell flush
        # can run after spark.stop() in the same cell.
        try:
            snap = _BufferedSparkFrame(
                schema=df.schema,
                data=_collect_rows_spark(df, _default_max_rows()),
            )
            _CELL_DF_BUFFER.append((text, snap))
            return
        except Exception:
            pass
    _CELL_DF_BUFFER.append((text, df))


def _start_cell_dataframe_batch(info=None, *_args, **_kwargs) -> None:
    global _CELL_DF_BATCHING, _CELL_DF_SOURCE_LABELS, _CELL_DF_RAW_CELL
    _CELL_DF_BUFFER.clear()
    raw = _raw_cell_from_pre_run_info(info)
    if not raw and _args:
        raw = _raw_cell_from_pre_run_info(_args[0])
    if not raw:
        raw = _raw_cell_from_pre_run_info(_kwargs.get("info"))
    _CELL_DF_RAW_CELL = raw
    _CELL_DF_SOURCE_LABELS = _labels_from_cell_source(raw)
    _CELL_DF_BATCHING = True


def _relabel_frames_from_source(
    frames: List[Tuple[str, object]],
) -> List[Tuple[str, object]]:
    """Fill empty buffer labels from the stashed cell source before publish."""
    if not frames:
        return frames
    source_labels = _labels_from_cell_source(_CELL_DF_RAW_CELL)
    if not source_labels:
        source_labels = list(_CELL_DF_SOURCE_LABELS)
    if not source_labels:
        return frames
    out: List[Tuple[str, object]] = []
    for i, (lab, df) in enumerate(frames):
        text = (lab or "").strip()
        if not text and i < len(source_labels):
            text = source_labels[i]
        out.append((text, df))
    return out


def _display_dataframe_viewer_error(exc: BaseException) -> None:
    """Surface dataframe viewer failures instead of silent IPython callback errors."""
    message = _html.escape(str(exc) or repr(exc), quote=True)
    detail = _html.escape(
        traceback.format_exception_only(type(exc), exc)[-1].strip(),
        quote=True,
    )
    html = (
        '<div class="dataframe-viewer dataframe-viewer-error" '
        f'title="{detail}">'
        f"<strong>Moonstorm dataframe viewer error:</strong> {message}"
        "</div>"
    )
    if IPYTHON_AVAILABLE:
        try:
            _ipython_display(HTML(html))
            return
        except Exception:
            pass
    print(f"Moonstorm dataframe viewer error: {exc}", file=sys.stderr)
    traceback.print_exception(type(exc), exc, exc.__traceback__)


def _flush_cell_dataframe_batch(*_args, **_kwargs) -> None:
    """Publish buffered dataframes as one viewer (tabs when multiple)."""
    global _CELL_DF_BATCHING, _CELL_DF_FLUSHING, _CELL_DF_SOURCE_LABELS
    global _CELL_DF_RAW_CELL

    _CELL_DF_BATCHING = False
    frames = _relabel_frames_from_source(list(_CELL_DF_BUFFER))
    _CELL_DF_BUFFER.clear()
    _CELL_DF_SOURCE_LABELS = []
    _CELL_DF_RAW_CELL = ""
    if not frames:
        return

    _CELL_DF_FLUSHING = True
    try:
        # Avoid Spark df.count() on every auto-display; callers can still pass
        # show_total_rows=True via display / displays / %%sql.
        if len(frames) > 1:
            displays(frames, show_total_rows=False)
        else:
            hint, lone_df = frames[0]
            display(lone_df, show_total_rows=False, var_name=hint or None)
    except Exception as exc:
        _display_dataframe_viewer_error(exc)
    finally:
        _CELL_DF_FLUSHING = False


def _register_cell_dataframe_batch_hooks(ipython) -> None:
    global _CELL_DF_EVENTS_REGISTERED
    if _CELL_DF_EVENTS_REGISTERED or ipython is None:
        return
    events = getattr(ipython, "events", None)
    if events is None or not hasattr(events, "register"):
        return
    try:
        events.register("pre_run_cell", _start_cell_dataframe_batch)
        events.register("post_run_cell", _flush_cell_dataframe_batch)
    except Exception:
        return
    _CELL_DF_EVENTS_REGISTERED = True


def _unregister_cell_dataframe_batch_hooks(ipython) -> None:
    global _CELL_DF_EVENTS_REGISTERED, _CELL_DF_BATCHING, _CELL_DF_FLUSHING
    global _CELL_DF_SOURCE_LABELS, _CELL_DF_RAW_CELL
    _CELL_DF_BUFFER.clear()
    _CELL_DF_SOURCE_LABELS = []
    _CELL_DF_RAW_CELL = ""
    _CELL_DF_BATCHING = False
    _CELL_DF_FLUSHING = False
    if not _CELL_DF_EVENTS_REGISTERED or ipython is None:
        _CELL_DF_EVENTS_REGISTERED = False
        return
    events = getattr(ipython, "events", None)
    if events is not None and hasattr(events, "unregister"):
        for name, fn in (
            ("pre_run_cell", _start_cell_dataframe_batch),
            ("post_run_cell", _flush_cell_dataframe_batch),
        ):
            try:
                events.unregister(name, fn)
            except Exception:
                pass
    _CELL_DF_EVENTS_REGISTERED = False


def _format_dataframe_html_or_batch(df):
    """Return viewer HTML, or buffer during a cell run (suppress mime)."""
    if _batching_enabled():
        _buffer_dataframe(df)
        return None
    return build_dataframe_html(df, var_name=_resolve_dataframe_var_name(df))


def _suppress_plain_during_batch(obj, p, cycle) -> None:
    """Pretty-printer: silence text/plain while coalescing cell dataframes.

    PlainTextFormatter registers ``(obj, p, cycle)`` printers, not 1-arg
    mime formatters.
    """
    if _batching_enabled() and is_displayable_dataframe(obj):
        return
    if cycle:
        p.text("DataFrame(...)")
        return
    try:
        p.text(obj.__repr__())
    except Exception:
        p.text(repr(obj))


def _install_pandas_html_repr(formatter) -> None:
    global _ORIGINAL_PANDAS_REPR_HTML
    import pandas as pd

    if _ORIGINAL_PANDAS_REPR_HTML is None:
        _ORIGINAL_PANDAS_REPR_HTML = pd.DataFrame._repr_html_

    def _html_dataframe_formatter(df):
        return _format_dataframe_html_or_batch(df)

    formatter.for_type(pd.DataFrame, _html_dataframe_formatter)
    formatter.for_type_by_name(
        'pandas.core.frame',
        'DataFrame',
        _html_dataframe_formatter,
    )
    pd.DataFrame._repr_html_ = _html_dataframe_formatter


def _uninstall_pandas_html_repr(formatter) -> None:
    global _ORIGINAL_PANDAS_REPR_HTML
    import pandas as pd

    formatter.pop(pd.DataFrame, None)
    formatter.pop("pandas.core.frame.DataFrame", None)
    if _ORIGINAL_PANDAS_REPR_HTML is not None:
        pd.DataFrame._repr_html_ = _ORIGINAL_PANDAS_REPR_HTML


# Deferred IPython registrations (module, class) so EG Spark drivers still get
# the viewer when pyspark is imported after Moonstorm's IPython extension loads.
_SPARK_DF_TYPE_NAMES: Tuple[Tuple[str, str], ...] = (
    ("pyspark.sql.dataframe", "DataFrame"),
    ("pyspark.sql.classic.dataframe", "DataFrame"),
    ("pyspark.sql.connect.dataframe", "DataFrame"),
)


def _spark_dataframe_types() -> List[type]:
    """Concrete PySpark DataFrame types to register with IPython formatters.

    Newer PySpark uses ``pyspark.sql.classic.dataframe.DataFrame`` at runtime;
    IPython's pretty-printer can short-circuit on that subclass's ``__repr__``
    before a parent-type printer runs, so register each known class.
    """
    types: List[type] = []
    try:
        from pyspark.sql import DataFrame as SparkDataFrame

        types.append(SparkDataFrame)
    except ImportError:
        return types
    for mod_name, _cls_name in _SPARK_DF_TYPE_NAMES[1:]:
        try:
            mod = __import__(mod_name, fromlist=["DataFrame"])
            cls = getattr(mod, "DataFrame", None)
            if isinstance(cls, type) and cls not in types:
                types.append(cls)
        except ImportError:
            pass
    return types


def _html_spark_dataframe_formatter(df):
    return _format_dataframe_html_or_batch(df)


def _install_spark_html_repr(formatter) -> None:
    """Register Spark DF HTML formatters, including deferred-by-name entries.

    ``for_type_by_name`` works before ``import pyspark`` (important for
    Enterprise Gateway drivers where Spark may initialize after kernel start).
    """
    for mod_name, cls_name in _SPARK_DF_TYPE_NAMES:
        formatter.for_type_by_name(
            mod_name, cls_name, _html_spark_dataframe_formatter
        )
    for cls in _spark_dataframe_types():
        formatter.for_type(cls, _html_spark_dataframe_formatter)


def _uninstall_spark_html_repr(formatter) -> None:
    for cls in _spark_dataframe_types():
        formatter.pop(cls, None)
    for mod_name, cls_name in _SPARK_DF_TYPE_NAMES:
        formatter.pop(f"{mod_name}.{cls_name}", None)


class _MoonstormPlainOmitProxy:
    """Proxy that omits text/plain for dataframes while cell batching is on.

    Special methods like ``__call__`` are looked up on the class, so assigning
    ``formatter.__call__`` on an instance does not affect ``formatter(obj)``.
    Replacing the formatter entry with this proxy does.
    """

    __slots__ = ("_inner",)

    def __init__(self, inner) -> None:
        self._inner = inner

    def __call__(self, obj):
        if _batching_enabled() and is_displayable_dataframe(obj):
            return None
        return self._inner(obj)

    def __getattr__(self, name: str):
        return getattr(self._inner, name)


def _install_plain_suppressors(ipython) -> None:
    """Silence Spark/pandas text/plain while cell dataframe batching is active.

    IPython still asks for text/plain even when the HTML formatter returns
    ``None`` (buffering). Returning ``None`` from the plain formatter omits
    that mime bundle so ``display(df)`` does not print
    ``DataFrame[col: type, ...]``.
    """
    if ipython is None:
        return
    display_formatter = getattr(ipython, "display_formatter", None)
    formatters = getattr(display_formatter, "formatters", None)
    if not isinstance(formatters, dict):
        return
    plain_formatter = formatters.get("text/plain")
    if plain_formatter is None:
        return
    if isinstance(plain_formatter, _MoonstormPlainOmitProxy):
        plain_formatter = plain_formatter._inner
    try:
        import pandas as pd

        plain_formatter.for_type(pd.DataFrame, _suppress_plain_during_batch)
        plain_formatter.for_type_by_name(
            "pandas.core.frame",
            "DataFrame",
            _suppress_plain_during_batch,
        )
    except ImportError:
        pass
    for mod_name, cls_name in _SPARK_DF_TYPE_NAMES:
        plain_formatter.for_type_by_name(
            mod_name, cls_name, _suppress_plain_during_batch
        )
    for cls in _spark_dataframe_types():
        plain_formatter.for_type(cls, _suppress_plain_during_batch)

    formatters["text/plain"] = _MoonstormPlainOmitProxy(plain_formatter)


def _uninstall_plain_suppressors(ipython) -> None:
    if ipython is None:
        return
    display_formatter = getattr(ipython, "display_formatter", None)
    formatters = getattr(display_formatter, "formatters", None)
    if not isinstance(formatters, dict):
        return
    plain_formatter = formatters.get("text/plain")
    if isinstance(plain_formatter, _MoonstormPlainOmitProxy):
        inner = plain_formatter._inner
        formatters["text/plain"] = inner
        plain_formatter = inner
    if plain_formatter is None:
        return
    try:
        import pandas as pd

        plain_formatter.pop(pd.DataFrame, None)
        plain_formatter.pop("pandas.core.frame.DataFrame", None)
    except ImportError:
        pass
    for cls in _spark_dataframe_types():
        plain_formatter.pop(cls, None)
    plain_formatter.pop("pyspark.sql.dataframe.DataFrame", None)
    plain_formatter.pop("pyspark.sql.classic.dataframe.DataFrame", None)
    plain_formatter.pop("pyspark.sql.connect.dataframe.DataFrame", None)


def ensure_spark_display_formatters(ipython=None) -> bool:
    """Install or refresh Spark DataFrame HTML formatters.

    Safe to call repeatedly. Uses deferred ``for_type_by_name`` registrations so
    Enterprise Gateway Spark drivers still get the viewer when ``pyspark`` is
    imported after the IPython extension has already loaded.
    """
    if ipython is None:
        try:
            from IPython.core.getipython import get_ipython

            ipython = get_ipython()
        except ImportError:
            return False
    if ipython is None:
        return False

    if not _FORMATTERS_REGISTERED:
        return register_display_formatters(ipython)

    html_formatter = ipython.display_formatter.formatters.get("text/html")
    if html_formatter is None:
        return False
    try:
        _install_spark_html_repr(html_formatter)
        _install_plain_suppressors(ipython)
    except Exception:
        return False
    return True


def register_display_formatters(ipython=None) -> bool:
    """Use the Moonstorm dataframe viewer for display(df) and cell output."""
    global _FORMATTERS_REGISTERED
    if _FORMATTERS_REGISTERED:
        # Spark may have become importable after the first registration (EG).
        ensure_spark_display_formatters(ipython)
        return True

    if ipython is None:
        try:
            from IPython.core.getipython import get_ipython
            ipython = get_ipython()
        except ImportError:
            return False

    if ipython is None:
        return False

    html_formatter = ipython.display_formatter.formatters.get("text/html")
    if html_formatter is None:
        return False

    import warnings

    try:
        _install_pandas_html_repr(html_formatter)
    except ImportError:
        pass
    except Exception as exc:
        warnings.warn(
            f"moonstorm-jup-theme: failed to register pandas dataframe viewer: {exc}",
            stacklevel=2,
        )
        return False

    try:
        # Deferred-by-name registrations — do not require pyspark at import time.
        _install_spark_html_repr(html_formatter)
    except Exception as exc:
        warnings.warn(
            f"moonstorm-jup-theme: failed to register PySpark dataframe viewer: {exc}",
            stacklevel=2,
        )

    try:
        _install_plain_suppressors(ipython)
    except Exception:
        pass

    _register_cell_dataframe_batch_hooks(ipython)
    _FORMATTERS_REGISTERED = True
    return True


def unregister_display_formatters(ipython=None) -> bool:
    """Restore default pandas and PySpark HTML reprs."""
    global _FORMATTERS_REGISTERED
    if not _FORMATTERS_REGISTERED:
        return True

    if ipython is None:
        try:
            from IPython.core.getipython import get_ipython
            ipython = get_ipython()
        except ImportError:
            return False

    if ipython is None:
        return False

    html_formatter = ipython.display_formatter.formatters.get("text/html")
    if html_formatter is None:
        _unregister_cell_dataframe_batch_hooks(ipython)
        _FORMATTERS_REGISTERED = False
        return False

    try:
        _uninstall_pandas_html_repr(html_formatter)
    except ImportError:
        pass

    try:
        _uninstall_spark_html_repr(html_formatter)
    except ImportError:
        pass

    try:
        _uninstall_plain_suppressors(ipython)
    except Exception:
        pass

    _unregister_cell_dataframe_batch_hooks(ipython)
    _FORMATTERS_REGISTERED = False
    return True


def display(
    df,
    max_rows: Optional[int] = None,
    show_total_rows: bool = False,
    var_name: str | None = None,
) -> None:
    """Display a pandas or PySpark DataFrame in the Moonstorm HTML viewer.

    Args:
        df:               pandas or PySpark DataFrame to display.
        max_rows:         Maximum preview rows (default 100, hard cap 10 000).
        show_total_rows:  Display the full row count when available.
    """
    # Opportunistically bind Spark formatters if pyspark became available
    # after extension load (Enterprise Gateway). Harmless when already set.
    try:
        ensure_spark_display_formatters()
    except Exception:
        pass

    if _batching_enabled():
        _buffer_dataframe(df)
        return

    html = build_dataframe_html(
        df,
        max_rows=max_rows,
        show_total_rows=show_total_rows,
        var_name=var_name or "",
    )

    if IPYTHON_AVAILABLE:
        _ipython_display(HTML(html))
    else:
        print("DataFrame viewer requires Jupyter for HTML rendering.")
        print(html[:500])


def displays(
    frames: Sequence[Tuple[str, object]],
    max_rows: Optional[int] = None,
    show_total_rows: bool = False,
) -> None:
    """Display multiple dataframes as Result tabs in one Moonstorm viewer."""
    try:
        ensure_spark_display_formatters()
    except Exception:
        pass

    if _batching_enabled():
        for label, df in frames:
            _buffer_dataframe(df, label=label)
        return

    html = build_multi_dataframe_html(
        frames,
        max_rows=max_rows,
        show_total_rows=show_total_rows,
    )

    if IPYTHON_AVAILABLE:
        _ipython_display(HTML(html))
    else:
        print("DataFrame viewer requires Jupyter for HTML rendering.")
        print(html[:500])