"""Tests for Moonstorm IPython extension (dataframe formatters)."""

from __future__ import annotations

from moonstorm_jup_theme.ipython import load_ipython_extension


def test_load_ipython_extension_registers_formatters(monkeypatch) -> None:
    calls: list[str] = []

    monkeypatch.setattr(
        "moonstorm_jup_theme.ipython.pin_pyspark_python",
        lambda: calls.append("pin") or "python",
    )
    monkeypatch.setattr(
        "moonstorm_jup_theme.ipython.register_theme_comm",
        lambda ip: calls.append("theme"),
    )
    monkeypatch.setattr(
        "moonstorm_jup_theme.ipython.register_sql_magic",
        lambda ip: calls.append("sql"),
    )
    monkeypatch.setattr(
        "moonstorm_jup_theme.ipython.register_display_formatters",
        lambda ip: calls.append("register") or True,
    )
    monkeypatch.setattr(
        "moonstorm_jup_theme.ipython.ensure_spark_display_formatters",
        lambda ip: calls.append("spark"),
    )

    load_ipython_extension(object())

    assert calls[0] == "pin"
    assert "theme" in calls
    assert "sql" in calls
    assert "register" in calls
    assert "spark" in calls
