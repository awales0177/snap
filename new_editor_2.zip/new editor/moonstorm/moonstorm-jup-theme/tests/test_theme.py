from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from moonstorm_jup_theme.dataframe_viewer import (
    _MAX_ROWS_HARD_CAP,
    _PANEL_HEIGHT_PX,
    _PANEL_MAX_HEIGHT_PX,
    _PANEL_MIN_HEIGHT_PX,
    _SCROLLBAR_WIDTH_PX,
    _SPARK_DF_TYPE_NAMES,
    _ViewerIds,
    _dataframe_engine,
    _engine_version_label,
    _highlight_json_html,
    _is_spark_df,
    _render_header,
    build_dataframe_html,
    build_multi_dataframe_html,
    ensure_spark_display_formatters,
    register_display_formatters,
    unregister_display_formatters,
)


ROOT = Path(__file__).resolve().parents[1]
LABEXT = ROOT / "moonstorm_jup_theme" / "labextension"


@pytest.fixture
def sample_df() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "name": ["Ada", "Grace", "Alan"],
            "score": [99, 97, 95],
            "active": [True, True, False],
        }
    )


class TestDataframeViewer:
    def test_build_html_for_pandas_dataframe(self, sample_df: pd.DataFrame) -> None:
        html = build_dataframe_html(sample_df, max_rows=2, show_total_rows=True)

        assert "dataframe-viewer" in html
        assert "Ada" in html
        assert "Grace" in html
        assert "Alan" not in html
        assert "showing 2 of 3 rows" in html
        assert "<strong>3</strong> columns" in html

    def test_multi_dataframe_html_has_result_tabs(
        self, sample_df: pd.DataFrame
    ) -> None:
        other = pd.DataFrame({"x": [1, 2]})
        html = build_multi_dataframe_html(
            [
                ("SELECT * FROM people", sample_df),
                ("SELECT 1 AS x", other),
            ],
            max_rows=10,
            show_total_rows=True,
        )

        assert 'data-result-count="2"' in html
        assert "dataframe-result-tabs" in html
        assert "Result 1" in html
        assert "Result 2" in html
        assert "dataframe-result-pane" in html
        assert "SELECT * FROM people" in html
        assert "Ada" in html
        assert html.count('class="dataframe-result-pane"') == 2
        assert 'aria-selected="true"' in html
        assert " hidden" in html  # inactive pane / controls
        assert "dataframe-split-btn" in html
        assert "Break into separate viewers" in html
        assert "dataframe-split-icon" in html
        assert 'width="11" height="11"' in html  # stacked.svg (smaller)
        assert 'viewBox="0 0 16 16"' in html  # stacked.svg
        assert "dataframe-merge-btn" in html or "mergeBtnHtml" in html
        assert "Merge into one viewer" in html
        assert "dataframe-merge-icon" in html
        assert "viewBox=\\\"0 0 100 100\\\"" in html  # merge.svg (JSON in split JS)
        assert 'width=\\"16\\" height=\\"16\\"' in html  # merge icon size in JSON
        assert "_split_" in html or "bindSplit" in html
        assert "bindMerge" in html
        assert "data-dfv-split-group" in html or "data-dfv-split-index" in html
        assert "__moonstormDfvHydratePane" in html
        assert "__moonstormDfvSplit" in html
        assert "dataframe-result-pane-template" in html
        assert 'data-dfv-hydrated="1"' in html
        # Inactive panes stay in <template> (content still present in the MIME string).
        assert html.count("<template") >= 1
        assert html.index("dataframe-result-pane-template") < html.rindex(
            'class="dataframe-table"'
        )
        # Shared CSS is no longer embedded per output (~22KB rule block).
        assert "position:relative; border-radius:12px; border:1px solid #404040" not in html

    def test_single_dataframe_has_no_split_or_result_tabs(
        self, sample_df: pd.DataFrame
    ) -> None:
        html = build_multi_dataframe_html(
            [("only", sample_df)],
            max_rows=10,
        )
        # Multi-result chrome must not appear when only one frame is passed.
        assert 'class="dataframe-result-tabs"' not in html
        assert 'class="dataframe-split-btn"' not in html
        assert "Break into separate viewers" not in html
        assert 'class="dataframe-result-pane"' not in html
        assert "Ada" in html

    def test_pandas_dataframe_header_has_no_engine_logo(
        self, sample_df: pd.DataFrame
    ) -> None:
        html = build_dataframe_html(sample_df)

        assert 'data-engine="pandas"' in html
        assert "dataframe-engine-logo" not in html
        assert "dataframe-engine-logo-img--pandas" not in html
        assert "data:image/png;base64," not in html
        assert 'aria-label="PySpark' not in html
        assert _dataframe_engine(sample_df) == "pandas"
        assert _engine_version_label("pandas") == f"pandas {pd.__version__}"
        shared_css = (ROOT / "style" / "dataframe-viewer.css").read_text()
        assert "--moonstorm-dfv-header-bg" in shared_css

    def test_pandas_viewer_includes_row_edit_controls(
        self, sample_df: pd.DataFrame
    ) -> None:
        html = build_dataframe_html(sample_df)

        assert "dataframe-row-edit-btn" in html
        assert 'data-dfv-edit-snapshot="1"' in html
        assert "buildPandasPatchSource" in html
        assert '"engine": "pandas"' in html

    def test_spark_header_has_no_engine_logo(self) -> None:
        ids = _ViewerIds(
            uid="test",
            viewer="v",
            table="t",
            col_sel="c",
            col_sel_modal="m",
            open_tab_btn="ot",
            edit_btn="ed",
            minimize_btn="mn",
            footer="f",
        )
        html = _render_header(ids, "pyspark")

        assert 'data-engine="pyspark"' in html
        assert "dataframe-engine-logo" not in html
        assert "dataframe-engine-logo-img--spark" not in html
        assert "data:image/png;base64," not in html
        assert "column-selector-wrap" in html
        assert "dataframe-open-tab-btn" in html
        assert "dataframe-minimize-btn" in html
        assert _engine_version_label("pyspark").startswith("PySpark")

    def test_pandas_header_shows_column_filter(
        self, sample_df: pd.DataFrame
    ) -> None:
        html = build_dataframe_html(sample_df)
        # Prefer the live header element (CSS also mentions these class names).
        header_start = html.index('class="dataframe-header" data-engine=')
        header_end = html.index("dataframe-table-shell", header_start)
        header = html[header_start:header_end]
        assert "column-selector-wrap" in header
        assert "dataframe-open-tab-btn" in header
        assert "dataframe-minimize-btn" in header
        assert "dataframe-engine-logo" not in header
        shared_css = (ROOT / "style" / "dataframe-viewer.css").read_text()
        assert "justify-content:flex-end" in shared_css

    def test_viewer_uses_shared_panel_height(self, sample_df: pd.DataFrame) -> None:
        html = build_dataframe_html(sample_df)
        shared_css = (ROOT / "style" / "dataframe-viewer.css").read_text()

        assert f"height:{_PANEL_HEIGHT_PX}px" in shared_css
        assert f"min-height:{_PANEL_MIN_HEIGHT_PX}px" in shared_css
        assert f"max-height:min(85vh, {_PANEL_MAX_HEIGHT_PX}px)" in shared_css
        assert "dataframe-table-shell" in html
        assert "dataframe-resize-corner" in html
        assert "dataframe-resize-corner-icon" in html
        assert "Drag to resize height" in html
        assert "resize:vertical" not in html
        assert "pointerdown" in html
        assert "data-name-min-width" in html
        assert "data-dfv-resizing" in html
        assert "pinTop" not in html
        assert "findNotebookScroller" not in html
        assert "moonstorm-dfv-open-tab" in html
        assert "dataframe-open-tab-btn" in html
        assert "dataframe-open-tab-icon" in html
        assert "Open in tab" in html
        assert "dataframe-minimize-btn" in html
        assert "dataframe-minimize-icon" in html
        assert "dataframe-minimized-chrome" in html
        assert "dataframe-minimized-banner" in html
        assert "dataframe-minimized-tray" in html
        assert "dataframe-maximize-btn" in html
        assert "dataframe-minimized-open-tab" in html
        assert "DataFrame minimized" in html
        assert "data-minimized" in html
        assert "Minimize dataframe" in html
        assert "collectTable" in html
        assert "collectHtml" not in html
        assert "dataframe-height-handle" not in html
        assert "dataframe-expand-btn" not in html
        assert "dataframe-viewer--modal" not in html
        footer = html[html.index('class="dataframe-footer"') :]
        assert "dataframe-resize-corner" in footer
        assert html.count('class="dataframe-resize-corner"') == 1
        assert f"--dfv-scrollbar-width:{_SCROLLBAR_WIDTH_PX}px" in shared_css
        assert "overflow:auto" in shared_css
        assert ".dataframe-table-container" in shared_css
        assert f"min-height:calc({_PANEL_HEIGHT_PX}px + 84px)" not in html
        assert "flex-direction:column" in shared_css

    def test_rejects_non_dataframe_input(self) -> None:
        with pytest.raises(TypeError, match="Expected a pandas or PySpark DataFrame"):
            build_dataframe_html([1, 2, 3])

    def test_rejects_negative_max_rows(self, sample_df: pd.DataFrame) -> None:
        with pytest.raises(ValueError, match="max_rows must be non-negative"):
            build_dataframe_html(sample_df, max_rows=-1)

    def test_rejects_excessive_max_rows(self, sample_df: pd.DataFrame) -> None:
        with pytest.raises(ValueError, match="hard cap"):
            build_dataframe_html(sample_df, max_rows=_MAX_ROWS_HARD_CAP + 1)

    def test_rejects_empty_dataframe(self) -> None:
        empty = pd.DataFrame()
        with pytest.raises(ValueError, match="no columns"):
            build_dataframe_html(empty)

    def test_column_selector_modal_is_rendered(self, sample_df: pd.DataFrame) -> None:
        html = build_dataframe_html(sample_df)

        assert "column-selector-modal" in html
        assert "column-selector-toggle-all-btn" in html
        assert 'data-column="0"' in html
        assert ">name</span>" in html

    def test_column_headers_show_dtype_under_name(self, sample_df: pd.DataFrame) -> None:
        html = build_dataframe_html(sample_df)

        assert 'class="column-header-name">name</span>' in html
        assert 'class="column-header-dtype">str</span>' in html or (
            'class="column-header-dtype">string</span>' in html
        )
        assert 'class="column-header-name">score</span>' in html
        assert 'class="column-header-dtype">int64</span>' in html
        assert 'class="column-header-name">active</span>' in html
        assert 'class="column-header-dtype">bool</span>' in html

    def test_object_columns_infer_element_dtype_labels(self) -> None:
        df = pd.DataFrame(
            {
                "list_col": [["apple", "banana"], None],
                "dict_col": [{"country": "US"}, None],
                "tuple_col": [("A", "B"), None],
                "set_col": [{"red", "green"}, None],
                "bytes_col": [b"hello", None],
                "mixed_col": ["hello", 1],
            }
        )
        html = build_dataframe_html(df)

        assert 'class="column-header-dtype">array&lt;string&gt;</span>' in html
        assert 'class="column-header-dtype">struct</span>' in html
        assert 'class="column-header-dtype">tuple</span>' in html
        assert 'class="column-header-dtype">set</span>' in html
        assert 'class="column-header-dtype">bytes</span>' in html
        assert 'class="column-header-dtype">object</span>' in html

    def test_null_values_render_as_null_label(self) -> None:
        df = pd.DataFrame({"value": [None, 1]})
        html = build_dataframe_html(df, max_rows=2)

        assert 'class="dataframe-null dfv-cell-text">null</span>' in html

    def test_empty_string_cell_distinct_from_null(self) -> None:
        df = pd.DataFrame({"text": ["", None]})
        html = build_dataframe_html(df, max_rows=2)

        assert "dfv-empty-string" in html
        assert 'class="dataframe-null dfv-cell-text">null</span>' in html
        assert "parseCellInput" in html

    def test_list_and_dict_columns_do_not_raise_on_display(self) -> None:
        df = pd.DataFrame(
            [
                {
                    "list_col": ["apple", "banana", "orange"],
                    "dict_col": {"country": "US", "state": "VA"},
                    "tuple_col": ("A", "B", "C"),
                    "set_col": {"red", "green", "blue"},
                    "bytes_col": b"hello world",
                }
            ]
        )
        html = build_dataframe_html(df)

        assert "dataframe-viewer" in html
        assert "apple" in html
        assert "country" in html or "Struct" in html
        assert "green" in html and "red" in html
        assert "(&quot;A&quot;, &quot;B&quot;, &quot;C&quot;)" in html
        assert 'data-dfv-lazy-json="1"' in html
        assert "hello world" in html
        assert html.count("complex-value") >= 4
        # Highlight spans are deferred until expand (toggle JS).
        assert 'class="json-string"' not in html

    def test_complex_struct_cells_include_lazy_json_payload(self) -> None:
        df = pd.DataFrame(
            {
                "payload": [
                    {"id": 3, "name": "Charlie", "active": True},
                ]
            }
        )
        html = build_dataframe_html(df)

        assert "complex-value" in html
        assert 'data-dfv-lazy-json="1"' in html
        assert 'type="application/json"' in html
        assert "Charlie" in html
        assert "moonstormHighlightJson_" in html
        # Eager highlight spans must not ship in the MIME HTML.
        assert 'class="json-key"' not in html

    def test_list_of_structs_renders_expandable_json(self) -> None:
        df = pd.DataFrame(
            {
                "users": [
                    [
                        {"id": 1, "name": "Alice", "active": True},
                        {"id": 2, "name": "Bob", "active": False},
                    ]
                ]
            }
        )
        html = build_dataframe_html(df)

        assert 'class="column-header-dtype">array&lt;struct&gt;</span>' in html
        assert "Alice" in html
        assert "Bob" in html
        assert "complex-value" in html
        assert 'data-dfv-lazy-json="1"' in html
        assert 'class="json-key"' not in html
        assert "complex-preview" in html

    def test_list_of_row_like_structs_renders_as_json_not_row_repr(self) -> None:
        class MockRow:
            def __init__(self, **kwargs):
                self._data = kwargs

            def asDict(self, recursive=False):
                return dict(self._data)

            def __repr__(self) -> str:
                return f"Row({self._data!r})"

        df = pd.DataFrame(
            {
                "items": [
                    [
                        MockRow(id=1, name="Ada"),
                        MockRow(id=2, name="Grace"),
                    ]
                ]
            }
        )
        html = build_dataframe_html(df)

        assert "MockRow(" not in html
        assert "Ada" in html
        assert "Grace" in html
        assert "complex-preview" in html


class TestJsonHighlighting:
    def test_highlight_json_html_colors_tokens(self) -> None:
        highlighted = _highlight_json_html(
            '{"name": "Charlie", "active": true, "count": 3, "missing": null}'
        )

        assert '<span class="json-key">"name":</span>' in highlighted
        assert '<span class="json-string">"Charlie"</span>' in highlighted
        assert '<span class="json-boolean">true</span>' in highlighted
        assert '<span class="json-number">3</span>' in highlighted
        assert '<span class="json-null">null</span>' in highlighted


class TestThemePackaging:
    def test_labextension_assets_exist(self) -> None:
        required = [
            LABEXT / "package.json",
            LABEXT / "static/style.js",
            LABEXT / "themes/moonstorm-jup-theme/index.css",
            LABEXT / "themes/moonstorm-jup-theme/theme-light.css",
            LABEXT / "themes/moonstorm-jup-theme/theme-dark.css",
            LABEXT / "schemas/moonstorm-jup-theme/moonstorm-jup-theme.plugin.json",
        ]
        missing = [str(path.relative_to(ROOT)) for path in required if not path.exists()]
        assert missing == [], f"Missing labextension assets: {missing}"

    def test_theme_css_does_not_reference_removed_filebrowser_assets(self) -> None:
        for css_path in [
            LABEXT / "themes/moonstorm-jup-theme/theme-light.css",
            LABEXT / "themes/moonstorm-jup-theme/theme-dark.css",
        ]:
            css = css_path.read_text(encoding="utf-8")
            assert "filebrowser.css" not in css
            assert "--moonstorm-explorer-" not in css
            assert "#filebrowser" not in css

    def test_bundled_index_css_has_no_empty_string_cell_underline(self) -> None:
        index_css = (
            LABEXT / "themes/moonstorm-jup-theme/index.css"
        ).read_text(encoding="utf-8")
        assert "dfv-empty-string" not in index_css
        assert "inset 0 -2" not in index_css

    def test_error_traceback_padding_rule_beats_output_pre_reset(self) -> None:
        css = (ROOT / "style/outputs.css").read_text(encoding="utf-8")
        assert ".jp-OutputArea-output .moonstorm-error-traceback" in css
        assert "padding: 10px 12px 10px 38px" in css

    def test_schema_is_valid_json_with_cell_toolbar_defaults(self) -> None:
        schema_path = ROOT / "schema/moonstorm-jup-theme.plugin.json"
        schema = json.loads(schema_path.read_text(encoding="utf-8"))

        toolbar = schema["jupyter.lab.toolbars"]["Cell"]
        command_names = [item["name"] for item in toolbar if "name" in item]
        assert command_names == [
            "run-cell",
            "move-cell-up",
            "move-cell-down",
            "insert-cell-below",
            "delete-cell",
        ]
        # Theme-conditional Notebook/FileBrowser items are applied at runtime
        # so leaving Moonstorm can restore stock Lab toolbars.
        assert "Notebook" not in schema["jupyter.lab.toolbars"]
        assert "FileBrowser" not in schema["jupyter.lab.toolbars"]

    def test_schema_keeps_restart_controls_with_run_cluster(self) -> None:
        settings_path = ROOT / "src/lib/notebookToolbarSettings.ts"
        src = settings_path.read_text(encoding="utf-8")
        assert "run-all" in src
        assert "clear-all-outputs" in src
        assert "moonstorm-suppress-stderr" in src
        assert "moonstorm-settings" in src
        assert "STOCK_NOTEBOOK_TOOLBAR_PATCH" in src

    def test_schema_disables_notebook_interface_switcher(self) -> None:
        settings_path = ROOT / "src/lib/notebookToolbarSettings.ts"
        src = settings_path.read_text(encoding="utf-8")
        assert "interfaceSwitcher" in src
        assert "MOONSTORM_NOTEBOOK_TOOLBAR_PATCH" in src

    def test_seti_assets_exist(self) -> None:
        assets = ROOT / "moonstorm_jup_theme/assets/file-icons"
        required = [
            assets / "seti.woff",
            assets / "seti-icon-theme.json",
            ROOT / "style/file-icons-dark.generated.css",
            ROOT / "style/file-icons-light.generated.css",
            ROOT / "style/tabs.css",
        ]
        missing = [str(path.relative_to(ROOT)) for path in required if not path.exists()]
        assert missing == [], f"Missing Seti/tab assets: {missing}"

    def test_seti_css_leaves_dir_listing_before_pseudo_for_running_dot(self) -> None:
        for css_name in ["file-icons-dark.generated.css", "file-icons-light.generated.css"]:
            css = (ROOT / "style" / css_name).read_text(encoding="utf-8")
            assert ".jp-DirListing-item .jp-DirListing-itemIcon," in css
            assert ".moonstorm-FileBrowser-treeRow .jp-DirListing-itemIcon {" in css
            assert "position: relative" in css
            assert '.moonstorm-FileBrowser-treeRow[data-isdir="true"]' in css
            assert (
                '.jp-DirListing-item[data-isdir="true"] .jp-DirListing-itemIcon::after{'
                in css
                or '.jp-DirListing-item[data-isdir="true"]' in css
            )
            assert (
                '.jp-DirListing-item[data-isdir="true"] .jp-DirListing-itemIcon::before{font-family:'
                not in css
            )

    def test_tabs_css_hides_default_launcher_add_button(self) -> None:
        css = (ROOT / "style/tabs.css").read_text(encoding="utf-8")
        assert ".moonstorm-tab-bar-tray {" in css
        assert "--moonstorm-tab-bar-tray-radius: 8px" in css
        assert "#jp-main-dock-panel" in css
        assert ".lm-TabBar-addButton" in css
        assert "display: none !important" in css

    def test_chrome_css_hides_file_browser_toolbar_launcher(self) -> None:
        css = (ROOT / "style/chrome.css").read_text(encoding="utf-8")
        assert ".jp-FileBrowser-toolbar" in css
        assert "data-jp-item-name='new-launcher'" in css
        assert "display: none !important" in css

    def test_schema_disables_file_browser_launcher_toolbar_item(self) -> None:
        # Launcher hide is CSS/JS while Moonstorm is active — not a permanent
        # schema disable (so stock Lab returns after leaving the theme).
        schema = json.loads(
            (ROOT / "schema/moonstorm-jup-theme.plugin.json").read_text(
                encoding="utf-8"
            )
        )
        assert "FileBrowser" not in schema.get("jupyter.lab.toolbars", {})
        css = (ROOT / "style/chrome.css").read_text(encoding="utf-8")
        assert "new-launcher" in css

    def test_launcher_css_uses_seti_notebook_for_launcher_and_menus(self) -> None:
        css = (ROOT / "style/launcher.css").read_text(encoding="utf-8")
        compact = " ".join(css.split())
        assert "data-category='Notebook'" in css
        assert ".jp-Launcher-sectionHeader::before" in css
        assert (
            ".jp-Launcher-sectionHeader > :not(.jp-Launcher-sectionTitle)" in compact
            or ".jp-Launcher-sectionHeader > :not(.jp-Launcher-sectionTitle)" in css
        )
        assert "> :not(.jp-Launcher-sectionTitle)" in css
        assert ".jp-Icon-cover" not in css
        assert ".jp-Launcher-kernelIcon" not in css
        assert "content: '\\E066'" in css
        assert "launcher.png" not in css

    def test_theme_css_imports_file_browser_tree_styles(self) -> None:
        for theme_name in ["theme-dark.css", "theme-light.css"]:
            css = (ROOT / "style" / theme_name).read_text(encoding="utf-8")
            assert "@import './filebrowser-tree.css'" in css

    def test_built_theme_css_includes_tab_tray_rules(self) -> None:
        for theme_name in ["theme-dark.css", "theme-light.css"]:
            # Assert source themes (labextension may be stale until rebuild).
            src = (ROOT / "style" / theme_name).read_text(encoding="utf-8")
            assert "@import './file-icons-" not in src
            assert "@import './dataframe-viewer.css'" in src
            assert "@import './filebrowser-tree.css'" in src

            path = LABEXT / "themes/moonstorm-jup-theme" / theme_name
            if not path.is_file():
                continue
            css = path.read_text(encoding="utf-8")
            assert ".moonstorm-tab-bar-tray {" in css
            assert "--moonstorm-tab-bar-tray-radius: 8px" in css
            assert ".lm-TabBar-addButton" in css and "display: none !important" in css
            assert "content: '\\E066'" in css or "content:'\\E066'" in css
            # Launcher cards keep default icons; Seti is applied to the Notebook
            # section header and notebook menu items instead.
            assert ".jp-LauncherCard-icon" not in css
            assert ".jp-FileBrowser-toolbar" in css
            assert "data-jp-item-name='new-launcher'" in css
            assert "data-category='Notebook'" in css
            assert ".jp-Launcher-sectionHeader::before" in css
            assert ".lm-Menu-itemIcon:has(" in css
            assert ".jp-FileBrowser-mod-tree" in css
            assert ".moonstorm-FileBrowser-treeRow" in css
            # After a fresh theme rebuild, Seti is deferred out of the bundle.
            if "font-family:'seti'" not in css:
                assert ".dataframe-viewer" in css

        for name in (
            "file-icons-dark.generated.css",
            "file-icons-light.generated.css",
        ):
            src_icons = ROOT / "style" / name
            assert src_icons.is_file()
            assert "font-family:'seti'" in src_icons.read_text(encoding="utf-8")

    def test_packaged_dataframe_engine_logos_exist(self) -> None:
        # Icons remain in the package for possible future use, but are not
        # rendered in the dataframe viewer header.
        assets = ROOT / "moonstorm_jup_theme" / "assets"
        for name in ("pandas.png", "spark.png"):
            path = assets / name
            assert path.is_file(), f"missing dataframe engine logo: {path}"
            assert path.stat().st_size > 100


class TestIpythonExtension:
    def test_register_display_formatters_with_mock_ipython(
        self, sample_df: pd.DataFrame, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        monkeypatch.setattr(viewer, "_FORMATTERS_REGISTERED", False)
        class MockFormatter:
            def __init__(self) -> None:
                self.types: list[type] = []

            def for_type(self, typ, func) -> None:
                self.types.append(typ)

            def for_type_by_name(self, module, name, func) -> None:
                return None

            def pop(self, typ, default=None):
                return default

        class MockIPython:
            def __init__(self) -> None:
                self.display_formatter = type(
                    "DisplayFormatter",
                    (),
                    {"formatters": {"text/html": MockFormatter()}},
                )()

        ipython = MockIPython()
        assert register_display_formatters(ipython) is True

        formatter = ipython.display_formatter.formatters["text/html"]
        assert pd.DataFrame in formatter.types

        html = sample_df._repr_html_()
        assert isinstance(html, str)
        assert "dataframe-viewer" in html
        assert "Ada" in html

        unregister_display_formatters(ipython)
        monkeypatch.setattr(viewer, "_FORMATTERS_REGISTERED", False)

    def test_unregister_display_formatters_restores_default_html(
        self, sample_df: pd.DataFrame, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        if viewer._ORIGINAL_PANDAS_REPR_HTML is not None:
            pd.DataFrame._repr_html_ = viewer._ORIGINAL_PANDAS_REPR_HTML

        monkeypatch.setattr(viewer, "_FORMATTERS_REGISTERED", False)
        monkeypatch.setattr(viewer, "_ORIGINAL_PANDAS_REPR_HTML", None)

        class MockFormatter:
            def __init__(self) -> None:
                self.types: dict[type, object] = {}
                self.deferred: dict[tuple[str, str], object] = {}

            def for_type(self, typ, func) -> None:
                self.types[typ] = func

            def for_type_by_name(self, module, name, func) -> None:
                self.deferred[(module, name)] = func

            def pop(self, typ, default=None):
                if isinstance(typ, str):
                    key = tuple(typ.rsplit(".", 1))
                    return self.deferred.pop(key, default)
                return self.types.pop(typ, default)

        class MockIPython:
            def __init__(self) -> None:
                self.display_formatter = type(
                    "DisplayFormatter",
                    (),
                    {"formatters": {"text/html": MockFormatter()}},
                )()

        ipython = MockIPython()
        default_html = sample_df._repr_html_()
        assert "dataframe-viewer" not in default_html

        assert register_display_formatters(ipython) is True
        moonstorm_html = sample_df._repr_html_()
        assert "dataframe-viewer" in moonstorm_html

        assert unregister_display_formatters(ipython) is True
        restored_html = sample_df._repr_html_()
        assert "dataframe-viewer" not in restored_html
        assert restored_html == default_html

    def test_register_display_formatters_without_ipython_returns_false(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        monkeypatch.setattr(viewer, "_FORMATTERS_REGISTERED", False)
        assert register_display_formatters(None) is False

    def test_register_spark_formatters_deferred_by_name(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """EG: Spark HTML formatters must register before import pyspark."""
        import moonstorm_jup_theme.dataframe_viewer as viewer

        monkeypatch.setattr(viewer, "_FORMATTERS_REGISTERED", False)
        monkeypatch.setattr(viewer, "_spark_dataframe_types", lambda: [])

        class MockFormatter:
            def __init__(self) -> None:
                self.deferred: dict[tuple[str, str], object] = {}

            def for_type(self, typ, func) -> None:
                return None

            def for_type_by_name(self, module, name, func) -> None:
                self.deferred[(module, name)] = func

            def pop(self, typ, default=None):
                return default

        class MockIPython:
            def __init__(self) -> None:
                html = MockFormatter()
                plain = MockFormatter()
                self.display_formatter = type(
                    "DisplayFormatter",
                    (),
                    {"formatters": {"text/html": html, "text/plain": plain}},
                )()

        ipython = MockIPython()
        assert register_display_formatters(ipython) is True

        html = ipython.display_formatter.formatters["text/html"]
        for mod_name, cls_name in _SPARK_DF_TYPE_NAMES:
            assert (mod_name, cls_name) in html.deferred

        plain = ipython.display_formatter.formatters["text/plain"]
        # Wrapped by omit proxy; deferred names still live on the inner formatter.
        assert isinstance(plain, viewer._MoonstormPlainOmitProxy)
        for mod_name, cls_name in _SPARK_DF_TYPE_NAMES:
            assert (mod_name, cls_name) in plain._inner.deferred

        unregister_display_formatters(ipython)
        monkeypatch.setattr(viewer, "_FORMATTERS_REGISTERED", False)

    def test_ensure_spark_display_formatters_refreshes_after_register(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        monkeypatch.setattr(viewer, "_FORMATTERS_REGISTERED", True)
        calls: list[str] = []

        class MockFormatter:
            def for_type(self, typ, func) -> None:
                return None

            def for_type_by_name(self, module, name, func) -> None:
                calls.append(f"{module}.{name}")

            def pop(self, typ, default=None):
                return default

        ipython = type(
            "IPython",
            (),
            {
                "display_formatter": type(
                    "DF",
                    (),
                    {
                        "formatters": {
                            "text/html": MockFormatter(),
                            "text/plain": MockFormatter(),
                        }
                    },
                )(),
            },
        )()
        assert ensure_spark_display_formatters(ipython) is True
        assert any(
            name.startswith("pyspark.sql") for name in calls
        )

    def test_is_spark_df_matches_module_path_without_import(self) -> None:
        class FakeSparkDF:
            __module__ = "pyspark.sql.classic.dataframe"
            columns = ["a"]

            def take(self, n):
                return []

        FakeSparkDF.__name__ = "DataFrame"
        assert _is_spark_df(FakeSparkDF()) is True
        assert _is_spark_df(pd.DataFrame({"a": [1]})) is False

    def test_cell_batch_coalesces_multiple_displays(
        self, sample_df: pd.DataFrame, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        published: list[object] = []

        monkeypatch.setattr(viewer, "_CELL_DF_BATCHING", False)
        monkeypatch.setattr(viewer, "_CELL_DF_FLUSHING", False)
        monkeypatch.setattr(viewer, "_CELL_DF_BUFFER", [])
        monkeypatch.setattr(viewer, "_CELL_DF_SOURCE_LABELS", [])
        monkeypatch.setattr(
            viewer,
            "display",
            lambda df, **kwargs: published.append(("one", df)),
        )
        monkeypatch.setattr(
            viewer,
            "displays",
            lambda frames, **kwargs: published.append(("multi", frames)),
        )

        other = pd.DataFrame({"z": [1]})
        viewer._start_cell_dataframe_batch()
        assert viewer._format_dataframe_html_or_batch(sample_df) is None
        assert viewer._format_dataframe_html_or_batch(other) is None
        assert published == []

        viewer._flush_cell_dataframe_batch()
        assert published[0][0] == "multi"
        assert len(published[0][1]) == 2
        assert viewer._CELL_DF_BUFFER == []
        assert viewer._CELL_DF_BATCHING is False

    def test_labels_from_cell_source_display_calls(self) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        assert viewer._labels_from_cell_source(
            "display(df)\ndisplay(df5)\n"
        ) == ["df", "df5"]
        assert viewer._labels_from_cell_source("df\ndf5\n") == ["df", "df5"]
        assert viewer._labels_from_cell_source(
            "display(df)\nfrom IPython.display import display\ndisplay(other)\n"
        ) == ["df", "other"]
        assert viewer._labels_from_cell_source("display(df.head())\n") == []

    def test_cell_batch_uses_display_variable_names_as_tab_labels(
        self, sample_df: pd.DataFrame, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        published: list[object] = []
        other = pd.DataFrame({"z": [1]})

        monkeypatch.setattr(viewer, "_CELL_DF_BATCHING", False)
        monkeypatch.setattr(viewer, "_CELL_DF_FLUSHING", False)
        monkeypatch.setattr(viewer, "_CELL_DF_BUFFER", [])
        monkeypatch.setattr(viewer, "_CELL_DF_SOURCE_LABELS", [])
        monkeypatch.setattr(viewer, "_CELL_DF_RAW_CELL", "")
        monkeypatch.setattr(
            viewer,
            "_label_from_call_site",
            lambda: "",
        )
        monkeypatch.setattr(
            viewer,
            "displays",
            lambda frames, **kwargs: published.append(frames),
        )

        info = type("Info", (), {"raw_cell": "display(df)\ndisplay(df5)\n"})()
        viewer._start_cell_dataframe_batch(info)
        assert viewer._CELL_DF_SOURCE_LABELS == ["df", "df5"]
        assert viewer._CELL_DF_RAW_CELL == "display(df)\ndisplay(df5)\n"
        assert viewer._format_dataframe_html_or_batch(sample_df) is None
        assert viewer._format_dataframe_html_or_batch(other) is None
        viewer._flush_cell_dataframe_batch()

        assert len(published) == 1
        labels = [label for label, _df in published[0]]
        assert labels == ["df", "df5"]

    def test_flush_relabels_empty_buffer_from_raw_cell(
        self, sample_df: pd.DataFrame, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        published: list[object] = []
        other = pd.DataFrame({"z": [1]})

        monkeypatch.setattr(viewer, "_CELL_DF_BATCHING", True)
        monkeypatch.setattr(viewer, "_CELL_DF_FLUSHING", False)
        monkeypatch.setattr(viewer, "_CELL_DF_BUFFER", [("", sample_df), ("", other)])
        monkeypatch.setattr(viewer, "_CELL_DF_SOURCE_LABELS", [])
        monkeypatch.setattr(
            viewer,
            "_CELL_DF_RAW_CELL",
            "display(df)\ndisplay(df5)\n",
        )
        monkeypatch.setattr(
            viewer,
            "displays",
            lambda frames, **kwargs: published.append(frames),
        )

        viewer._flush_cell_dataframe_batch()
        assert published[0][0][0] == "df"
        assert published[0][1][0] == "df5"

    def test_label_at_source_line_display_calls(self) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        src = "display(df)\ndisplay(df5)\n"
        assert viewer._label_at_source_line(src, 1) == "df"
        assert viewer._label_at_source_line(src, 2) == "df5"
        assert viewer._label_from_expr_value_line("display(df5)") == "df5"

    def test_plain_formatter_omits_text_during_batch(
        self, sample_df: pd.DataFrame, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        calls: list[object] = []

        class PlainFormatter:
            def __call__(self, obj):
                calls.append(obj)
                return repr(obj)

            def for_type(self, typ, func) -> None:
                return None

            def for_type_by_name(self, module, name, func) -> None:
                return None

            def pop(self, typ, default=None):
                return default

        plain = PlainFormatter()
        ipython = type(
            "IPython",
            (),
            {
                "display_formatter": type(
                    "DF",
                    (),
                    {"formatters": {"text/plain": plain}},
                )(),
            },
        )()
        viewer._install_plain_suppressors(ipython)
        proxy = ipython.display_formatter.formatters["text/plain"]
        assert isinstance(proxy, viewer._MoonstormPlainOmitProxy)

        monkeypatch.setattr(viewer, "_CELL_DF_BATCHING", True)
        monkeypatch.setattr(viewer, "_CELL_DF_FLUSHING", False)
        assert proxy(sample_df) is None
        assert calls == []

        monkeypatch.setattr(viewer, "_CELL_DF_BATCHING", False)
        assert proxy(sample_df) == repr(sample_df)
        assert calls == [sample_df]

        viewer._uninstall_plain_suppressors(ipython)
        assert ipython.display_formatter.formatters["text/plain"] is plain

    def test_display_buffers_during_cell_batch(
        self, sample_df: pd.DataFrame, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import moonstorm_jup_theme.dataframe_viewer as viewer

        monkeypatch.setattr(viewer, "_CELL_DF_BATCHING", True)
        monkeypatch.setattr(viewer, "_CELL_DF_FLUSHING", False)
        monkeypatch.setattr(viewer, "_CELL_DF_BUFFER", [])
        monkeypatch.setattr(
            viewer,
            "_ipython_display",
            lambda *_a, **_k: (_ for _ in ()).throw(AssertionError("publish")),
        )

        viewer.display(sample_df)
        assert len(viewer._CELL_DF_BUFFER) == 1
