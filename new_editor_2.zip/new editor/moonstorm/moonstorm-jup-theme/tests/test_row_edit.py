"""Tests for manual dataframe row edit (HTML snapshot, display cells, wiring)."""

from __future__ import annotations

import json
import re

import pandas as pd
import pytest

from moonstorm_jup_theme.dataframe_viewer import (
    _build_edit_snapshot,
    _format_simple_cell,
    build_dataframe_html,
)


@pytest.fixture
def notes_df() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "service_id": [1, 2, 3],
            "notes": ["", None, "checked brakes"],
        }
    )


class TestEmptyStringDisplay:
    def test_empty_string_markup_distinct_from_null(self, notes_df: pd.DataFrame) -> None:
        empty_html = _format_simple_cell("")
        null_html = _format_simple_cell(None)
        assert "dfv-empty-string" in empty_html
        assert "dataframe-null" in null_html
        assert "dfv-empty-string" not in null_html
        assert "dataframe-null" not in empty_html

    def test_viewer_html_includes_row_edit_and_empty_string(self, notes_df: pd.DataFrame) -> None:
        html = build_dataframe_html(notes_df)
        assert "dataframe-row-edit-btn" in html
        assert "data-dfv-edit-snapshot" in html
        assert "dfv-empty-string" in html
        assert 'class="dataframe-null dfv-cell-text">null</span>' in html
        assert "parseCellInput" in html
        assert "buildPandasPatchSource" in html
        assert "buildPySparkPatchSource" in html
        assert "stripEditArtifacts" in html


class TestEditSnapshot:
    def test_snapshot_json_round_trip_preserves_empty_and_null(
        self, notes_df: pd.DataFrame
    ) -> None:
        html = build_dataframe_html(notes_df)
        match = re.search(
            r'<script[^>]+data-dfv-edit-snapshot="1"[^>]*>(\{.*?\})</script>',
            html,
            re.DOTALL,
        )
        assert match is not None
        payload = json.loads(match.group(1))
        assert payload["engine"] == "pandas"
        notes_col = next(c for c in payload["columns"] if c["name"] == "notes")
        assert "STRING" in notes_col["sqlType"].upper()
        rows = payload["rows"]
        assert rows[0][1] == ""
        assert rows[1][1] is None
        assert rows[2][1] == "checked brakes"

    def test_edit_snapshot_helper_preserves_types(self) -> None:
        from moonstorm_jup_theme.dataframe_viewer import (
            _ColumnMeta,
            _TableData,
            _build_edit_snapshot,
        )

        col = _ColumnMeta("notes", object(), "string", "string", 80, 40)
        data = _TableData(display_rows=[{"notes": ""}], has_more=False)
        raw = _build_edit_snapshot([col], data, engine="pandas")
        payload = json.loads(raw)
        assert payload["engine"] == "pandas"
        assert payload["rows"][0][0] == ""


class TestRowEditHygiene:
    def test_activate_edit_reads_dom_before_prepare(self) -> None:
        from pathlib import Path

        py = Path(__file__).resolve().parents[1] / "moonstorm_jup_theme/dataframe_viewer.py"
        text = py.read_text(encoding="utf-8")
        assert "var origVal = cellValueFromDom(td)" in text
        idx = text.index("var origVal = cellValueFromDom(td)")
        prep = text.index("prepareEditableCell(td)", idx)
        assert idx < prep

    def test_no_empty_string_underline_in_shared_css(self) -> None:
        from pathlib import Path

        css = (
            Path(__file__).resolve().parents[1] / "style/dataframe-viewer.css"
        ).read_text(encoding="utf-8")
        assert "inset 0 -2px" not in css
        assert "content:'\\200b'" not in css
        assert "dfv-empty-string" in css or "dfv-cell-editable" in css
