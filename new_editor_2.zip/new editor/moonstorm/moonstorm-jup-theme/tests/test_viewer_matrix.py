"""DataFrame viewer matrix tests for notebook display workflows."""

from __future__ import annotations

import itertools
import json

import pandas as pd
import pytest

from moonstorm_jup_theme.dataframe_viewer import (
    _MAX_ROWS_HARD_CAP,
    _highlight_json_html,
    build_dataframe_html,
)

ROW_COUNTS = [0, 1, 2, 3, 5, 10, 25, 50, 100, 200]
COL_COUNTS = [1, 2, 3, 5, 8, 12, 20, 30]
MAX_ROW_OPTIONS = [1, 2, 5, 10, 25, 50, 100, 200, 500, 1000]
DTYPES = [
    "int64",
    "float64",
    "object",
    "bool",
    "datetime64[ns]",
]


def _frame(rows: int, cols: int, *, dtype: str = "int64") -> pd.DataFrame:
    if cols == 0:
        return pd.DataFrame()
    if rows == 0:
        return pd.DataFrame(columns=[f"col_{index}" for index in range(cols)])
    data = {}
    for index in range(cols):
        column = f"col_{index}"
        if dtype == "object":
            data[column] = [f"value-{row}-{index}" for row in range(rows)]
        elif dtype == "bool":
            data[column] = [row % 2 == 0 for row in range(rows)]
        elif dtype == "datetime64[ns]":
            data[column] = pd.date_range("2024-01-01", periods=rows, freq="D")
        else:
            data[column] = list(range(rows))
    return pd.DataFrame(data)


SIZE_CASES = [
    (rows, cols)
    for rows, cols in itertools.product(ROW_COUNTS, COL_COUNTS)
    if rows * cols <= 6000
]


@pytest.mark.parametrize("rows,cols", SIZE_CASES)
def test_build_dataframe_html_for_shape_matrix(rows: int, cols: int) -> None:
    frame = _frame(rows, cols)
    html = build_dataframe_html(frame, max_rows=min(rows or 1, 200), show_total_rows=True)
    assert "dataframe-viewer" in html
    if rows == 0:
        assert "0 rows" in html or "empty" in html.lower() or "columns" in html
    else:
        assert "col_0" in html


@pytest.mark.parametrize("dtype", DTYPES)
@pytest.mark.parametrize("rows", range(1, 41))
def test_build_dataframe_html_for_dtype_matrix(dtype: str, rows: int) -> None:
    frame = _frame(rows, 3, dtype=dtype)
    html = build_dataframe_html(frame, max_rows=rows)
    assert "dataframe-viewer" in html
    assert "col_0" in html


@pytest.mark.parametrize("max_rows", MAX_ROW_OPTIONS)
@pytest.mark.parametrize("rows", [1, 5, 50, 500, 2000])
def test_build_dataframe_html_respects_row_cap(max_rows: int, rows: int) -> None:
    frame = _frame(rows, 4)
    capped = min(max_rows, _MAX_ROWS_HARD_CAP)
    html = build_dataframe_html(frame, max_rows=capped, show_total_rows=True)
    assert "dataframe-viewer" in html
    if rows > capped:
        assert "showing" in html.lower()


@pytest.mark.parametrize(
    "payload",
    [
        {"name": "Ada", "score": 99},
        {"items": [1, 2, 3]},
        {"nested": {"a": 1, "b": [True, False]}},
        [1, 2, 3],
        "plain-text",
        42,
        None,
    ]
    * 15,
)
def test_highlight_json_html_matrix(payload: object) -> None:
    json_str = json.dumps(payload, default=str)
    html = _highlight_json_html(json_str)
    assert isinstance(html, str)
    assert html
    if isinstance(payload, str):
        assert payload in html or "plain-text" in html


@pytest.mark.parametrize("rows", range(1, 31))
def test_viewer_reports_column_count(rows: int) -> None:
    frame = _frame(rows, 4)
    html = build_dataframe_html(frame)
    assert "<strong>4</strong> columns" in html
