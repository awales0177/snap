import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it } from 'node:test';

import { loadRowEditApiFromFile } from './helpers/rowEditRuntime.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '../..');
const viewerPy = join(root, 'moonstorm_jup_theme/dataframe_viewer.py');
const dfvCss = join(root, 'style/dataframe-viewer.css');

const api = loadRowEditApiFromFile(viewerPy);

const sampleSnapshot = {
  engine: 'pandas',
  columns: [
    { name: 'id', sqlType: 'INT' },
    { name: 'notes', sqlType: 'STRING' },
    { name: 'active', sqlType: 'BOOLEAN' },
    { name: 'cost', sqlType: 'DOUBLE' },
    { name: 'day', sqlType: 'DATE' }
  ],
  rows: [
    [1, '', null],
    [2, 'hello', true]
  ]
};

describe('dataframe row edit — parseCellInput', () => {
  it('treats null literal as SQL null', () => {
    assert.equal(api.parseCellInput('null', 'STRING'), null);
    assert.equal(api.parseCellInput('NULL', 'STRING'), null);
    assert.equal(api.parseCellInput('  null  ', 'STRING'), null);
  });

  it('preserves empty string distinct from null', () => {
    assert.equal(api.parseCellInput('', 'STRING'), '');
    assert.notEqual(api.parseCellInput('', 'STRING'), null);
  });

  it('strips zero-width spaces from input', () => {
    assert.equal(api.parseCellInput('\u200b', 'STRING'), '');
    assert.equal(api.parseCellInput('a\u200bb', 'STRING'), 'ab');
  });

  it('parses booleans and numbers', () => {
    assert.equal(api.parseCellInput('True', 'BOOLEAN'), true);
    assert.equal(api.parseCellInput('False', 'BOOLEAN'), false);
    assert.equal(api.parseCellInput('42', 'INT'), 42);
    assert.equal(api.parseCellInput('-3.5', 'DOUBLE'), -3.5);
  });

  it('keeps non-numeric text as strings', () => {
    assert.equal(api.parseCellInput('hello', 'STRING'), 'hello');
    assert.equal(api.parseCellInput('01', 'STRING'), '01');
  });
});

describe('dataframe row edit — validateDisplayValue', () => {
  it('allows empty string only on string-like columns', () => {
    assert.equal(api.validateDisplayValue('', 'STRING').ok, true);
    assert.equal(api.validateDisplayValue('', 'VARCHAR(64)').ok, true);
    assert.equal(api.validateDisplayValue('', 'INT').ok, false);
    assert.equal(api.validateDisplayValue('', 'DOUBLE').ok, false);
  });

  it('allows null literal on any column', () => {
    assert.equal(api.validateDisplayValue('null', 'INT').ok, true);
    assert.equal(api.validateDisplayValue('NULL', 'BOOLEAN').ok, true);
  });

  it('validates boolean formats', () => {
    assert.equal(api.validateDisplayValue('true', 'BOOLEAN').ok, true);
    assert.equal(api.validateDisplayValue('false', 'BOOL').ok, true);
    assert.equal(api.validateDisplayValue('maybe', 'BOOLEAN').ok, false);
  });

  it('documents date validation in viewer source', () => {
    const py = readFileSync(viewerPy, 'utf8');
    assert.match(py, /Use YYYY-MM-DD/);
    assert.match(py, /base === 'DATE'/);
  });
});

describe('dataframe row edit — renderCellText', () => {
  it('renders null and empty string differently', () => {
    const nullHtml = api.renderCellText(null);
    const emptyHtml = api.renderCellText('');
    assert.match(nullHtml, /dataframe-null/);
    assert.match(emptyHtml, /dfv-empty-string/);
    assert.doesNotMatch(emptyHtml, /dataframe-null/);
    assert.doesNotMatch(nullHtml, /dfv-empty-string/);
  });

  it('escapes HTML in cell values', () => {
    const html = api.renderCellText('<script>"x"</script>');
    assert.match(html, /&lt;script&gt;/);
    assert.doesNotMatch(html, /<script>/);
  });
});

describe('dataframe row edit — DOM cell readers', () => {
  it('reads null vs empty string before edit prep', () => {
    const nullTd = document.createElement('td');
    nullTd.innerHTML =
      '<span class="dataframe-null dfv-cell-text">null</span>';
    assert.equal(api.cellValueFromDom(nullTd), null);

    const emptyTd = document.createElement('td');
    emptyTd.innerHTML =
      '<span class="dfv-cell-text dfv-empty-string"></span>';
    assert.equal(api.cellValueFromDom(emptyTd), '');
  });

  it('reads contenteditable empty td as empty string', () => {
    const td = document.createElement('td');
    td.setAttribute('contenteditable', 'true');
    td.innerHTML = '';
    assert.equal(api.cellRawText(td), '');
    assert.equal(api.isEmptyEditCell(td), true);
  });
});

describe('dataframe row edit — patch codegen', () => {
  it('pandas patch uses empty string literal not None', () => {
    const src = api.buildPandasPatchSource(
      'id',
      { name: 'df', known: true },
      [
        {
          op: 'replace',
          match: { id: 1 },
          set: { notes: '' }
        }
      ],
      sampleSnapshot
    );
    assert.match(src, /notes.*= ''/);
    assert.doesNotMatch(src, /notes.*= None/);
  });

  it('pandas patch uses None for null', () => {
    const src = api.buildPandasPatchSource(
      'id',
      { name: 'df', known: true },
      [
        {
          op: 'replace',
          match: { id: 2 },
          set: { notes: null }
        }
      ],
      sampleSnapshot
    );
    assert.match(src, /notes.*= None/);
  });

  it('pyspark patch uses try_cast for empty string on strings', () => {
    const src = api.buildPySparkPatchSource(
      'id',
      { name: 'df', known: true },
      [
        {
          op: 'replace',
          match: { id: 1 },
          set: { notes: '' }
        }
      ],
      sampleSnapshot
    );
    assert.match(src, /try_cast\(''/);
    assert.match(src, /AS STRING/);
  });

  it('sql insert fragment uses try_cast empty string', () => {
    const frag = api.sqlTryCastFragment('', 'STRING');
    assert.equal(frag, "try_cast('' AS STRING)");
    assert.equal(api.sqlTryCastFragment(null, 'STRING'), 'CAST(NULL AS STRING)');
  });

  it('sparkTryCastExpr handles null boolean and number', () => {
    assert.match(api.sparkTryCastExpr(null, 'INT'), /F\.lit\(None\)/);
    assert.match(api.sparkTryCastExpr(true, 'BOOLEAN'), /True/);
    assert.match(api.sparkTryCastExpr(3, 'INT'), /F\.lit\(3\)/);
  });
});

describe('dataframe row edit — source hygiene', () => {
  it('captures original cell value before prepareEditableCell', () => {
    const py = readFileSync(viewerPy, 'utf8');
    const origIdx = py.indexOf('var origVal = cellValueFromDom(td)');
    const prepIdx = py.indexOf('prepareEditableCell(td)', origIdx);
    assert.ok(origIdx >= 0 && prepIdx >= 0);
    assert.ok(origIdx < prepIdx, 'origVal must be read before DOM prep');
  });

  it('uses spellcheck=false on editable cells', () => {
    const py = readFileSync(viewerPy, 'utf8');
    assert.match(py, /setAttribute\('spellcheck', 'false'\)/);
  });

  it('does not inject zero-width space in CSS', () => {
    const css = readFileSync(dfvCss, 'utf8');
    assert.doesNotMatch(css, /\\200b/u);
    assert.doesNotMatch(css, /inset 0 -2px/);
    assert.match(css, /dfv-empty-string[\s\S]*box-shadow:none !important/);
  });

  it('refreshes injected dataframe viewer CSS when already present', () => {
    const stylesTs = readFileSync(
      join(root, 'src/lib/dataframeViewerStyles.ts'),
      'utf8'
    );
    assert.match(stylesTs, /style\.textContent = DATAFRAME_VIEWER_CSS/);
    assert.doesNotMatch(
      stylesTs,
      /getElementById\(DATAFRAME_VIEWER_STYLE_ID\)\) \{\s*return;/
    );
  });
});
