import { readFileSync } from 'node:fs';

/** Pull the row-edit JS template from dataframe_viewer.py and unescape Python `{{` braces. */
export function readRowEditTemplate(viewerPyText) {
  const marker = '_JS_ROW_EDIT_TMPL = """\\';
  const start = viewerPyText.indexOf(marker);
  if (start < 0) {
    throw new Error('row edit template not found');
  }
  const bodyStart = start + marker.length;
  const nextTpl = viewerPyText.indexOf('\n_JS_', bodyStart);
  if (nextTpl < 0) {
    throw new Error('row edit template end not found');
  }
  let body = viewerPyText.slice(bodyStart, nextTpl);
  body = body.replace(/"""\s*$/u, '');
  body = body.replace(/\{\{/g, '{').replace(/\}\}/g, '}');
  // Python stores JS escapes as \\' / \\uXXXX — normalize for new Function() eval.
  return body
    .replace(/\\\\u([0-9a-fA-F]{4})/g, '\\u$1')
    .replace(/\\\\'/g, "\\'");
}

/** Extract one `function name(...) { ... }` block (brace-balanced). */
export function extractFunction(source, fnName) {
  const re = new RegExp(`function ${fnName}\\(`);
  const start = source.search(re);
  if (start < 0) {
    throw new Error(`function ${fnName} not found`);
  }
  const open = source.indexOf('{', start);
  if (open < 0) {
    throw new Error(`function ${fnName} has no body`);
  }
  let depth = 0;
  for (let i = open; i < source.length; i++) {
    const ch = source[i];
    if (ch === '{') depth += 1;
    else if (ch === '}') {
      depth -= 1;
      if (depth === 0) {
        return source.slice(start, i + 1);
      }
    }
  }
  throw new Error(`function ${fnName} unbalanced braces`);
}

const FN_NAMES = [
  'escapeHtml',
  'stripEditArtifacts',
  'isStringSqlType',
  'parseCellInput',
  'normalizeDisplay',
  'validateDisplayValue',
  'renderCellText',
  'cellRawText',
  'cellValueFromDom',
  'isEmptyEditCell',
  'sqlEscapeLiteral',
  'sqlTypeForColumn',
  'sparkTryCastExpr',
  'sqlTryCastFragment',
  'pyLiteral',
  'pyColRef',
  'buildPandasPatchSource',
  'buildPySparkPatchSource',
  'sparkMatchCondition'
];

/** Evaluate pure row-edit helpers from the viewer template (no DOM button wiring). */
export function buildRowEditApi(viewerPyText) {
  const tmpl = readRowEditTemplate(viewerPyText);
  const parts = FN_NAMES.map(name => extractFunction(tmpl, name));
  const body = `
    ${parts.join('\n\n')}
    return {
      escapeHtml,
      stripEditArtifacts,
      isStringSqlType,
      parseCellInput,
      normalizeDisplay,
      validateDisplayValue,
      renderCellText,
      cellRawText,
      cellValueFromDom,
      isEmptyEditCell,
      sqlEscapeLiteral,
      sqlTypeForColumn,
      sparkTryCastExpr,
      sqlTryCastFragment,
      pyLiteral,
      pyColRef,
      buildPandasPatchSource,
      buildPySparkPatchSource,
      sparkMatchCondition
    };
  `;
  // eslint-disable-next-line no-new-func
  return new Function(body)();
}

export function loadRowEditApiFromFile(viewerPyPath) {
  return buildRowEditApi(readFileSync(viewerPyPath, 'utf8'));
}
